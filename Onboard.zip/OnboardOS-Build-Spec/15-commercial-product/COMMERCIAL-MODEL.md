# OnboardOS v2 — Commercial & Product Delivery Model

## Recommendation

OnboardOS should support **three deployment modes using the same core engine**. Do not choose between a client dashboard and a managed service: offer both, because they serve different buyers and create an expansion path.

### Mode A — Managed Onboarding (recommended initial sales motion)

The customer buys an outcome, not software configuration.

We map their process, connect tools, build workflows, configure AI, operate the Exception Inbox and continuously optimize onboarding.

Client experience:
- branded secure client portal
- next action
- progress/readiness
- documents/forms/approvals/payments/meetings
- contextual AI assistant
- human support when needed

Customer admin experience can initially be operated by our team. This is the fastest route to revenue and lets us learn real onboarding patterns.

### Mode B — Client-Operated SaaS

The business gets its own organization workspace and operates:
- templates
- requirements
- workflows
- team members
- integrations
- onboardings
- analytics
- AI policies

This is the normal SaaS plan.

### Mode C — White-Label Partner

Agencies/consultants operate sub-accounts for their own customers.

They receive:
- custom domain
- branding
- email identity
- client portal
- sub-account management
- templates
- usage/billing controls
- partner-level analytics

## Client Dashboard Recommendation

**Yes: build a client-facing dashboard.** But it should NOT expose the internal machinery.

The client sees the outcome:

1. What is complete
2. What we need from them now
3. What is blocking progress
4. What happens next
5. Upcoming meetings
6. Documents / approvals / payments
7. Messages and AI help
8. A simple timeline

They should not see:
- workflow node graphs
- AI model names
- internal exceptions
- internal scores unless intentionally surfaced
- internal tasks
- staff-only notes
- automation implementation details

### Client home

```text
WELCOME, ACME

Onboarding readiness
82%   Ready for kickoff in ~2 days

YOUR NEXT STEP
Connect Google Analytics
2 minutes · Required
[Connect]

WHAT'S COMPLETE
✓ Agreement
✓ Payment
✓ Business questionnaire
✓ Brand assets

UP NEXT
○ Analytics verification
○ Kickoff
○ Implementation

NEED HELP?
Ask Onboard AI
```

The product should make the client feel that a professional team is moving their project forward automatically—not that they have been handed a complicated project-management application.

## Commercial packaging

### Launch — software-assisted onboarding

For smaller service businesses.
- 1–3 templates
- branded portal
- forms/files
- payment/e-sign/calendar integrations
- email reminders
- basic readiness
- basic analytics

Suggested positioning: $149–$299/month + implementation.

### Pro — AI onboarding operations

- multiple templates
- requirements/evidence verification
- AI assistant
- AI document intelligence
- risk/health
- Exception Inbox
- workflows/escalations
- CRM + Google + Slack + WhatsApp
- advanced analytics

Suggested positioning: $399–$999/month + implementation, depending on usage.

### Managed — we run onboarding for you

- process mapping
- workflow build
- integrations
- AI configuration
- monitoring
- exception handling
- monthly optimization

Suggested positioning: $1,500–$5,000+/month plus setup, based on volume and service complexity.

### White-label Partner

- partner workspace
- unlimited branded portals subject to usage
- sub-accounts
- custom domain
- partner analytics
- templates
- reseller controls

Price using platform fee + usage + implementation.

### Enterprise

- SSO/SAML/OIDC
- SCIM
- advanced RBAC
- data residency
- custom integrations
- dedicated environment options
- audit/security controls
- custom SLAs
- procurement/security support

## Recommended go-to-market sequence

1. Sell **Managed** first to learn onboarding operations.
2. Convert repeatable patterns into vertical templates.
3. Offer **Pro SaaS** once implementation is repeatable.
4. Offer **White-label** to agencies after the multi-tenant engine is proven.
5. Expand successful customers into Customer Operations / Revenue OS.

## Product boundary

OnboardOS is not primarily a CRM, accounting system, project-management suite, or document editor.

Its proprietary layer is:

**Requirement → Evidence → Verification → Readiness → Orchestration → Exception handling → Activation → Learning.**
