# Client Portal + Commercial Decision

## Decision

**Build the paying-client Operations Dashboard now. Also build a separate end-customer onboarding workspace. Sell Managed first if speed-to-revenue is the priority.**

These are not competing choices.

### What the buyer pays for

The commercial offer can be positioned around the outcome:

> We automate and operate your client onboarding so signed clients become ready, configured and activated with less manual chasing.

### What the paying buyer sees

A branded **Client Operations Dashboard** showing their onboarding business: total onboardings, active/completed/on-track/at-risk/stuck counts, stage distribution, bottlenecks, completion and activation rates, trends, exceptions, team workload and AI insights.

### What the buyer's end customer sees

A separate **End-Customer Onboarding Workspace** used to complete forms, upload evidence, sign agreements, pay, connect integrations, book meetings, approve deliverables and communicate with the team.

### What our team sees

The Command Center: requirements, exceptions, workflow execution, integrations, AI decisions, SLAs, reconciliation and analytics.

### Why the paying-client dashboard is necessary even for Managed

1. It proves the value of the service with live operational visibility.
2. It gives the buyer one place to monitor every onboarding.
3. It exposes bottlenecks, exceptions and performance without exposing internal machinery.
4. It makes the managed service measurable and accountable.
5. The same dashboard becomes the SaaS/white-label operations surface later.
6. End-customer activity remains structured data for readiness, risk and learning.

## Recommended packaging architecture

```text
                    OnboardOS Core Engine
                            │
             ┌──────────────┴──────────────┐
             │                             │
      Client Operations              End-Customer
        Dashboard                  Onboarding Workspace
             │                             │
      metrics / pipeline             tasks / forms
      analytics / AI                 docs / payment
      exceptions / team              approvals / meetings
             │                             │
             └────────── same engine ──────┘
```

The paying-client Operations Dashboard and the end-customer Onboarding Workspace are separate product surfaces backed by the same onboarding engine. Neither is optional in the complete product architecture.
