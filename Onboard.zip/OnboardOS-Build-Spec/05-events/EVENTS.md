# OnboardOS — Event Model

## Design principles

1. Every meaningful state change emits an event.
2. Events are immutable and append-only.
3. Consumers are idempotent.
4. Realtime UI and automation engine both subscribe to the same event stream.
5. Failed external side-effects go to a dead-letter queue with manual replay.

---

## Event envelope

```json
{
  "id": "evt_01H...",
  "organization_id": "org_...",
  "instance_id": "onb_..." | null,
  "type": "client.task.completed",
  "occurred_at": "2026-09-28T10:41:00Z",
  "actor": {
    "type": "user" | "system" | "ai" | "integration",
    "id": "..."
  },
  "payload": { ... },
  "correlation_id": "corr_...",
  "causation_id": "evt_..." | null
}
```

---

## Core event catalog

### Onboarding lifecycle
- `onboarding.created`
- `onboarding.invited`
- `onboarding.started`
- `onboarding.status_changed`
- `onboarding.completed`
- `onboarding.paused`
- `onboarding.cancelled`
- `onboarding.health.changed`
- `onboarding.blocked`
- `onboarding.unblocked`

### Stages & tasks
- `stage.started`
- `stage.completed`
- `task.created`
- `task.assigned`
- `task.status_changed`
- `task.completed`
- `task.overdue`
- `task.blocked`
- `task.dependency_satisfied`

### Forms & documents
- `form.submitted`
- `document.uploaded`
- `document.analyzed`
- `document.validation_failed`
- `document.validation_passed`

### Contracts & payments
- `contract.sent`
- `contract.viewed`
- `contract.signed`
- `contract.declined`
- `payment.created`
- `payment.completed`
- `payment.failed`
- `payment.refunded`

### Scheduling
- `meeting.booked`
- `meeting.rescheduled`
- `meeting.cancelled`
- `meeting.completed`

### Communication
- `message.sent`
- `message.received`
- `message.failed`
- `reminder.sent`
- `escalation.triggered`

### Approvals
- `approval.requested`
- `approval.approved`
- `approval.rejected`
- `approval.changes_requested`

### AI
- `ai.run.started`
- `ai.run.completed`
- `ai.action.created`
- `ai.action.approved`
- `ai.action.executed`
- `ai.action.rejected`
- `ai.risk.detected`
- `ai.scope_conflict.detected`

### Workflows
- `workflow.started`
- `workflow.step.completed`
- `workflow.completed`
- `workflow.failed`

### System
- `integration.connected`
- `integration.disconnected`
- `webhook.received`
- `webhook.failed`
- `user.invited`
- `user.joined`

---

## Consumers

| Consumer | Responsibility |
|----------|----------------|
| Realtime gateway | Push role-specific projections to internal dashboard, paying-client dashboard & end-customer workspace |
| Workflow engine | Evaluate triggers & advance automations |
| Health calculator | Recompute onboarding health score |
| Risk detector | Update risk level & create exceptions |
| Notification service | In-app, email, SMS, WhatsApp, Slack |
| Analytics aggregator | Update funnel & bottleneck metrics |
| Audit writer | Persist to audit_logs |
| n8n bridge | Translate selected events into n8n webhooks |

---

## Delivery guarantees

- At-least-once delivery to consumers
- Consumer-side idempotency via event `id`
- Dead-letter queue after N retries
- Manual replay endpoint for ops
- Ordered per `instance_id` where possible (partitioned stream)

---

## Example: task completed → cascade

1. Client completes “Connect Google Analytics”
2. Emit `task.completed`
3. Health calculator updates score → `onboarding.health.changed`
4. Dependency engine marks dependent tasks unblocked → `task.dependency_satisfied`
5. Workflow engine may start next stage or send confirmation
6. Realtime pushes progress to paying-client dashboard/end-customer workspace + internal Exception Inbox update

## V2.4 Document & Billing Events

`document.created`, `document.sent`, `document.viewed`, `document.approved`, `document.signed`, `document.voided`, `signature.completed`, `invoice.created`, `invoice.finalized`, `invoice.sent`, `invoice.viewed`, `invoice.payment_failed`, `invoice.overdue`, `payment.requested`, `payment.succeeded`, `payment.failed`, `credit_note.issued`, `receipt.created`, `commercial_flow.resolved`, `commercial_flow.overridden`, `template.version_published`.

All external webhook events are persisted, verified, deduplicated and mapped to canonical domain events.

## V2.5 Client Entry Events

- `customer.created`
- `customer.updated`
- `onboarding.draft_created`
- `onboarding.flow_selected`
- `onboarding.activation_previewed`
- `onboarding.activated`
- `onboarding.activation_failed`
