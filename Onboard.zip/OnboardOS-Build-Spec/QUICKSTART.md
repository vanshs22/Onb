# OnboardOS Build Spec — Quick Start

## Read order (first day)

1. `README.md` — package map
2. `01-product/PRODUCT.md` — why this product exists
3. `02-architecture/ARCHITECTURE.md` — stack & design decisions
4. `11-backlog/BACKLOG.md` — what to build when
5. `03-database/SCHEMA.md` + `12-schemas/prisma-schema.prisma`
6. `07-screens/SCREENS.md` — UX source of truth
7. Everything else as needed

## First engineering tasks

```bash
# 1. Create monorepo
pnpm create turbo@latest onboardos
# or nx / manual

# 2. Add packages
apps/web      # Next.js
apps/api      # NestJS or Hono
apps/worker   # BullMQ
packages/db   # Prisma (copy prisma-schema.prisma)
packages/shared
packages/ai
packages/integrations

# 3. Apply schema
cd packages/db
npx prisma migrate dev --name init

# 4. Auth + org creation flow
# 5. Hardcoded template → create onboarding instance
# 6. Client magic-link portal showing next task
# 7. Emit event on task complete → admin realtime update
```

## Non-negotiables from day one

- Multi-tenant with `organization_id` + RLS
- Controlled onboarding state machine (no free-text status)
- Event emission on every meaningful change
- Audit log on privileged mutations
- No secrets in the browser

## Success demo (end of Phase 1)

1. Create organization  
2. Create client  
3. Create onboarding from template  
4. Client logs in via magic link  
5. Client completes a task  
6. Admin dashboard updates without refresh  

## Commercial note

Primary package to sell first: **Onboard Pro**  
Positioning: automated client onboarding system that chases, detects blockers, and tells the team what needs attention — not “another portal.”
