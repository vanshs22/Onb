# OnboardOS Integration Blueprint

## Integration strategy

OnboardOS is the orchestration and readiness layer. External systems remain the source of truth for their specialized domains unless an explicit source-of-truth rule says otherwise.

### Tier 1 — launch-critical

| Domain | Primary candidates | OnboardOS responsibility |
|---|---|---|
| CRM | HubSpot, Salesforce, Pipedrive, GoHighLevel, Attio, Zoho | Deal/client sync, owner, lifecycle, source IDs |
| Billing | Stripe | Checkout/payment/invoice events, reconciliation |
| E-sign | DocuSign, PandaDoc, Dropbox Sign, Adobe Acrobat Sign | Agreement status + signed evidence |
| Calendar | Google Calendar, Microsoft Outlook, Calendly, Cal.com | Availability + event sync |
| Email | Gmail/Google Workspace, Microsoft 365, SMTP/provider API | Transactional communication + delivery state |
| Files | Google Drive, OneDrive, Dropbox, Box, S3-compatible storage | Secure evidence/file access |
| SMS/voice | Twilio | Reminder and communication delivery |
| Internal chat | Slack, Microsoft Teams | Internal alerts and deep links |
| Generic | REST API, OAuth, API keys, webhooks | Long-tail integrations |

### Tier 2 — delivery ecosystem

Project/delivery tools: ClickUp, Asana, Monday, Jira, Linear, Trello, Basecamp, Rocketlane, GUIDEcx.

Forms/intake: native OnboardOS forms, Typeform, Jotform, Tally, Fillout, Google Forms.

Accounting/subscriptions: QuickBooks, Xero, Chargebee, GoCardless, PayPal, Square, Razorpay.

Knowledge/content: Notion, Confluence, Google Docs, SharePoint.

### Integration contract

Every connector implements:
- credential lifecycle and least-privilege scopes
- tenant ownership and authorization
- provider/source-of-truth declaration
- connection health
- capability discovery
- inbound webhook verification
- outbound API idempotency
- durable event mapping
- retries/backoff
- rate-limit handling
- reconciliation
- replay/repair
- provider request IDs
- audit trail
- disconnect/revoke behavior
- secret rotation

### Event examples

`crm.deal_won`
`agreement.signed`
`payment.succeeded`
`payment.failed`
`form.submitted`
`file.uploaded`
`file.verified`
`calendar.booking_created`
`message.delivered`
`integration.webhook_received`
`integration.sync_failed`
`requirement.completed`
`requirement.blocked`
`readiness.changed`
`exception.created`
`activation.completed`

### Source-of-truth rule

Each data domain must declare exactly one authoritative external source where applicable. OnboardOS stores normalized references and operational projections; it must not silently overwrite an external system that owns the data.
