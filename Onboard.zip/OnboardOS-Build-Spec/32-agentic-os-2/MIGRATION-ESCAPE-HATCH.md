# Migration + Escape Hatch

Provide import/export across common CRM/onboarding/project systems plus CSV/API.

Export must preserve the Onboarding Twin including customer, scope, requirements, evidence metadata, documents, approvals, workflow versions, agent runs, events and outcomes subject to tenant policy.

No vendor-specific export may silently omit audit-critical records.
