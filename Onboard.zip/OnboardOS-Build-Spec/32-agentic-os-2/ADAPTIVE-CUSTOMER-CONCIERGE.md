# Adaptive Customer Concierge

The end-customer workspace dynamically chooses what to show next based on role, progress, missing evidence, prior answers, behavior, deadline and workflow state.

Each requirement can expose:
- why it is needed
- exact acceptable evidence
- step-by-step instructions
- examples/screenshots/video
- AI explanation
- connect/upload action
- fallback/manual path

The default experience is "what needs you now", not a giant checklist.
