# Configurable Autonomy Levels

0 Observe
1 Recommend
2 Draft
3 Auto-execute low-risk actions
4 Autopilot approved workflows
5 Autonomous operations

Autonomy is configurable per agent, tenant, workflow, tool and action type. A lower-level policy always overrides a higher-level default.
