# Agent Cost + ROI Intelligence

Track per-run and portfolio economics:
- model/tool cost
- execution time
- retries
- human intervention minutes
- tasks automated
- estimated labor avoided
- revenue protected/accelerated
- cost per successful activation

The dashboard must distinguish actual measured savings from estimates.
