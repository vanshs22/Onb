# Model / Capability Routing

Route each task to the least expensive capability that meets its risk and quality requirements.

Examples:
- deterministic code: state transitions, billing calculations, permissions
- fast model: classification, extraction, routing, reminders
- reasoning model: ambiguity, scope interpretation, complex planning
- browser agent: legacy/no-API systems
- human: configured high-risk or ambiguous decisions

Routing decisions are logged with model, capability, reason, cost and outcome.
