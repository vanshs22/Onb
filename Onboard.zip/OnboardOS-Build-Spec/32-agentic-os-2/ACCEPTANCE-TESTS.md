# Agentic OS 2.0 Acceptance Tests

A1 Agent Control Plane: unauthorized tool call is rejected server-side.
A2 Dynamic Planner: objective produces a dependency-correct DAG and re-plans after an external state change.
A3 Browser Agent: browser action is isolated, evidence-backed and cannot cross an unapproved domain.
A4 Evaluation: shadow run executes no external mutation; canary promotion requires thresholds.
A5 Stakeholder Graph: requests route to the authorized responsible stakeholder.
A6 Concierge: customer sees only currently actionable requirements and receives contextual guidance.
A7 Model Routing: deterministic work avoids LLM calls and routing decisions are logged.
A8 Cost/ROI: run cost and human-intervention estimates are captured with provenance.
A9 Process Mining: event history reconstructs actual paths and identifies rework.
A10 Contract Graph: obligation is linked to requirement/evidence/activation gate.
A11 Delivery Economics: effort burn creates an evidence-backed economic warning.
A12 First Value: technical completion does not equal activation until first-value criteria are observed.
A13 Revenue Risk: revenue-at-risk requires contract value plus an evidence-backed risk reason.
A14 Scope Recovery: out-of-scope request can generate an approval-gated change order and billing transition.
A15 Migration: export/import preserves audit-critical onboarding records.
A16 Autonomy: action executes only when effective autonomy policy permits it.
A17 Recovery: injected partial failure resumes/reconciles without duplicate side effects.
A18 Workflow Canary: new workflow can be canaried, measured and rolled back.
A19 Activation Certificate: certificate cannot be issued while mandatory activation gates remain unsatisfied.
A20 Execution Fabric: API/MCP/browser capability uses the same permission, idempotency and verification gateway.

Release gate: all A1-A20 plus all v3.1, v3 and 59-upgrade tests must pass in staging with connector sandboxes, tenant-isolation checks, failure injection and webhook replay.
