# Proof of Activation / Activation Certificate

Every completed onboarding can generate a machine-verifiable Activation Certificate containing:
- contract commitments
- requirements satisfied
- evidence references
- approvals
- payment/commercial gates
- activation criteria
- first-value evidence
- outstanding exceptions
- workflow/agent versions
- timestamp and audit identifiers

"Complete" is not valid unless the configured activation gates are satisfied.
