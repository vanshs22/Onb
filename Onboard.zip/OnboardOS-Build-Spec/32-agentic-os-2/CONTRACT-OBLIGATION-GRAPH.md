# Contract Obligation Graph

Extract and normalize obligations from agreements, SOWs, order forms and amendments.

Nodes include deliverables, deadlines, payment obligations, customer responsibilities, provider responsibilities, SLAs, acceptance criteria, restrictions and renewal terms.

Each obligation links to workflow nodes, requirements, evidence, approvals, invoices and activation criteria.
