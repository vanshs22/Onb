# Revenue-at-Risk Intelligence

Combine contract value, payment state, scope state, activation forecast, delivery economics and customer risk.

Every revenue-at-risk record requires an evidence-backed reason and suggested action such as escalation, reassignment, payment follow-up, change order or acceleration.
