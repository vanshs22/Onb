# Delivery Economics Engine

Maintain operational economics without becoming a full accounting suite.

Track contract value, expected effort, assigned capacity, actual effort, external costs, payment state, scope changes, estimated margin and revenue at risk.

Expose warnings such as: "73% onboarding complete, 91% of expected delivery effort consumed."
