# Product Usage + First-Value Intelligence

Activation is not complete merely because onboarding tasks are checked.

Integrate product/API/analytics/CRM events to detect:
SIGNED → ONBOARDING COMPLETE → READY → LIVE → FIRST VALUE → ADOPTED.

The Activation Agent can intervene when technical onboarding is complete but the customer has not reached the defined first-value event.
