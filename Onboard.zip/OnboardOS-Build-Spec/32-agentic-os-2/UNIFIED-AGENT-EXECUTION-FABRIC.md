# Unified Agent Execution Fabric

All agents use one capability layer for API, MCP, OAuth connectors, webhooks, events and browser execution.

Capabilities advertise:
- action schema
- read/write classification
- risk level
- required permissions
- idempotency support
- verification method
- compensation support
- rate limits
- cost estimate
- tenant scope

The planner selects capabilities; the gateway enforces policy; the verifier proves side effects.
