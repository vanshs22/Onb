# Scope Leakage → Change Order → Revenue Recovery

Customer requests and delivery activity are compared with contractual scope.

If a request is likely outside scope:
1. classify it
2. show evidence
3. estimate effort
4. estimate revenue impact
5. propose change order
6. route approval
7. update billing
8. unlock implementation after approval

No scope classification alone may create a billable obligation without configured approval.
