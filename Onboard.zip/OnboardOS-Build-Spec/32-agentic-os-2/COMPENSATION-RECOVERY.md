# Compensation, Reconciliation + Recovery Runtime

Partial execution is a first-class state.

For multi-step operations the runtime records checkpoints and supports:
- resume from checkpoint
- provider reconciliation
- idempotent retry
- compensating action
- rollback where supported
- human recovery

Recovery actions are themselves audited and verified.
