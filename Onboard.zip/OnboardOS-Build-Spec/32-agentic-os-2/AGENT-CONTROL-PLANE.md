# Agent Control Plane

Every agent is a governed runtime identity, not just a prompt.

## Agent record
- agent_id, tenant_id, version, capability set
- allowed tools and connector scopes
- model policy and fallback models
- autonomy level
- spend/token/time/concurrency budgets
- environment restrictions
- approval requirements
- data-access scope
- retry and compensation policy
- SLA and escalation policy
- kill switch
- evaluation status: draft, shadow, canary, autonomous, paused, retired

## Supervisor
The supervisor schedules objectives, resolves capability conflicts, enforces budgets, serializes conflicting mutations, detects stuck agents and initiates recovery or human escalation.

## Safety
Agents cannot write directly to the database. All mutations go through the execution gateway and workflow runtime.
