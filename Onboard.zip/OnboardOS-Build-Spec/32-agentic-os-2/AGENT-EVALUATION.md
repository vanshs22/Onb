# Agent Evaluation, Shadow Mode + Canary Promotion

Agents progress through controlled release states:

DRAFT → OFFLINE EVAL → SHADOW → CANARY → AUTONOMOUS.

## Evaluation dimensions
- task correctness
- policy compliance
- tool-call correctness
- evidence quality
- recovery quality
- human intervention rate
- latency
- cost
- false-positive/false-negative rates
- tenant/data isolation

Shadow mode records what the agent would have done without executing. Canary mode limits exposure by tenant/workflow/percentage. Promotion requires configured thresholds and no critical safety regressions.
