# Process Mining + Workflow Discovery

Reconstruct actual onboarding paths from immutable event history.

Detect:
- common paths and variants
- loops and rework
- skipped steps
- bottlenecks
- waiting time
- approval delays
- provider latency
- human intervention hotspots
- divergence between designed and observed workflow

Recommendations require evidence from observed events and must be measurable through experiments.
