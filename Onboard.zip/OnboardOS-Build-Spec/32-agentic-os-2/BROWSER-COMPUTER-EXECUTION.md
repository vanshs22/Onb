# Browser / Computer Execution Agent

Provides controlled execution where an API is unavailable.

## Runtime
- isolated ephemeral browser session
- domain and action allowlists
- short-lived credentials/OAuth
- no credential values in model context
- screenshot/DOM/network evidence
- destructive-action approval gates
- session recording metadata without sensitive secrets
- replayable action trace

## Verification
Browser success requires post-action evidence or provider-state verification. A click is never treated as proof that the business operation succeeded.
