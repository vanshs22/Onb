# Workflow Shadow / Canary Releases

Workflow changes can run in shadow or controlled canary populations.

Compare activation time, customer effort, failure rate, intervention, cost and first-value outcomes against the current version. Promotion and rollback are versioned and auditable.
