# Dynamic Objective Planner + Task DAG

The system plans from desired outcomes rather than requiring a fixed agent sequence.

## Inputs
- onboarding twin state
- contract obligations
- promise/scope graph
- requirements and evidence
- workflow policy
- customer/stakeholder context
- connector capabilities
- deadlines and dependencies

## Output
A bounded task DAG containing objective, preconditions, owner capability, required evidence, side effects, rollback/compensation, SLA, budget and completion criteria.

Tasks may execute in parallel only when their mutation domains are non-conflicting. Completion triggers re-planning because external state can change during execution.
