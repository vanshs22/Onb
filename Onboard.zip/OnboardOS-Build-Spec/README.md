# OnboardOS — Complete Build Specification

**Working name:** OnboardOS  
**Product:** AI-powered Client Onboarding & Activation Operating System  
**Promise:** From signed deal to fully onboarded client — automatically.

**Version:** 1.0 Build Spec  
**Date:** September 2026  
**Status:** Ready for implementation

---

## What this package contains

| Folder | Contents |
|--------|----------|
| `01-product` | Product vision, positioning, packages, competitive strategy |
| `02-architecture` | System architecture, tech stack, multi-tenant design, deployment modes |
| `03-database` | Full PostgreSQL schema, ER relationships, state machines |
| `04-api` | REST/GraphQL-ready API routes, contracts, auth patterns |
| `05-events` | Event model, event bus, realtime contracts |
| `06-workflows` | Workflow engine schema, template DSL, automation rules |
| `07-screens` | Exact screens, navigation maps, client portal & admin UX |
| `08-permissions` | RBAC matrix, roles, row-level security policies |
| `09-ai` | AI agents, document intelligence, health/risk models |
| `10-integrations` | Tier 1–3 integration contracts, webhooks, OAuth |
| `11-backlog` | Phase-by-phase implementation backlog (V1 → V3) |
| `12-schemas` | Machine-readable schemas (Prisma, JSON Schema, OpenAPI stubs) |

---

## Core thesis

Do **not** build another ordinary client portal + forms + contract app.

Build the **intelligence and execution layer** that turns a business’s existing tools into one automated onboarding process:

> Understand → Orchestrate → Chase → Validate → Detect risk → Escalate → Verify → Learn

---

## Recommended tech stack (summary)

| Layer | Choice |
|-------|--------|
| Frontend | Next.js 15 + TypeScript + Tailwind + shadcn/ui |
| Backend | Node.js + TypeScript (NestJS or Hono) |
| Database | PostgreSQL (Supabase or self-hosted) |
| Auth | Supabase Auth or Clerk |
| Files | Supabase Storage / S3 + signed URLs |
| Realtime | Supabase Realtime / WebSockets |
| Jobs | Redis + BullMQ |
| Automation | n8n (execution only; DB is source of truth) |
| AI | OpenAI / Anthropic + embeddings (pgvector) |

---

## Deployment modes (one engine, three modes)

1. **Managed by us** — high-ticket service
2. **Client-operated SaaS** — setup + subscription
3. **White-label partner** — agency resale

---

## How to use this package

1. Read `01-product/PRODUCT.md` for vision and packages.
2. Read `02-architecture/ARCHITECTURE.md` for system design.
3. Implement schema from `03-database` + `12-schemas`.
4. Follow phase backlog in `11-backlog/BACKLOG.md`.
5. Use screens in `07-screens` as the source of truth for UX.

---

## Next actions after this spec

1. Initialize monorepo (`apps/web`, `apps/api`, `packages/db`, `packages/shared`).
2. Apply Prisma / SQL schema.
3. Scaffold auth + multi-tenant org model.
4. Build Phase 1 screens and state machine.
5. Wire Stripe + calendar + e-sign as first integrations.

---

*This specification is the single source of truth for building OnboardOS.*

---

# v2 Production Upgrade

This package has been upgraded from a task-centric onboarding specification to a production-oriented **Readiness & Activation OS**.

The core model is now:

**Requirement → Evidence → Verification → Readiness → Orchestration → Exception Handling → Activation → Learning**

Key additions are documented in:
- `13-production-hardening/`
- `14-domain-model-v2/`
- `15-commercial-product/`
- `16-ui-ux-v2/`
- `17-implementation-v2/`

Commercially, OnboardOS supports:
1. Managed onboarding service
2. Client-operated SaaS
3. White-label partner platform

The product has three distinct surfaces: **OnboardOS Internal Command Center**, **Paying-Client Operations Dashboard**, and **End-Customer Onboarding Workspace**. They share the same core engine but expose different data and actions.

## v2.1 completeness update

This release explicitly tracks all 59 core upgrades in `V2-UPGRADE-MANIFEST.md` and `59-UPGRADE-TRACEABILITY.md`.

### Paying-client dashboard + end-customer workspace are real product surfaces

OnboardOS now treats both the paying-client Operations Dashboard and end-customer workspace as first-class in Managed, SaaS, White-label and Enterprise modes. See:

- `16-ui-ux-v2/CLIENT-PORTAL-IMPLEMENTATION.md` — end-customer workspace
- `16-ui-ux-v2/ADMIN-COMMAND-CENTER-IMPLEMENTATION.md`
- `16-ui-ux-v2/PORTAL-ROLES-AND-MODES.md`

The client gets a branded, mobile-first workspace for next actions, forms, documents, agreements, payments, meetings, approvals, messages, timeline and AI help. Internal workflow graphs, exceptions, private notes and automation implementation details remain in the Command Center.

### Commercial recommendation

Build one engine with three operating modes:

1. **Managed** — we run the onboarding operations; the paying business uses the Operations Dashboard, while its customers use the branded end-customer workspace.
2. **SaaS** — the paying business operates its Operations Dashboard; its customers use the workspace.
3. **White-label** — a partner operates branded Operations Dashboards and end-customer workspaces.

This keeps the customer experience consistent while allowing the service level to change without rebuilding the product.

## v2.2 complete lifecycle + integration contract

The current specification now includes the full 18-stage adaptive onboarding lifecycle and a concrete integration blueprint. See `18-lifecycle-playbook/ONBOARDING-LIFECYCLE.md`, `19-integration-blueprint/INTEGRATION-MATRIX.md`, and `20-product-requirements/COMPLETE-SYSTEM-REQUIREMENTS.md`.


## v2.3 definitive product-surface correction

For avoidance of ambiguity, “Client Portal” now means the **Paying-Client Operations Dashboard**: the dashboard used by the business that pays for OnboardOS to monitor total onboardings, active/completed/on-track/at-risk/stuck counts, pipeline stages, bottlenecks, exceptions, analytics, team performance and AI insights.

The people being onboarded by that business use a separate **End-Customer Onboarding Workspace** for forms, documents, agreements, payments, connected accounts, meetings, approvals and messages.

The platform therefore has three surfaces: **Internal Command Center → Paying-Client Operations Dashboard → End-Customer Onboarding Workspace**, all powered by the same event-driven onboarding engine.

## V2.4 — Document, Billing & Commercial Flow Engine

OnboardOS now treats agreements, proposals, SOWs, invoices, payment requests, receipts, change orders and related commercial documents as first-class workflow objects. Paying clients can configure a global commercial flow, while authorized users can override it for a specific end-customer. Example flows include Agreement → Signature → Invoice → Payment, Invoice → Payment → Agreement, or Agreement + Invoice in parallel. Custom templates can be imported, mapped, validated, versioned and published; existing issued documents remain pinned to their original template versions.

## v3 — Agentic Onboarding Operations OS

The latest release extends the 59 production upgrades with an executable agent workforce and the competitive differentiation layer. See:

- `26-agentic-onboarding-os/AGENTIC-ONBOARDING-OS.md`
- `26-agentic-onboarding-os/AGENT-TOOL-REGISTRY.json`
- `26-agentic-onboarding-os/REFERENCE-AUTONOMOUS-FLOW.json`
- `27-competitive-differentiation/COMPETITIVE-MOAT.md`
- `28-agent-execution/AGENT-EXECUTION-RUNTIME.md`
- `29-activation-intelligence/ACTIVATION-AND-INTELLIGENCE.md`
- `30-testing/V3-AGENTIC-ACCEPTANCE-TESTS.md`


## Agentic OS 2.0

The latest competitive layer is documented under `32-agentic-os-2/`. It upgrades the agent workforce into a governed execution operating system with dynamic planning, browser execution, evaluation/canary controls, stakeholder orchestration, process mining, contract obligations, delivery economics, first-value intelligence, revenue risk, recovery, migration and proof of activation.
