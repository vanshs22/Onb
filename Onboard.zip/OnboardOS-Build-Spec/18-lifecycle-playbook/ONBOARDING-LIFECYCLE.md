# OnboardOS Canonical Onboarding Lifecycle

This is the canonical end-to-end lifecycle. It is adaptive: an onboarding instance may skip, insert, or branch stages based on its template, requirements, dependencies, scope, policies, and client configuration.

## Lifecycle

1. Deal Won / Client Created
2. Onboarding Initialization
3. Welcome + End-Customer Workspace
4. Agreement / Contract
5. Payment / Billing
6. Client Intake
7. Document & Asset Collection
8. AI Understanding + Validation
9. Internal Preflight
10. Kickoff Scheduling
11. Kickoff
12. Implementation / Delivery
13. Client Review + Approvals
14. QA / Readiness
15. Activation
16. Handoff
17. Post-Onboarding Follow-up
18. Learning / Optimization

## Stage contract

Every stage must define:
- entry criteria and exit criteria
- required/optional requirements
- evidence types and verification rules
- client-visible actions
- internal actions
- AI actions and allowed tools
- automations and timers
- integrations and source-of-truth rules
- events emitted/consumed
- permissions
- failure and exception states
- SLA/escalation behavior
- realtime projection changes
- audit requirements
- analytics metrics

## 1. Deal Won / Client Created

Trigger sources: CRM deal won, manual creation, API, payment, signed agreement, lead conversion, import.

Actions: resolve/create organization and client, create engagement, attach commercial context, identify owner, create onboarding from the correct template version, capture source identifiers, and emit `onboarding.created`.

Required integration families: CRM, billing, e-sign, generic webhook/API.

Failure handling: duplicate client/deal detection, ambiguous identity, missing product mapping, connector failure -> exception without duplicate onboarding.

## 2. Onboarding Initialization

AI/rules resolve purchased services, client segment, contract scope, sales context, promises, required integrations, applicable template, policies, and initial requirements. Requirements are generated as version-pinned records with dependencies and visibility.

Output: a concrete onboarding plan and readiness graph.

## 3. Welcome + End-Customer Workspace

Provision secure client membership and branded workspace. Present progress, one Next Best Action, completed items, upcoming items, messages, help, and safe timeline. Never expose internal workflow details.

## 4. Agreement / Contract

Track agreement lifecycle and extract relevant terms. Compare approved sales context with contract. Store evidence and verification. Scope discrepancies become controlled exceptions/scope review items.

## 5. Payment / Billing

Track deposit/subscription/invoice/checkout requirements. Reconcile provider events. Payment secrets remain provider-side. Failed, pending, refunded, or disputed payments can block or branch onboarding according to policy.

## 6. Client Intake

Collect adaptive, autosaving, version-pinned forms. Conditional sections are generated from service/template context. Validate required data, contradictions, and completeness before submission.

## 7. Document & Asset Collection

Request files and external connections. Securely upload, quarantine, scan, classify, extract, verify, and associate evidence with requirements. Support Drive/Dropbox/OneDrive/Box/S3-style sources.

## 8. AI Understanding + Validation

AI analyzes approved intake, documents, sales context, promises, and connected evidence. Outputs are evidence-backed, confidence-scored, policy-checked, and either executed within permission boundaries or routed to human approval.

## 9. Internal Preflight

Run a readiness gate across contract, payment, intake, evidence, access, scope, owner assignment, dependencies, and policy requirements. Block, warn, or allow based on explicit gate policy.

## 10. Kickoff Scheduling

Offer timezone-safe availability, book/reschedule/cancel, synchronize attendees and calendar events, send reminders, and attach a client-safe kickoff record.

## 11. Kickoff

Generate an internal briefing from verified context: goals, purchased services, scope, promises, open questions, risks, missing dependencies, and success criteria. Capture decisions and action items.

## 12. Implementation / Delivery

Transition from onboarding to delivery while preserving requirements, dependencies, scope, approvals, and client context. Integrate with delivery/project systems when applicable. OnboardOS remains the orchestration/readiness layer rather than replacing every project tool.

## 13. Client Review + Approvals

Present reviewable deliverables, approvals, requested changes, comments, attachments, and immutable decisions. Revisions can reopen dependent requirements or gates.

## 14. QA / Readiness

Final activation gate checks implementation, client approval, integrations, tracking, billing, scope, required evidence, QA, and outstanding exceptions. Every blocker has a reason and owner.

## 15. Activation

Record activation event, effective date, activated services, configuration snapshot, success criteria, and post-activation plan. Trigger handoff and lifecycle follow-ups.

## 16. Handoff

Produce a verified operational handoff containing client profile, goals, scope, promises, configuration, integrations, contacts, preferences, risks, open issues, and success metrics. Route ownership to customer success/support/account management.

## 17. Post-Onboarding Follow-up

Run Day 7/14/30 or template-defined follow-ups for adoption, issues, satisfaction, outcomes, support needs, and expansion signals. Follow-ups are policy-controlled and consent-aware.

## 18. Learning / Optimization

Measure time-to-ready, time-to-activation, requirement friction, exception frequency, client completion behavior, provider failures, and outcome quality. Recommend template/workflow improvements. Never silently change production workflows; changes require versioning, testing, approval, and rollout.

## Adaptive lifecycle rule

These stages are a logical lifecycle, not a rigid checklist. The requirement/dependency graph is authoritative for what must happen for a specific engagement. Stage transitions are state-machine controlled and auditable.
