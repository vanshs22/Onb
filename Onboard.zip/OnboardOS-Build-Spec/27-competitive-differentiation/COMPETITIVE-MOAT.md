# OnboardOS v3 — Competitive Differentiation

## Positioning

OnboardOS is not a generic checklist, PSA, CRM, client portal or chatbot. It is the **execution and intelligence layer between a signed deal and verified customer activation**.

## Competitive categories

- Rocketlane / GUIDEcx: implementation and onboarding execution, portfolio visibility, AI-assisted delivery.
- OnRamp: AI-powered onboarding, customer-facing agents, dynamic workflows and portals.
- Dock / Arrows: shared customer workspaces and mutual action plans.
- Dubsado / HoneyBook / Bonsai: contracts, forms, payments, scheduling and service-business clientflow.
- Vitally / Planhat: customer health, lifecycle and success operations.
- HighLevel: broad agency CRM/marketing/automation stack.

OnboardOS should not try to win by cloning each category. Its differentiator is the connected chain of **commercial promise → scope → evidence → verified readiness → execution → activation outcome**.

## Differentiation pillars

### 1. Deal-to-Delivery Compiler
Turn sales artifacts into an executable onboarding model.

### 2. Promise Graph
Maintain provenance for what was sold/promised and compare it continuously against delivery.

### 3. Evidence-first onboarding
A requirement is complete only when required evidence is present and verified.

### 4. Agent workforce
Multiple specialized agents collaborate through typed tools and durable workflows.

### 5. Autonomous exception handling
The system retries, changes strategy, asks for clarification, escalates and verifies instead of simply flagging a red status.

### 6. Activation intelligence
The finish line is customer activation/first value, not 100% task completion.

### 7. Scope protection
Potential out-of-scope requests become structured change-order opportunities.

### 8. Customer effort optimization
Measure and reduce friction in the onboarding journey.

### 9. Workflow simulation
Test an onboarding before activation, including branches, side effects and approvals.

### 10. Learning workflows
Use completed onboarding outcomes to propose evidence-backed workflow improvements.

## Product north-star metrics

- Time to first value
- Time to activation
- Customer effort
- Percentage of onboarding work executed automatically
- Exception recovery rate
- Requirement verification accuracy
- Scope leakage prevented
- SLA breach rate
- First-pass evidence acceptance
- Customer response latency
- Activation success rate

## Avoid these traps

- Becoming a full CRM.
- Becoming a generic project manager.
- Building an unbounded agent marketplace.
- Making AI chat the main product.
- Letting AI mutate state without typed tools and policy enforcement.
- Treating task completion as customer success.
