# OnboardOS — System Architecture

## 1. High-level architecture

```
                         ┌──────────────────────┐
                         │ PAYING CLIENT DASH │
                         │ + END CUSTOMER WS  │
                         │  Tasks / Docs / Pay  │
                         │ Forms / Chat / Appr. │
                         └───────────┬──────────┘
                                     │
                                     ↓
┌───────────────┐        ┌──────────────────────┐
│ CRM / SALES   │───────→│  ONBOARDING ENGINE   │
└───────────────┘        │  Templates           │
┌───────────────┐        │  Stages / Tasks      │
│ EMAIL         │───────→│  Dependencies / SLAs │
└───────────────┘        │  Approvals / State   │
┌───────────────┐        └──────────┬───────────┘
│ CALENDAR      │───────→           │
└───────────────┘          ┌────────┴────────┐
                           ↓                 ↓
                    ┌──────────────┐ ┌──────────────┐
                    │   AI LAYER   │ │ AUTOMATION   │
                    │ Risk / Docs  │ │ ENGINE       │
                    │ Next action  │ │ Email/SMS/WA │
                    │ Q&A / Valid. │ │ CRM / Slack  │
                    └──────┬───────┘ │ Payments     │
                           │         └──────┬───────┘
                           └────────┬───────┘
                                    ↓
                         ┌──────────────────────┐
                         │ OPERATIONS COMMAND   │
                         │ CENTER               │
                         │ Health / Blockers    │
                         │ Exceptions / Analytics│
                         └──────────────────────┘
```

**Source of truth:** PostgreSQL (clients, tasks, workflows, payments, documents, AI state).  
**n8n / external runners:** execution only — never the system of record.

---

## 2. Tech stack

| Layer | Technology | Notes |
|-------|------------|-------|
| Frontend | Next.js 15 (App Router) + TypeScript | Internal Command Center + Paying-Client Dashboard + End-Customer Workspace |
| UI | Tailwind CSS + shadcn/ui | Polished, accessible |
| Backend | Node.js + TypeScript (NestJS recommended) | Or Hono for lighter |
| Database | PostgreSQL 16 | Relational model is required |
| ORM | Prisma | Or Drizzle |
| Auth | Supabase Auth or Clerk | Multi-tenant org support |
| Files | Supabase Storage or S3 | Signed URLs + RLS |
| Realtime | Supabase Realtime or Socket.io | First-class requirement |
| Jobs / Queue | Redis + BullMQ | Durable, retryable |
| Automation | n8n (self-hosted or cloud) | External actions only |
| AI | OpenAI / Anthropic + pgvector | Document extraction, agents |
| Email | Resend / Postmark / Gmail API | Transactional + Gmail |
| SMS / WhatsApp | Twilio | Templates for WA |
| Payments | Stripe | Checkout + webhooks |
| E-sign | PandaDoc / DocuSign | API + webhooks |
| Calendar | Google Calendar + Calendly | Embed + API |
| Hosting | Vercel (web) + Railway / Fly / AWS (API) | Or full Supabase |

---

## 3. Multi-tenant model

- **Organization** = tenant (customer of OnboardOS)
- All core tables carry `organization_id`
- Row Level Security (RLS) on every tenant table
- White-label partners get sub-accounts under a parent org
- Managed mode: our staff operate under the customer’s org with elevated roles

---

## 4. Deployment modes (one engine)

```
                 PLATFORM
                    │
         ┌──────────┼──────────┐
         ↓          ↓          ↓
      Managed     Client     White Label
      Service     SaaS       Partner
         │          │          │
         └──────────┼──────────┘
                    ↓
              Same Core Engine
```

- Mode A: We configure and run everything (high-ticket)
- Mode B: Customer admins control templates, users, clients
- Mode C: Agency white-labels and resells

---

## 5. Event-driven core

Every meaningful action emits an event:

```
client.task.completed
client.file.uploaded
client.payment.completed
contract.signed
message.received
meeting.booked
task.overdue
workflow.started / completed
ai.action.created
approval.requested / decided
onboarding.health.changed
onboarding.blocked / unblocked
```

Flow:

```
Event → Event bus → DB update → Realtime fan-out → Automation engine → External APIs
```

Requirements for every integration action:
- Retry with backoff
- Timeout
- Idempotency keys
- Dead-letter queue
- Webhook replay
- Failure status + manual retry

---

## 6. Realtime requirement

No stale dashboards.  
Internal Command Center, Paying-Client Dashboard and End-Customer Workspace subscribe to relevant tenant-scoped channels with different projections.  
Optimistic UI + server confirmation.

---

## 7. Security architecture (non-negotiable)

- Multi-tenant isolation (RLS)
- RBAC + fine-grained permissions
- Encrypted data at rest (Postgres + storage)
- Signed URLs for all file access
- Full audit log (who, what, when, before/after, source, AI agent, approval)
- Webhook signature verification
- Secret management (Vault / env + rotation)
- Session / device controls
- Data retention + export / delete (GDPR / CCPA ready)
- No secrets in frontend; all privileged actions server-side

---

## 8. State machine (onboarding instance)

Controlled transitions only:

```
DRAFT
→ INVITED
→ IN_PROGRESS
→ AWAITING_CLIENT
→ AWAITING_INTERNAL
→ BLOCKED
→ READY_FOR_KICKOFF
→ IN_IMPLEMENTATION
→ AWAITING_APPROVAL
→ READY_TO_LAUNCH
→ COMPLETED
→ PAUSED
→ CANCELLED
```

Every transition validates preconditions (dependencies, payments, signatures, required tasks).

---

## 9. Monorepo structure (recommended)

```
onboardos/
├── apps/
│   ├── web/          # Next.js (internal admin + paying-client dashboard + end-customer workspace)
│   ├── api/          # NestJS / Hono API
│   └── worker/       # BullMQ workers
├── packages/
│   ├── db/           # Prisma schema + migrations
│   ├── shared/       # Types, events, validators
│   ├── ai/           # Agents, extraction, prompts
│   └── integrations/ # Stripe, PandaDoc, Twilio, etc.
├── n8n/              # Workflow definitions (export)
└── docs/             # This specification
```

---

## 10. Key design decisions

1. **Postgres is source of truth** — never n8n state.
2. **Realtime is first-class** — not an afterthought.
3. **State machine > free-text status**.
4. **Dependency graph** on tasks (not just linear checklists).
5. **Human-in-the-loop permission levels** for AI actions.
6. **Exception Inbox** is the primary internal UX, not a generic task list.
7. **Health score** is computed and explainable, not a black box.
8. **Integrate first** — payments, e-sign, calendar, email, WhatsApp via existing providers.
