# OnboardOS — Screens & Navigation

## 1. Application shells

### A. Admin / Operations Command Center
Primary internal app for staff.

### B. Paying-Client Operations Dashboard
Branded, minimal, progress-first experience for the client.

### C. Platform Admin (us)
Manage all orgs, billing, white-label partners (internal only).

---

## 2. Admin navigation

```
Dashboard
Exception Inbox
Onboardings
Clients
Templates
Workflows
Integrations
Analytics
Knowledge Base
Settings
  ├── Organization
  ├── Branding
  ├── Team & Roles
  ├── Billing
  └── AI Preferences
```

---

## 3. Admin screens (exact)

### 3.1 Dashboard
**Purpose:** At-a-glance operational health.

Widgets:
- Active Onboardings (count)
- At Risk
- Blocked
- Awaiting Client
- Ready for Kickoff
- Completed This Month
- Average TTV (days)
- Funnel mini-chart
- Recent activity feed

### 3.2 Exception Inbox (killer screen)
**Purpose:** Single place for “needs attention”.

List items sorted by severity:
- 🔴 Blocked > N days
- 🟠 Payment pending after signature
- 🟠 Scope change requested
- 🔴 Kickoff tomorrow + intake incomplete
- 🟡 Client inactive 48h+

Each row expands to:
- Why it matters
- What AI already tried
- Recommended action
- Buttons: Approve AI action | Handle manually | Snooze

### 3.3 Onboardings table
Columns: Client | Stage | Health | Progress % | Blocker | Owner | Last activity | Actions

Filters: status, health, owner, template, date range.

### 3.4 Onboarding detail (command view)
Tabs / sections:
- Overview (status, health score + explanation, progress, timeline)
- Stages & Tasks (client + internal, dependencies visible)
- Documents
- Forms / Submissions
- Contracts & Payments
- Meetings
- Messages
- Approvals
- AI Summary & Risks
- Activity / Audit

Actions: Invite client, Transition status, Run workflow, Assign owner, Pause/Cancel.

### 3.5 Client profile
- Overview
- Contacts
- Company
- All onboardings
- Contracts / Payments history
- Documents
- Messages
- Timeline
- Integrations status
- AI brief

### 3.6 Template builder
- Visual stage/task editor
- Dependency edges
- Conditional branches
- Form / document request attach
- Default messages
- AI instructions panel
- Preview as client

### 3.7 Workflow builder
- Trigger → nodes canvas (or linear for V1)
- Condition / wait / action / approval nodes
- Test run against sample instance

### 3.8 Integrations
- Connect / disconnect cards (Google, Microsoft, Stripe, PandaDoc, Calendly, HubSpot, Twilio, Slack…)
- Status, last sync, error log

### 3.9 Analytics
- Funnel (signed → paid → intake → kickoff → live)
- Bottleneck heat map
- Client-caused vs internal delay
- Most missing items
- TTV distribution
- Completion rate by template / package

### 3.10 Knowledge Base
- SOPs, FAQs, policies, service descriptions
- Used by AI Q&A (grounded)

### 3.11 Settings
- Org profile & branding (logo, colors, custom domain)
- Team members & role assignment
- AI permission levels
- SLA defaults
- Quiet hours / channels
- Data retention

---

## 4. Paying-client dashboard navigation

Minimal top bar:
- Progress indicator
- Help / Ask AI
- Profile / Logout

Main areas (bottom or side nav if needed):
```
Home
Tasks
Forms
Documents
Agreements
Payments
Meetings
Messages
Approvals
Resources
Timeline
Support
```

---

## 5. Paying-client dashboard screens

### 5.1 Home (first impression)
```
Welcome to Acme Media.

Your onboarding is 68% complete
Estimated time remaining: 14 minutes

Your next steps
1. Complete business questionnaire     ✓ Done
2. Upload brand assets                 ✓ Done
3. Connect Google Analytics            ⚠ Action required
4. Schedule kickoff                    ✓ Booked
5. Sign service agreement              ✓ Done

Timeline
✓ Welcome → ✓ Contract → ✓ Payment → ✓ Questionnaire
→ Access collection → ○ Kickoff → ○ Implementation → ○ Launch

Need help? Ask Onboard AI
```

### 5.2 Tasks
Only client-visible tasks. Clear CTA, due date, status.

### 5.3 Forms
One form at a time or list of required forms. Progress save.

### 5.4 Documents
Upload zones with accepted types, validation status after AI analysis.

### 5.5 Agreements
View / sign via embedded PandaDoc / DocuSign or hosted link.

### 5.6 Payments
Outstanding amount, pay now (Stripe), history.

### 5.7 Meetings
Book / reschedule (Calendly embed or Google).

### 5.8 Messages
Threaded conversation with the team + AI.

### 5.9 Approvals
List of items needing Approve / Request changes / Comment / Attach.

### 5.10 Resources
Guides, videos, FAQs (from knowledge base).

### 5.11 Timeline
Readable history of everything that happened.

### 5.12 Support / Ask AI
Chat interface grounded in org knowledge + current onboarding state.

---

## 6. Key UX principles

1. **Client never sees a giant confusing dashboard** — next action first.
2. **Health & blockers are explainable** — not mysterious scores.
3. **Exception Inbox > generic task lists** for internal users.
4. **Realtime** — no refresh to see progress or new messages.
5. **Responsive** for paying-client dashboard; end-customer workspace is mobile-first.
6. **Branded** — client feels they are inside the service business’s world, not a third-party tool.
7. **Estimated time remaining** reduces abandonment.
8. **Clear separation** of client-visible vs internal tasks.

---

## 7. Screen priority for V1

Must ship:
- Admin Dashboard
- Exception Inbox
- Onboardings list + detail
- Client Home + Tasks + Forms + Documents + Payments + Meetings
- Basic Settings (org, team, branding)

Can follow quickly:
- Template builder (can start with JSON / form)
- Workflow builder (start with predefined + simple editor)
- Full Analytics
- Knowledge Base UI

## V2.4 Documents & Billing

Client Dashboard: Documents, Agreements, Invoices, Payments, Templates, Commercial Flows.

Operator screens: Template Library, Template Editor, Import & Mapping, Document Preview, Invoice Editor, Billing Settings, Commercial Flow Builder, Per-Customer Flow Override, Signature/Payment Activity, Document Audit.

## V2.5 — Manual Customer Creation & Flow Activation

### Create Customer
Guided wizard for entering a new end customer manually, including identity, contacts, business information, commercial context and custom fields.

### Choose Flow
Selectable cards for OnboardOS starter flows, tenant global flows, service flows, customer-specific customization and from-scratch flow building.

### Activation Review
A final preview of every external and internal action that will occur after activation: agreements, invoices, payment links, forms, reminders, integrations, assignments and next steps.

### Customer Profile
Stores identity, contacts, business, billing, commercial data, custom fields and all onboarding instances.
