# OnboardOS — Database Schema

**Engine:** PostgreSQL 16  
**ORM recommendation:** Prisma  
**Multi-tenancy:** Every tenant table has `organization_id` + RLS policies.

---

## 1. Core entities (summary)

| Entity | Purpose |
|--------|---------|
| organizations | Tenants |
| users / memberships | People + roles inside orgs |
| roles / permissions | RBAC |
| clients / client_contacts | Onboarded customers |
| onboarding_templates | Reusable blueprints |
| onboarding_instances | Live onboardings |
| stages | Ordered phases inside an instance |
| tasks | Client + internal work items |
| task_dependencies | Graph edges |
| forms / form_submissions | Intake |
| documents / document_requests | File collection + validation |
| contracts / signatures | Agreements |
| payments / invoices | Money |
| appointments | Kickoffs & meetings |
| messages / threads | Communication |
| approvals | Review cycles |
| integrations / credentials | Connected tools |
| workflows / runs / steps | Automation definitions & history |
| events | Event store |
| webhooks | Outbound + inbound |
| ai_agents / ai_runs / ai_actions | Intelligence layer |
| notifications | In-app + push |
| escalations | Escalation records |
| audit_logs | Immutable audit trail |
| knowledge_sources / chunks | RAG for AI |
| metrics | Aggregated analytics |

---

## 2. Key tables (detailed)

### organizations
```
id              uuid PK
name            text
slug            text unique
plan            enum (launch, pro, revenue, white_label, enterprise)
settings        jsonb
branding        jsonb          -- logo, colors, domain
parent_org_id   uuid nullable  -- white-label hierarchy
created_at      timestamptz
updated_at      timestamptz
```

### users
```
id              uuid PK
email           text unique
name            text
avatar_url      text
created_at      timestamptz
```

### organization_memberships
```
id              uuid PK
organization_id uuid FK
user_id         uuid FK
role_id         uuid FK
status          enum (active, invited, suspended)
created_at      timestamptz
```

### roles
```
id              uuid PK
organization_id uuid FK nullable  -- null = system role
name            text              -- Platform Owner, Admin, Manager, ...
permissions     text[]            -- or join table
```

### clients
```
id              uuid PK
organization_id uuid FK
name            text
external_id     text              -- CRM id
status          enum
health_score    int 0-100
risk_level      enum (low, medium, high, critical)
owner_id        uuid FK           -- account manager
metadata        jsonb
created_at      timestamptz
updated_at      timestamptz
```

### client_contacts
```
id              uuid PK
client_id       uuid FK
name            text
email           text
phone           text
role            text              -- decision maker, technical, billing
is_primary      boolean
preferred_channel enum (email, sms, whatsapp)
consent         jsonb
```

### onboarding_templates
```
id              uuid PK
organization_id uuid FK
name            text
description     text
vertical        text              -- agency, msp, accounting, ...
version         int
config          jsonb             -- stages, tasks, forms, rules, AI instructions
is_active       boolean
created_at      timestamptz
```

### onboarding_instances
```
id              uuid PK
organization_id uuid FK
client_id       uuid FK
template_id     uuid FK
status          enum (see state machine)
health_score    int
progress_pct    numeric
current_stage_id uuid
started_at      timestamptz
completed_at    timestamptz
ttv_days        numeric
metadata        jsonb
created_at      timestamptz
updated_at      timestamptz
```

### stages
```
id              uuid PK
instance_id     uuid FK
template_stage_key text
name            text
order_index     int
status          enum (pending, active, completed, skipped)
started_at      timestamptz
completed_at    timestamptz
```

### tasks
```
id              uuid PK
instance_id     uuid FK
stage_id        uuid FK
key             text
title           text
description     text
type            enum (client, internal, system)
visibility      enum (client, internal, both)
status          enum (todo, in_progress, blocked, completed, skipped, cancelled)
owner_id        uuid FK nullable
assignee_type   enum (client_contact, internal_user, system)
due_at          timestamptz
completed_at    timestamptz
priority        enum (low, medium, high, critical)
sla_hours       int
is_blocking     boolean
metadata        jsonb             -- form_id, document_request_id, etc.
created_at      timestamptz
updated_at      timestamptz
```

### task_dependencies
```
id              uuid PK
task_id         uuid FK           -- dependent
depends_on_task_id uuid FK
type            enum (blocks, soft)
```

### forms
```
id              uuid PK
organization_id uuid FK
name            text
schema          jsonb             -- JSON Schema / form builder output
version         int
```

### form_submissions
```
id              uuid PK
form_id         uuid FK
instance_id     uuid FK
task_id         uuid FK
submitted_by    uuid
data            jsonb
ai_extracted    jsonb
status          enum
created_at      timestamptz
```

### documents
```
id              uuid PK
organization_id uuid FK
client_id       uuid FK
instance_id     uuid FK
task_id         uuid FK
name            text
storage_path    text
mime_type       text
size_bytes      bigint
uploaded_by     uuid
ai_analysis     jsonb             -- extraction results
validation_status enum (pending, valid, invalid, partial)
created_at      timestamptz
```

### document_requests
```
id              uuid PK
instance_id     uuid FK
task_id         uuid FK
title           text
required        boolean
accepted_types  text[]
validation_rules jsonb
status          enum
```

### contracts
```
id              uuid PK
instance_id     uuid FK
provider        enum (pandadoc, docusign, internal)
external_id     text
status          enum (draft, sent, viewed, signed, declined, expired)
signed_at       timestamptz
document_url    text
metadata        jsonb
```

### payments
```
id              uuid PK
instance_id     uuid FK
provider        enum (stripe)
external_id     text
amount_cents    int
currency        text
status          enum (pending, paid, failed, refunded)
paid_at         timestamptz
invoice_url     text
```

### appointments
```
id              uuid PK
instance_id     uuid FK
task_id         uuid FK
provider        enum (google, calendly)
external_id     text
starts_at       timestamptz
ends_at         timestamptz
status          enum
attendees       jsonb
```

### messages
```
id              uuid PK
thread_id       uuid FK
instance_id     uuid FK
channel         enum (email, sms, whatsapp, in_app, slack)
direction       enum (inbound, outbound)
from_address    text
to_address      text
body            text
status          enum
provider_id     text
sent_at         timestamptz
ai_summary      text
sentiment       enum
```

### approvals
```
id              uuid PK
instance_id     uuid FK
task_id         uuid FK
title           text
status          enum (pending, approved, rejected, changes_requested)
requested_from  uuid
decided_by      uuid
comment         text
decided_at      timestamptz
```

### workflows
```
id              uuid PK
organization_id uuid FK
name            text
trigger         jsonb
definition      jsonb             -- nodes: trigger → condition → action → wait
is_active       boolean
```

### workflow_runs
```
id              uuid PK
workflow_id     uuid FK
instance_id     uuid FK
status          enum
started_at      timestamptz
finished_at     timestamptz
error           text
```

### events
```
id              uuid PK
organization_id uuid FK
instance_id     uuid FK nullable
type            text              -- namespaced event type
payload         jsonb
actor_type      enum (user, system, ai, integration)
actor_id        text
created_at      timestamptz
```

### ai_runs
```
id              uuid PK
organization_id uuid FK
instance_id     uuid FK
agent           text              -- onboard_agent, document_intel, ...
input           jsonb
output          jsonb
tokens_used     int
status          enum
created_at      timestamptz
```

### ai_actions
```
id              uuid PK
ai_run_id       uuid FK
action_type     text
permission_level int 0-4
status          enum (draft, approved, executed, rejected)
executed_at     timestamptz
```

### audit_logs
```
id              uuid PK
organization_id uuid FK
actor_id        uuid
actor_type      text
action          text
resource_type   text
resource_id     text
before          jsonb
after           jsonb
ip              text
user_agent      text
source          text              -- ui, api, ai, workflow
created_at      timestamptz
```

### knowledge_sources
```
id              uuid PK
organization_id uuid FK
name            text
type            enum (sop, faq, policy, service, guide)
content         text
```

### knowledge_chunks
```
id              uuid PK
source_id       uuid FK
content         text
embedding       vector(1536)      -- pgvector
metadata        jsonb
```

---

## 3. Indexes (critical)

- All FK columns
- `(organization_id, status)` on onboarding_instances, tasks
- `(instance_id, status)` on tasks
- `(organization_id, created_at)` on events, audit_logs
- GIN on jsonb columns used for filtering
- Vector index on knowledge_chunks.embedding

---

## 4. RLS pattern (example)

```sql
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;

CREATE POLICY clients_tenant_isolation ON clients
  USING (organization_id = current_setting('app.current_org_id')::uuid);
```

Set `app.current_org_id` from JWT claims in every request.

---

## 5. Soft deletes & retention

Prefer `deleted_at` on most entities.  
Hard delete only via explicit data-retention / GDPR jobs with full audit.

---

## v2 required entities

The original schema summary must be extended with:

```text
organization_memberships
onboarding_template_versions
workflow_versions
form_versions
requirements
requirement_evidence
requirement_verifications
readiness_gates
readiness_gate_results
engagements
deal_snapshots
scope_versions
promise_register
scope_change_requests
document_versions
document_analysis
document_verifications
message_attempts
delivery_events
channel_consents
approval_versions
workflow_run_steps
workflow_waits
outbox_messages
webhook_deliveries
idempotency_keys
exceptions
exception_actions
sla_policies
integration_connections
integration_events
sync_mappings
sync_conflicts
ai_agent_versions
ai_evidence
ai_evaluations
security_events
operational_read_models
```

Every live onboarding must pin template/workflow/form/policy versions. Derived state must be rebuildable.

See `14-domain-model-v2/DOMAIN-MODEL.md` and `13-production-hardening/PRODUCTION-ARCHITECTURE.md`.

## V2.4 Document & Billing Engine additions

Add first-class entities for DocumentTemplate, DocumentTemplateVersion, DocumentInstance, DocumentApproval, SignatureEnvelope, Invoice, InvoiceLine, PaymentRequest, Payment, CreditNote, Receipt, BillingPolicy, CommercialFlow, CommercialFlowVersion, CommercialFlowNode, ClientFlowOverride, NumberingSequence, TaxProfile, and DocumentAuditEvent.

Every document/invoice references an immutable template/flow version. Global policies are inherited; service policies override global; explicit end-customer overrides override service policy. Existing onboardings pin resolved versions.
