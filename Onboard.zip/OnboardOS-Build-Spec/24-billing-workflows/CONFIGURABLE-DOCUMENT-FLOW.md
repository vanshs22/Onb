# OnboardOS — Configurable Document & Billing Flow

## Requirement
A paying OnboardOS client must be able to configure how commercial documents participate in onboarding globally and per end-customer.

## Global policy
Example:
1. Send agreement
2. Wait for signature
3. Send invoice
4. Wait for payment
5. Release onboarding intake
6. Collect documents
7. Schedule kickoff

## Alternative global policy
1. Send agreement + invoice together
2. Allow client to sign and pay independently
3. Start intake only after both are complete

## Per-customer override
A specific end-customer can override the global policy:
- Agreement first
- Invoice first
- Agreement + invoice together
- Agreement → payment request
- Invoice → agreement
- Custom sequence

The override is explicitly recorded and visible to authorized operators.

## Flow builder
Visual nodes:
- Send Agreement
- Wait for Signature
- Send Invoice
- Wait for Payment
- Send Payment Request
- Send Intake
- Request Document
- Request Integration
- Send Reminder
- Wait
- Approval
- Condition
- Branch
- Human Review
- Create Task
- Schedule Meeting
- Activate Stage
- End

## Node configuration
Every node supports:
- template selection
- recipient selection
- delay
- due date
- retry policy
- reminder policy
- blocking/non-blocking behavior
- condition
- approval requirement
- escalation
- fallback channel
- timezone
- business-hours policy

## Sequence examples

### A. Agreement → Invoice
Send agreement → signed → invoice → paid → intake.

### B. Invoice → Agreement
Send invoice → paid → agreement → signed → intake.

### C. Parallel
Send agreement + invoice → wait for both → intake.

### D. Agreement + deposit
Send agreement → signed → deposit invoice → paid → kickoff scheduling.

### E. Flexible commercial flow
Send proposal → accepted → generate agreement → sign → generate invoice → pay → create onboarding.

## Blocking semantics
A node may be:
- Required blocker
- Required but non-blocking
- Optional
- Informational

Example: agreement and deposit are required blockers; welcome email is informational.

## Per-client resolution algorithm
1. Load tenant global policy.
2. Load service/product policy.
3. Load client override if present.
4. Resolve precedence: explicit client override > service policy > tenant global policy > system default.
5. Pin the resolved workflow version to the onboarding.
6. Execute from the pinned version.

Changing the global policy must never mutate an onboarding already in progress unless an authorized migration is performed.

## Automation behavior
After each event, evaluate the current node and dependencies. Only one idempotent execution may claim a node action. Provider webhooks confirm external state.

## Reminder engine
Configurable examples:
- 24h before due date
- on due date
- 2 days overdue
- 5 days overdue → escalation

Avoid duplicate reminders and respect communication preferences/opt-outs.

## UI
Global settings:
`Settings → Commercial Flows`

Per-client:
`Client → Onboarding → Flow → Override`

Show a visual explanation:
`Global policy → Service policy → This client override`

## Audit
Record who changed the flow, old version, new version, reason, affected client/onboarding, timestamp and approval if required.
