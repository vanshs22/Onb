# OnboardOS v3 — Agentic Acceptance Tests

## A. End-to-end autonomous onboarding

1. Deal-won event creates onboarding.
2. Deal-to-Delivery Agent reads configured sources.
3. Promise Graph is created with provenance.
4. Requirement Planner creates dynamic requirements.
5. Commercial Agent executes agreement/payment steps through adapters.
6. End customer receives workspace.
7. Intake Agent parses responses.
8. Evidence Agent validates uploads.
9. Chase Agent sends an authorized reminder when a requirement is late.
10. Risk Agent identifies a blocked dependency.
11. Exception Agent attempts bounded recovery.
12. Scheduling Agent books kickoff.
13. Implementation Agent creates downstream delivery work.
14. Scope Agent detects an out-of-scope request.
15. Approval Agent obtains approval for change order.
16. Activation Agent verifies service-specific activation gates.
17. Handoff Agent creates handoff package.
18. Learning Agent creates an improvement proposal.

## B. Agent safety

- Agent cannot call a tool outside its allowlist.
- Agent cannot cross tenant boundaries.
- Agent cannot approve its own human-required action.
- Agent cannot mark a side effect complete without verification.
- Agent cannot access secrets through model context.
- Agent cannot publish workflow/policy changes without approval.

## C. Reliability

- Duplicate event does not duplicate side effects.
- Provider timeout retries according to policy.
- Provider outage creates recoverable exception.
- Job replay produces the same idempotent result.
- Webhook replay is safe.
- Stale write returns 409.
- Realtime client converges to server truth.

## D. Explainability

Every consequential agent action exposes:

- objective
- evidence
- confidence
- policy decision
- selected tool
- input summary
- provider result
- verification
- actor/agent
- model/prompt version
- cost

## E. Customer isolation

A paying client cannot see:

- internal staff notes
- provider secrets
- internal AI traces
- another tenant's customer data
- internal health formulas
- restricted exceptions

## F. Simulator

Before publishing a flow:

- all required nodes validate
- unreachable nodes are detected
- missing variables are detected
- approval requirements are detected
- potential infinite loops are rejected
- provider actions are shown as side effects
- sample event replay completes without schema errors

## G. Activation

An onboarding cannot transition to ACTIVATED unless every required activation gate is VERIFIED or explicitly waived under policy with an auditable approval.
