# OnboardOS v3 — Agentic Onboarding Operations OS

## Purpose

This release turns OnboardOS from an onboarding workflow product into an **agentic execution system**. Agents do not merely recommend work: they select authorized tools, execute actions through the durable workflow runtime, verify the result, and hand off to another agent or human when policy requires it.

## Product identity

> **From Deal Won to Customer Activated — automatically, with proof.**

The system's canonical chain is:

**Promise → Scope → Requirement → Evidence → Verification → Dependency → Execution → Approval → Activation → Outcome → Learning**

## 12 major systems

1. **Deal-to-Delivery Compiler** — converts CRM/deal/proposal/SOW/contract/sales notes/call transcripts into a normalized delivery brief.
2. **Promise & Scope Graph** — records commitments, deliverables, constraints, dates and provenance; detects conflicts and scope drift.
3. **Onboarding Twin** — live operational graph for every customer containing state, requirements, evidence, dependencies, actors, risks, events and outcome.
4. **Requirement + Evidence Engine** — requirement-aware collection, validation and provenance instead of checkbox completion.
5. **Scope Drift + Change Order Engine** — detects work outside agreed scope and can create a change-order proposal subject to policy.
6. **Agent Workforce** — specialized agents collaborate through typed tools and durable jobs.
7. **Workflow Simulator** — dry-runs flows, predicts branches, side effects, approvals and failure points before activation.
8. **Customer Friction Analytics** — measures customer effort, stalls, repeated requests and problematic steps.
9. **Activation + Outcome Engine** — defines service-specific activation criteria and verifies first value, not just onboarding completion.
10. **Portfolio Intelligence** — bottlenecks, forecasts, root causes, workload, SLA risk and recommended interventions.
11. **Workflow Experimentation** — versioned A/B or controlled workflow experiments with outcome measurement.
12. **Connector + MCP/API Fabric** — durable integrations, typed actions, webhooks, generic HTTP/OAuth, MCP and event subscriptions.

## Agent collaboration model

Agents never directly mutate the database or call arbitrary provider APIs. They operate through the **Agent Execution Gateway**.

```text
Event / Schedule / Human Request
            ↓
      Agent Orchestrator
            ↓
   Context + Policy Resolver
            ↓
       Agent Planner
            ↓
   Typed Tool Authorization
            ↓
       Durable Job Queue
            ↓
      Tool / Workflow Step
            ↓
        Provider / DB
            ↓
       Result Verification
            ↓
      Onboarding Twin update
            ↓
  Next agent / Human / Complete
```

### Collaboration protocol

Every agent result uses:

```json
{
  "run_id": "uuid",
  "agent": "evidence-agent",
  "goal": "verify_required_business_registration",
  "observation": "document_uploaded",
  "evidence": ["evidence://document/123"],
  "inference": "document appears valid but legal name differs",
  "confidence": 0.96,
  "proposed_actions": [
    {"tool": "request_human_review", "reason": "legal_name_mismatch"}
  ],
  "policy_decision": "approval_required",
  "handoff": "exception-agent",
  "state_patch": {"requirement_status": "needs_review"}
}
```

The orchestrator validates the schema, policy and authorization before execution.

## Agent roster

### 1. Orchestrator Agent
Owns the current objective and delegates to specialized agents. It cannot bypass policy or execute provider side effects itself.

### 2. Deal-to-Delivery Agent
Builds the Client Brief and Promise Graph from sales context.

### 3. Requirement Planner Agent
Creates and adapts requirements based on service, scope, customer type, answers and dependencies.

### 4. Intake Agent
Reads forms and messages, maps answers to structured fields, detects contradictions and requests clarification.

### 5. Evidence Agent
Extracts and validates evidence, identifies missing/expired/contradictory evidence and produces provenance.

### 6. Commercial Agent
Coordinates agreement, invoice, payment and commercial dependencies through approved connectors.

### 7. Chase Agent
Chooses the least intrusive authorized channel and sends contextual requests/reminders.

### 8. Scheduling Agent
Finds available slots, schedules meetings and reschedules within policy.

### 9. Scope Agent
Compares requested work with promise/contract/SOW and proposes a change order when needed.

### 10. Implementation Agent
Creates downstream tasks, tickets, project records and configuration actions after readiness gates pass.

### 11. Approval Agent
Collects required human/customer approvals and prevents unauthorized progression.

### 12. Risk Agent
Continuously evaluates blockers, inactivity, deadlines, sentiment, provider health and dependency chains.

### 13. Exception Agent
Owns failed automation and attempts bounded recovery: retry, alternate provider, re-plan, request human intervention or escalate.

### 14. Activation Agent
Evaluates final readiness and verifies service-specific activation outcomes.

### 15. Handoff Agent
Builds the delivery-to-success handoff, summarizes history, outstanding risks and success criteria.

### 16. Learning Agent
Analyzes completed onboarding data and proposes workflow/template/policy improvements; it never publishes changes without approval.

### 17. Customer Concierge Agent
Runs inside the end-customer workspace and answers only from authorized customer-visible knowledge/state.

## Agent memory

Agents use three memory scopes:

- **Run memory:** current execution context; expires after completion.
- **Onboarding memory:** facts/evidence/events for one customer engagement.
- **Organization memory:** approved policies, templates, terminology and historical patterns.

No agent may treat unverified model-generated text as durable business truth.

## Agent permissions

Permissions are action-specific, not agent-wide.

| Level | Capability |
|---|---|
| Observe | Read authorized context |
| Draft | Prepare an action for approval |
| Low-risk Execute | Send reminders, create tasks, update non-critical metadata |
| Workflow Execute | Execute actions explicitly approved by an active workflow |
| Consequential | Payment/refund/contract/data deletion; human approval by default |
| Restricted | Security, credential, tenant, policy or irreversible operations; human/admin only |

## Agent handoffs

Handoffs are explicit events, never hidden prompt chaining.

Examples:

```text
Deal-to-Delivery
 → Requirement Planner
 → Evidence Agent
 → Risk Agent
 → Chase Agent
 → Evidence Agent
 → Approval Agent
 → Implementation Agent
 → Activation Agent
 → Handoff Agent
```

A handoff contains objective, context references, required evidence, prior attempts, failure reason, allowed tools and deadline.

## Execution guarantees

- Every side effect has an idempotency key.
- Every job is durable and retryable.
- Every provider response is persisted.
- Every consequential action is auditable.
- Every agent run records model, prompt, policy, tools, evidence, cost and outcome.
- Verification occurs after side effects.
- Provider failures enter retry/DLQ/reconciliation paths.
- An agent cannot claim success without a verification result.
- Human approval gates are enforced server-side.

## Example autonomous run

**Goal:** onboard a new $20k website + SEO customer.

1. CRM `deal.won` arrives.
2. Deal-to-Delivery Agent reads deal, proposal, SOW and sales notes.
3. Promise Graph records website, SEO, Analytics and launch commitments.
4. Requirement Planner creates required intake, assets, access and commercial requirements.
5. Commercial Agent generates agreement and deposit invoice from approved templates.
6. Agreement provider webhook reports signed; payment provider reports paid.
7. Intake Agent parses customer answers and discovers that Google Ads is required.
8. Requirement Planner adds Google Ads access requirement.
9. Chase Agent requests access using the customer's preferred channel.
10. Evidence Agent verifies the submitted access/evidence.
11. Risk Agent sees kickoff deadline approaching but one access requirement is missing.
12. Chase Agent sends a contextual reminder; after policy threshold, Exception Agent escalates.
13. Requirement becomes satisfied.
14. Scheduling Agent books kickoff.
15. Implementation Agent creates downstream delivery work.
16. Scope Agent detects an extra landing page request outside the SOW and proposes a change order instead of silently accepting it.
17. Approval Agent gets client approval.
18. Implementation continues.
19. Activation Agent checks service-specific activation criteria.
20. Handoff Agent packages the complete operational history for customer success.
21. Learning Agent records delay/friction signals for future optimization.

## Hard rule

**Agents are workers inside the OnboardOS control plane, not independent chatbots.** The workflow runtime remains the durable source of execution state; agents provide planning, interpretation and bounded action selection.
