# OnboardOS v3 — Multi-Agent Collaboration Protocol

## Goal

Agents are a coordinated workforce, not isolated chatbots. The runtime guarantees that agents can discover work, claim bounded objectives, execute through authorized tools, verify results and hand work to the next specialist.

## Coordination model

```text
                     Agent Orchestrator
                            │
              ┌─────────────┼─────────────┐
              ↓             ↓             ↓
          Planner       Risk Monitor   Event Router
              │
       Durable Objective Queue
              │
     ┌────────┼─────────┐
     ↓        ↓         ↓
  Agent A   Agent B   Agent C
     │        │         │
     └───── evidence/state ─────┘
              │
        Execution Gateway
              │
        Verification
              │
       Onboarding Twin
              │
       Next Objective
```

## Objective lifecycle

`DISCOVERED → CLAIMED → PLANNED → AUTHORIZED → QUEUED → RUNNING → VERIFYING → COMPLETED`

Alternative terminal/recovery states:

`WAITING_APPROVAL`, `WAITING_EVENT`, `WAITING_EXTERNAL`, `RETRYING`, `BLOCKED`, `ESCALATED`, `CANCELLED`, `FAILED`

## Concurrency

- Agents may concurrently read context and perform explicitly safe observations.
- Only one conflicting state mutation may commit against a version at a time.
- Every mutation uses an idempotency key and optimistic concurrency version.
- A failed commit returns a conflict and forces context refresh/re-plan.
- Consequential external actions are serialized by the workflow/runtime policy.

## Shared state rules

Agents never share hidden prompt memory as system state. They communicate using durable references:

- onboarding ID
- objective ID
- requirement IDs
- evidence IDs
- event IDs
- exception IDs
- approval IDs
- connector execution IDs
- prior run IDs

Model-generated statements become durable truth only after the applicable verification or human approval.

## Handoff contract

```json
{
  "objective_id": "uuid",
  "handoff_id": "uuid",
  "from_agent": "risk-agent",
  "to_agent": "chase-agent",
  "goal": "obtain_missing_ga_access",
  "context_refs": ["requirement://123", "risk://456"],
  "allowed_tools": ["message.send", "requirement.lookup"],
  "deadline": "2026-10-04T12:00:00Z",
  "attempt": 2,
  "policy_state": "preapproved_low_risk",
  "success_condition": "requirement_verified"
}
```

## Supervisor behavior

The orchestrator must:

1. prevent duplicate objective claims;
2. detect deadlocks and dependency cycles;
3. cancel obsolete objectives when source state changes;
4. re-plan after verified failures;
5. enforce budgets and deadlines;
6. surface repeated failures to the Exception Agent;
7. request human intervention when policy requires it;
8. never bypass a blocked approval by routing around it.

## Agent team example

For a new website customer:

`Deal Agent` extracts promises → `Requirement Agent` creates requirements → `Commercial Agent` handles signature/payment → `Intake Agent` structures responses → `Evidence Agent` verifies assets → `Risk Agent` watches deadlines → `Chase Agent` requests missing evidence → `Scheduling Agent` books kickoff → `Implementation Agent` creates delivery work → `Scope Agent` handles new requests → `Approval Agent` obtains approvals → `Activation Agent` verifies first value → `Handoff Agent` transfers context → `Learning Agent` proposes process improvements.

The agents can continue autonomously while no protected gate is blocked. They stop and persist state when a human decision is required.
