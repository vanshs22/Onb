# OnboardOS v3 — Agent Execution Runtime

## Objective

Provide a concrete runtime contract that makes agents **work together and perform tasks**, rather than only producing recommendations.

## Core components

```text
Event Bus
   ↓
Agent Orchestrator
   ├── Context Resolver
   ├── Policy Resolver
   ├── Planner
   ├── Tool Authorizer
   ├── Handoff Manager
   └── Budget Manager
          ↓
Durable Agent Job Queue
          ↓
Tool Executor
   ├── OnboardOS domain tools
   ├── Integration adapters
   ├── Communication tools
   ├── Document/billing tools
   └── Generic API/MCP tools
          ↓
Verification Engine
          ↓
Event + State Store
          ↓
Next Best Action / Handoff
```

## Typed tool contract

Each tool has:

- name/version
- input JSON Schema
- output JSON Schema
- permission level
- supported tenant scopes
- idempotency requirement
- side-effect classification
- retry strategy
- verification strategy
- audit category

Example:

```json
{
  "name": "commercial.create_invoice",
  "version": "1.0",
  "permission": "workflow_execute",
  "side_effect": "financial",
  "requires_approval": true,
  "idempotency": "required",
  "verify_with": "commercial.invoice_status"
}
```

## Required domain tools

### Customer
- `customer.create`
- `customer.update`
- `customer.lookup`

### Requirements
- `requirement.create`
- `requirement.update`
- `requirement.satisfy`
- `requirement.block`

### Evidence
- `evidence.request`
- `evidence.inspect`
- `evidence.verify`
- `evidence.reject`

### Communication
- `message.draft`
- `message.send`
- `message.schedule`
- `message.escalate`

### Commercial
- `agreement.generate`
- `agreement.send`
- `invoice.generate`
- `payment.request`
- `payment.status`
- `change_order.generate`

### Scheduling
- `meeting.find_slots`
- `meeting.book`
- `meeting.reschedule`

### Delivery
- `task.create`
- `project.create`
- `ticket.create`
- `approval.request`
- `approval.record`

### Intelligence
- `risk.evaluate`
- `scope.compare`
- `activation.evaluate`
- `friction.analyze`

### Recovery
- `job.retry`
- `job.replay`
- `connector.failover`
- `exception.create`
- `exception.resolve`

## Agent execution state machine

```text
PLANNED
  ↓
AUTHORIZED
  ↓
QUEUED
  ↓
RUNNING
  ├── RETRYING
  ├── WAITING_APPROVAL
  ├── WAITING_EVENT
  ├── WAITING_EXTERNAL
  ↓
SIDE_EFFECT_APPLIED
  ↓
VERIFYING
  ├── VERIFIED → COMPLETED
  └── FAILED → RECOVERY / EXCEPTION
```

## Autonomous loop

```text
observe()
→ identify_gap()
→ select_next_action()
→ policy_check()
→ authorize_tool()
→ execute()
→ verify()
→ update_twin()
→ emit_event()
→ handoff_or_continue()
```

The loop is bounded by:

- maximum steps
- time budget
- cost budget
- action budget
- policy restrictions
- workflow deadline
- human approval gates

## Agent-to-agent coordination

Agents communicate using durable `agent_handoff.created` events. No hidden in-memory agent state may be required for correctness.

### Handoff payload

```json
{
  "handoff_id": "uuid",
  "from_agent": "risk-agent",
  "to_agent": "chase-agent",
  "objective": "obtain_google_analytics_access",
  "onboarding_id": "uuid",
  "context_refs": ["requirement://123", "risk://456"],
  "attempts": 2,
  "deadline": "2026-10-04T12:00:00Z",
  "allowed_tools": ["message.send", "requirement.lookup"],
  "approval_state": "preapproved_low_risk"
}
```

## Human takeover

A human can pause, cancel, retry, replay, approve, reject, override or reassign an agent run. The system records the reason and actor.

## Connector execution

All external calls pass through adapters with:

- credential vault reference
- tenant scope
- timeout
- rate limit
- idempotency
- provider request ID
- response persistence
- verification query
- health state

## Failure handling

Provider timeout:
`retry → alternate provider if configured → exception → human`

Validation failure:
`reject → request correction → re-inspect`

Conflicting evidence:
`pause → request clarification → human review if unresolved`

Agent budget exceeded:
`pause → human approval or deterministic fallback`

Unknown tool result:
`do not mark complete`

## Security requirements

- Tool allowlists are server-side.
- Agent prompts cannot grant permissions.
- Agent-generated tool arguments are schema-validated.
- Tenant identity comes from authenticated execution context, never model output.
- Secrets are never placed in prompts.
- Customer-visible agents cannot access internal-only notes.
