# OnboardOS v2.3 — Product Surfaces Decision

## Definitive terminology

OnboardOS has three surfaces backed by one core onboarding engine:

1. **Internal Command Center** — operated by OnboardOS staff in Managed mode or by the customer organization in SaaS/White-label mode. It contains deep operational controls, workflow execution, AI controls, exceptions, integrations, audit and repair tools.
2. **Paying-Client Operations Dashboard** — the main dashboard for the business that pays for OnboardOS. This is what “Client Portal” means in commercial/product discussions. It shows onboarding operations, KPIs, pipeline, stage distribution, bottlenecks, exceptions, trends, team performance and AI insights.
3. **End-Customer Onboarding Workspace** — used by the paying client’s customers to actually complete onboarding actions: forms, documents, agreements, payments, integrations, meetings, approvals and messages.

The system must never confuse #2 and #3.

## Paying-Client Dashboard: primary modules

- Overview
- Onboarding pipeline
- All onboardings
- Client/company directory
- Stage analytics
- Bottlenecks
- Exceptions
- SLA / overdue
- Completion and activation analytics
- Team/workload
- AI insights
- Reports
- Integrations health
- Workflow/template visibility
- Settings / users / billing

### Core KPIs

- total onboardings
- active onboardings
- completed onboardings
- activated onboardings
- at-risk onboardings
- stuck onboardings
- overdue onboardings
- average/median time to activate
- completion rate
- activation rate
- stage conversion
- client response time
- team response time
- exception count and resolution time
- SLA compliance
- bottleneck duration

## End-Customer Workspace: primary modules

- Home / next action
- Tasks / requirements
- Forms
- Documents
- Agreements
- Payments
- Connected accounts
- Meetings
- Approvals
- Messages
- Timeline
- Resources
- Ask AI

## Projection rule

```text
Core domain state
      ↓
Policy + authorization
      ↓
┌───────────────┬───────────────────────┐
│ paying-client │ end-customer          │
│ projection    │ projection             │
└───────────────┴───────────────────────┘
      ↓                         ↓
Operations Dashboard       Onboarding Workspace
```

Never expose the internal domain object wholesale.
