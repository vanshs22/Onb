# OnboardOS — Phase-by-Phase Implementation Backlog

## Guiding rules

- Ship a sellable core before expanding.
- Integrate existing tools; do not rebuild them.
- Realtime + state machine + Exception Inbox are non-negotiable early.
- AI starts as assistive; full autonomy comes later with permission levels.

---

## Phase 1 — Foundation (Weeks 1–6)

**Goal:** Multi-tenant core + internal admin + paying-client Operations Dashboard + end-customer workspace + onboarding engine skeleton.

### Deliverables
- [ ] Monorepo setup (web, api, worker, db, shared)
- [ ] PostgreSQL + Prisma schema (orgs, users, memberships, roles, clients, contacts, templates, instances, stages, tasks, dependencies, events, audit_logs)
- [ ] Auth (Supabase Auth / Clerk) + org switcher
- [ ] RBAC middleware + RLS policies
- [ ] Onboarding state machine (controlled transitions)
- [ ] Admin shell + navigation
- [ ] Dashboard (counts + basic table)
- [ ] Onboardings list + detail (stages/tasks view)
- [ ] Paying-client dashboard shell + KPI Home; end-customer workspace shell + next action Home
- [ ] Client tasks list + complete action
- [ ] Activity timeline (event-driven)
- [ ] Basic branding (logo, colors)
- [ ] Audit log writer

**Exit criteria:** Create org → create client → create onboarding from template → client can log in and complete a task → admin sees realtime update.

---

## Phase 2 — Forms, Files, Payments, E-sign, Calendar, Realtime (Weeks 7–12)

### Deliverables
- [ ] Form builder (or JSON schema forms) + submissions
- [ ] Document requests + signed upload/download (S3 / Supabase Storage)
- [ ] Stripe Checkout + webhooks → payment state
- [ ] PandaDoc or DocuSign connect + send + webhook → contract state
- [ ] Calendly / Google Calendar booking + webhook
- [ ] Realtime subscriptions (internal admin + paying-client dashboard + end-customer workspace)
- [ ] Email notifications (transactional provider)
- [ ] End-customer workspace: Forms, Documents, Agreements, Payments, Meetings; paying-client dashboard: pipeline, analytics, exceptions and client detail
- [ ] Exception Inbox v1 (manual + overdue rules)

**Exit criteria:** Full happy path: invite → sign → pay → fill form → upload doc → book kickoff → all reflected in admin + portal without refresh.

---

## Phase 3 — Workflow automation, reminders, escalations (Weeks 13–18)

### Deliverables
- [ ] Workflow definition storage + runner (internal first)
- [ ] Trigger on events (onboarding.created, payment.completed, task.overdue…)
- [ ] Wait / condition / action nodes
- [ ] Smart reminder engine (context-aware copy)
- [ ] Multi-channel: email + basic SMS (Twilio)
- [ ] Escalation rules engine
- [ ] SLA tracking fields + simple breach detection
- [ ] n8n bridge for selected external actions (optional)
- [ ] Template system with conditional stages (package-based)

**Exit criteria:** “Won deal” creates onboarding and automatically chases missing payment / form with escalating reminders; Exception Inbox surfaces real blockers.

---

## Phase 4 — AI Onboarding Manager + Document Intelligence + Health/Risk (Weeks 19–26)

### Deliverables
- [ ] Onboard Agent (missing / blocking / next / auto?)
- [ ] Document Intelligence (extract + validate against rules)
- [ ] Intake analysis (free text → structured + checklist adjustment)
- [ ] Health score calculator + explanation
- [ ] Risk detection agent
- [ ] End-customer AI assistant (grounded) + paying-client AI operations insights
- [ ] AI action permission levels + approval UI
- [ ] ai_runs / ai_actions logging
- [ ] Knowledge base storage + basic RAG

**Exit criteria:** Demo: missing document → risk rises → AI reminder → PDF upload → AI validates coverage amount and flags shortfall.

---

## Phase 5 — Core integrations (Weeks 27–32)

### Deliverables
- [ ] Google Workspace (Gmail send, Drive optional, Calendar)
- [ ] Slack notifications
- [ ] HubSpot (or Pipedrive) deal-won webhook → onboarding
- [ ] WhatsApp via Twilio (templates + consent)
- [ ] Integration connection UI + credential encryption
- [ ] Webhook replay + DLQ tooling

**Exit criteria:** Real CRM “Closed Won” creates fully running onboarding with Slack channel and WhatsApp fallback reminders.

---

## Phase 6 — Analytics, adaptive onboarding, white-label (Weeks 33–40)

### Deliverables
- [ ] Funnel, bottleneck, TTV, completion analytics
- [ ] Adaptive / conditional template UX polished
- [ ] White-label: custom domain, branding, sub-accounts
- [ ] Sales-to-delivery handoff brief
- [ ] Promise / scope detection (v1)
- [ ] Advanced Exception Inbox (AI recommendations + one-click approve)

**Exit criteria:** Partner can white-label; analytics show where clients get stuck; handoff brief auto-generated from CRM + notes.

---

## Phase 7 — Vertical packs + Customer Operations expansion (V2–V3)

### Deliverables
- [ ] Agency, MSP, Accounting, Consulting, Recruitment packs
- [ ] Learning loop from completed onboardings
- [ ] Revenue leak / reactivation modules
- [ ] Full AI Customer Operations OS vision (lead → renewal)
- [ ] Enterprise: SSO, advanced RBAC, audit exports, dedicated env

---

## Explicitly OUT of V1

- Full CRM
- Full accounting
- Full project management
- Custom e-sign infrastructure
- Custom payment processor
- 100 integrations
- Native mobile apps
- Giant AI agent marketplace

---

## Suggested first sprint (Week 1)

1. Repo + CI + staging env
2. Prisma schema for orgs, users, memberships, clients, onboarding_instances, stages, tasks
3. Auth + create org flow
4. Admin “Onboardings” empty state + create from hardcoded template
5. End-customer magic-link/login + “next action” view; paying-client dashboard SSO/session
6. Event emission on task complete → admin sees it

---

## Definition of Done (every phase)

- Tests for state machine transitions
- Audit log on privileged actions
- RLS verified with two orgs
- Realtime verified
- No secrets in frontend
- Runbook for failed webhooks / DLQ

---

## v2 backlog priority correction

Before expanding the AI feature set, implement:

1. Requirement engine
2. Evidence + verification
3. Readiness gates
4. Template/workflow/form version pinning
5. Transactional outbox
6. Webhook delivery persistence
7. Idempotency
8. Optimistic concurrency
9. Exception lifecycle
10. Reconciliation + repair tools
11. Connector health
12. Client Next Best Action UX

Then add advanced AI capabilities.

The complete recommended order is in `17-implementation-v2/BUILD-ORDER.md`.

## V2.4 Product Workstream — Document, Billing & Commercial Flow

P0: Template engine, versioning, DOCX import/mapping, document rendering, e-sign adapter, invoice engine, payment provider adapter, numbering, audit, commercial flow builder, global/service/client precedence, webhook handling, reminders, permissions, PDF QA.
P1: multi-currency/tax, recurring billing, credit notes, accounting sync, branded email, custom domains for hosted documents, localization.
P2: template marketplace, AI clause suggestions with approval, automatic template migration analysis, advanced revenue analytics.
