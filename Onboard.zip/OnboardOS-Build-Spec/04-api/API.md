# OnboardOS — API Specification

**Style:** REST (primary) + optional GraphQL later  
**Auth:** Bearer JWT (org-scoped)  
**Versioning:** `/api/v1/...`  
**Idempotency:** `Idempotency-Key` header on mutating requests that create side-effects.

---

## 1. Auth & session

| Method | Path | Description |
|--------|------|-------------|
| POST | `/auth/login` | Email + password / magic link |
| POST | `/auth/signup` | Create user |
| POST | `/auth/invite` | Invite member to org |
| POST | `/auth/switch-org` | Switch active organization |
| GET | `/auth/me` | Current user + memberships |
| POST | `/auth/logout` | Invalidate session |

---

## 2. Organizations

| Method | Path | Description |
|--------|------|-------------|
| GET | `/orgs` | List orgs for current user |
| POST | `/orgs` | Create org |
| GET | `/orgs/:orgId` | Org details + branding |
| PATCH | `/orgs/:orgId` | Update settings / branding |
| GET | `/orgs/:orgId/members` | List members |
| POST | `/orgs/:orgId/members` | Invite |
| PATCH | `/orgs/:orgId/members/:id` | Change role / status |

---

## 3. Clients

| Method | Path | Description |
|--------|------|-------------|
| GET | `/clients` | List (filter by status, health, owner) |
| POST | `/clients` | Create client |
| GET | `/clients/:id` | Full profile (overview, contacts, timeline) |
| PATCH | `/clients/:id` | Update |
| GET | `/clients/:id/timeline` | Activity feed |
| GET | `/clients/:id/health` | Current health + explanation |

---

## 4. Onboarding templates

| Method | Path | Description |
|--------|------|-------------|
| GET | `/templates` | List |
| POST | `/templates` | Create |
| GET | `/templates/:id` | Full config |
| PATCH | `/templates/:id` | Update |
| POST | `/templates/generate` | AI template generator |
| POST | `/templates/:id/duplicate` | Clone |

---

## 5. Onboarding instances

| Method | Path | Description |
|--------|------|-------------|
| GET | `/onboardings` | List (dashboard filters) |
| POST | `/onboardings` | Create from template + client (or “won deal”) |
| GET | `/onboardings/:id` | Full state (stages, tasks, health, blockers) |
| PATCH | `/onboardings/:id` | Update metadata / owner |
| POST | `/onboardings/:id/transition` | Controlled state transition |
| GET | `/onboardings/:id/health` | Live health score + reasons |
| GET | `/onboardings/:id/blockers` | Current blockers |
| POST | `/onboardings/:id/invite` | Send client portal invite |

---

## 6. Tasks

| Method | Path | Description |
|--------|------|-------------|
| GET | `/onboardings/:id/tasks` | List tasks |
| POST | `/onboardings/:id/tasks` | Create task |
| GET | `/tasks/:id` | Detail |
| PATCH | `/tasks/:id` | Update status / assignee / due |
| POST | `/tasks/:id/complete` | Mark complete (validates deps) |
| POST | `/tasks/:id/block` | Mark blocked + reason |
| GET | `/tasks/:id/dependencies` | Graph |

---

## 7. Forms & submissions

| Method | Path | Description |
|--------|------|-------------|
| GET | `/forms` | List org forms |
| POST | `/forms` | Create form |
| GET | `/forms/:id` | Schema |
| POST | `/forms/:id/submit` | Client submission |
| GET | `/submissions/:id` | View submission + AI extract |

---

## 8. Documents

| Method | Path | Description |
|--------|------|-------------|
| POST | `/documents/upload-url` | Get signed upload URL |
| POST | `/documents` | Confirm upload + attach to task |
| GET | `/documents/:id` | Metadata + signed download |
| POST | `/documents/:id/analyze` | Trigger AI document intelligence |
| GET | `/document-requests` | List for instance |

---

## 9. Contracts & payments

| Method | Path | Description |
|--------|------|-------------|
| POST | `/contracts` | Create / send via provider |
| GET | `/contracts/:id` | Status |
| POST | `/contracts/webhook/:provider` | Provider webhook |
| POST | `/payments/checkout` | Create Stripe session |
| POST | `/payments/webhook` | Stripe webhook |
| GET | `/payments/:id` | Status |

---

## 10. Appointments

| Method | Path | Description |
|--------|------|-------------|
| POST | `/appointments` | Book (Calendly / Google) |
| GET | `/appointments/:id` | Detail |
| PATCH | `/appointments/:id` | Reschedule / cancel |
| POST | `/appointments/webhook/:provider` | Provider webhook |

---

## 11. Messages & notifications

| Method | Path | Description |
|--------|------|-------------|
| GET | `/onboardings/:id/messages` | Thread |
| POST | `/onboardings/:id/messages` | Send (channel + template) |
| GET | `/notifications` | Current user notifications |
| PATCH | `/notifications/:id/read` | Mark read |

---

## 12. Approvals

| Method | Path | Description |
|--------|------|-------------|
| GET | `/approvals` | Pending for current user / client |
| POST | `/approvals` | Request approval |
| POST | `/approvals/:id/decide` | Approve / reject / request changes |

---

## 13. Workflows

| Method | Path | Description |
|--------|------|-------------|
| GET | `/workflows` | List |
| POST | `/workflows` | Create |
| GET | `/workflows/:id` | Definition |
| PATCH | `/workflows/:id` | Update |
| POST | `/workflows/:id/run` | Manual trigger |
| GET | `/workflow-runs` | History |

---

## 14. Exception Inbox & Command Center

| Method | Path | Description |
|--------|------|-------------|
| GET | `/exceptions` | Needs-attention list (sorted by severity) |
| GET | `/dashboard/summary` | Counts: active, at risk, blocked, etc. |
| GET | `/dashboard/onboardings` | Table data |

---

## 15. AI

| Method | Path | Description |
|--------|------|-------------|
| POST | `/ai/chat` | Client or admin AI assistant |
| POST | `/ai/document-analyze` | Extract + validate |
| POST | `/ai/intake-analyze` | Structure free-text intake |
| POST | `/ai/handoff-brief` | Sales → delivery brief |
| POST | `/ai/scope-check` | Promise / scope detection |
| POST | `/ai/actions/:id/approve` | Human approve AI action |
| GET | `/ai/runs` | History |

---

## 16. Integrations

| Method | Path | Description |
|--------|------|-------------|
| GET | `/integrations` | Connected integrations |
| POST | `/integrations/:provider/connect` | OAuth start |
| POST | `/integrations/:provider/callback` | OAuth callback |
| DELETE | `/integrations/:id` | Disconnect |
| POST | `/webhooks/inbound/:provider` | Generic inbound |

---

## 17. Analytics

| Method | Path | Description |
|--------|------|-------------|
| GET | `/analytics/funnel` | Signed → paid → intake → kickoff → live |
| GET | `/analytics/bottlenecks` | Where time is lost |
| GET | `/analytics/ttv` | Time-to-value distribution |
| GET | `/analytics/completion` | Completion rate |

---

## 18. End-customer onboarding workspace (scoped routes)

All under `/workspace/...` with end-customer JWT (limited permissions). Paying-client Operations Dashboard routes live under `/dashboard/...` with organization-scoped roles.

| Method | Path | Description |
|--------|------|-------------|
| GET | `/workspace/onboarding` | Progress, next steps, timeline |
| GET | `/workspace/tasks` | Client-visible tasks |
| POST | `/workspace/tasks/:id/complete` | Complete own task |
| POST | `/workspace/forms/:id/submit` | Submit form |
| POST | `/workspace/documents` | Upload |
| GET | `/workspace/approvals` | Pending approvals |
| POST | `/workspace/approvals/:id/decide` | Decide |
| POST | `/workspace/ai/chat` | Ask Onboard AI |
| GET | `/workspace/messages` | Conversation |

---

## 19. Common response envelope

```json
{
  "data": { ... },
  "meta": { "page": 1, "total": 42 },
  "error": null
}
```

Errors:

```json
{
  "error": {
    "code": "TASK_DEPENDENCY_NOT_MET",
    "message": "Cannot complete: blocked by Google Ads access",
    "details": { ... }
  }
}
```

---

## 20. Rate limiting & security

- Per-org and per-user rate limits
- Webhook signature verification required
- All file access via short-lived signed URLs
- Audit log on every privileged mutation

---

## v2 API additions

### Requirements
- `GET /onboardings/:id/requirements`
- `POST /onboardings/:id/requirements`
- `POST /requirements/:id/evidence`
- `POST /requirements/:id/verify`
- `POST /requirements/:id/waive`

### Readiness
- `GET /onboardings/:id/readiness`
- `POST /onboardings/:id/readiness/recalculate`
- `POST /onboardings/:id/readiness/override`

### Exceptions
- `GET /exceptions`
- `GET /exceptions/:id`
- `POST /exceptions/:id/acknowledge`
- `POST /exceptions/:id/snooze`
- `POST /exceptions/:id/retry`
- `POST /exceptions/:id/resolve`

### Workflow operations
- `GET /workflow-runs/:id`
- `GET /workflow-runs/:id/steps`
- `POST /workflow-runs/:id/retry-step`
- `POST /workflow-runs/:id/replay`
- `POST /workflow-runs/:id/takeover`

### Repairs
- `POST /onboardings/:id/rebuild-read-model`
- `POST /onboardings/:id/recalculate`
- `POST /integrations/:id/reconcile`
- `POST /webhooks/:id/replay`

All mutating side-effect endpoints support idempotency. Mutable resources use version/ETag-style optimistic concurrency.

## V2.4 Document & Billing API

### Templates
- `GET /v1/templates`
- `POST /v1/templates`
- `POST /v1/templates/import`
- `POST /v1/templates/:id/versions`
- `POST /v1/templates/:id/publish`
- `GET /v1/templates/:id/preview`

### Documents
- `POST /v1/documents/generate`
- `POST /v1/documents/:id/send`
- `POST /v1/documents/:id/void`
- `GET /v1/documents/:id`
- `GET /v1/documents/:id/audit`

### Billing
- `POST /v1/invoices`
- `POST /v1/invoices/:id/finalize`
- `POST /v1/invoices/:id/send`
- `POST /v1/invoices/:id/void`
- `POST /v1/invoices/:id/credit-notes`
- `GET /v1/invoices/:id`
- `GET /v1/invoices/:id/payments`

### Commercial flows
- `GET /v1/commercial-flows`
- `POST /v1/commercial-flows`
- `POST /v1/commercial-flows/:id/versions`
- `POST /v1/onboardings/:id/commercial-flow/resolve`
- `PUT /v1/onboardings/:id/commercial-flow/override`

All write endpoints use idempotency keys where external side effects are possible and return the standard API error envelope.

## V2.5 Client Entry APIs

- `POST /v1/customers` — create an end customer manually with validated identity/contact/business/commercial fields.
- `POST /v1/customers/{customerId}/onboardings/draft` — create a draft onboarding from a selected flow source.
- `PATCH /v1/onboardings/{onboardingId}/flow` — edit a draft/customer-specific flow.
- `POST /v1/onboardings/{onboardingId}/preview-activation` — return the exact planned outbound/internal actions and pinned versions.
- `POST /v1/onboardings/{onboardingId}/activate` — atomically pin the flow and activate the onboarding; idempotent.
- `GET /v1/flows/available` — list tenant-visible starter/global/service flows.
