# OnboardOS v3.1 — 20-Point Competitive Upgrade Contract

This is the canonical traceability contract for the 20 major competitive upgrades requested for the final OnboardOS build. Each point must be represented by a concrete runtime contract, UI/API behavior, persistence model, and acceptance test where applicable.

| # | Upgrade | Required behavior | Primary contract |
|---|---|---|---|
| 1 | Deal-to-Delivery Compiler | Convert CRM/deal/proposal/SOW/contract/sales context into an executable delivery brief. | `26-agentic-onboarding-os` |
| 2 | Promise & Scope Graph | Preserve provenance for promises, deliverables, dates, constraints and changes. | `26-agentic-onboarding-os` |
| 3 | Onboarding Twin | Maintain a live graph of customer, engagement, requirements, evidence, dependencies, risks, events and outcomes. | `26-agentic-onboarding-os` |
| 4 | Requirement + Evidence Engine | Treat requirements as evidence-backed states, not checkboxes; support validation, provenance and conflicts. | `26-agentic-onboarding-os` |
| 5 | Scope Drift + Change Orders | Detect out-of-scope requests and produce controlled change-order workflows. | `29-activation-intelligence` |
| 6 | Agent Workforce | Specialized agents coordinate through durable jobs, typed tools, handoffs and policies. | `26-agentic-onboarding-os`, `28-agent-execution` |
| 7 | Workflow Simulator | Dry-run a flow before activation, exposing branches, side effects, approvals, variables and failure paths. | `26-agentic-onboarding-os`, `30-testing` |
| 8 | Customer Friction Analytics | Measure effort, stalls, repeated requests, failed uploads, clarification loops and approval latency. | `29-activation-intelligence` |
| 9 | Activation + First-Value Engine | Define service-specific activation gates and verify actual first value rather than task completion. | `29-activation-intelligence` |
| 10 | Portfolio Intelligence | Explain risk, root causes, predicted impact, bottlenecks, workload and interventions across onboardings. | `29-activation-intelligence` |
| 11 | Workflow Experimentation | Version and compare onboarding variants using activation, effort, delay and outcome metrics; publishing requires approval. | `29-activation-intelligence` |
| 12 | Connector + MCP/API Fabric | Execute durable OAuth/API/webhook/MCP actions with tenant scope, idempotency, verification and provider health. | `28-agent-execution` |
| 13 | Adaptive End-Customer Workspace | Dynamically surface only the next relevant actions, context, documents, approvals and help. | `07-screens`, `16-ui-ux-v2`, `26-agentic-onboarding-os` |
| 14 | Ask OnboardOS Action Interface | Answer operational questions with evidence and offer authorized actions, not chat-only responses. | `28-agent-execution`, `29-activation-intelligence` |
| 15 | Autonomous Exception & Recovery | Detect failure, retry, fail over, re-plan, request clarification, escalate and verify recovery within bounded policy. | `28-agent-execution` |
| 16 | Benchmarking + Forecasting | Establish tenant-scoped benchmarks by service, complexity, workflow, team and period; forecast activation/SLA risk. | `29-activation-intelligence` |
| 17 | Workload + Capacity Intelligence | Detect team overload, dependency bottlenecks and assignment imbalance; recommend reassignment without silently changing ownership. | `29-activation-intelligence` |
| 18 | Commercial Orchestration | Treat contracts, signatures, invoices, payments, reminders, receipts and change orders as first-class workflow nodes. | `22-document-billing-engine`, `24-billing-workflows` |
| 19 | Premium Template + Document Intelligence | Import DOCX/templates, detect/map variables, validate, version, preview and publish; support professional commercial documents. | `22-document-billing-engine`, `23-template-library` |
| 20 | Agent Governance + Observability | Enforce permissions, approvals, model/prompt versions, evidence, costs, budgets, evaluations, audit trails and human takeover. | `08-permissions`, `13-production-hardening`, `28-agent-execution` |

## Definition of done

An upgrade is considered present only when:

1. Its behavior is explicitly specified.
2. Its source of truth is defined.
3. Side effects use typed tools or deterministic workflow actions.
4. Authorization is enforced server-side.
5. Important actions are idempotent and auditable.
6. External effects have a verification path.
7. Failure/retry/exception behavior is defined.
8. Tenant isolation is preserved.
9. The feature is represented in acceptance tests where executable.
10. No upgrade silently bypasses the existing 59 production hardening requirements.
