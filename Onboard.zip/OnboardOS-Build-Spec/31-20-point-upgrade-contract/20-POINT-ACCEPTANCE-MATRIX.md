# OnboardOS v3.1 — 20-Point Acceptance Matrix

| # | Acceptance test | Pass condition |
|---|---|---|
| 1 | Deal compiler | A representative closed-won payload produces a normalized delivery brief with provenance. |
| 2 | Promise graph | Every generated promise links back to a source artifact or explicit human input. |
| 3 | Onboarding twin | State converges after events, retries and replay without duplicate state transitions. |
| 4 | Evidence engine | Invalid, expired or contradictory evidence cannot satisfy a protected requirement. |
| 5 | Scope protection | An out-of-scope request cannot silently create committed delivery work. |
| 6 | Agent workforce | At least five specialized agents execute one end-to-end onboarding through durable handoffs. |
| 7 | Simulator | A flow with an unreachable node, missing variable or infinite loop is rejected before activation. |
| 8 | Friction analytics | Customer effort metrics are computed from persisted interaction events, not model guesses. |
| 9 | Activation | ACTIVATED is impossible without configured verified gates or an auditable approved waiver. |
| 10 | Portfolio intelligence | Dashboard can trace every risk recommendation to current onboarding evidence/events. |
| 11 | Experimentation | Workflow variants are isolated, measured and cannot silently replace the production version. |
| 12 | Connector fabric | An external side effect records tenant, credential reference, provider ID, idempotency key and verification result. |
| 13 | Adaptive workspace | End customer sees only authorized customer-visible requirements and current next actions. |
| 14 | Ask OnboardOS | Operational answer includes evidence and any proposed action goes through normal authorization. |
| 15 | Recovery | A failed provider call follows retry/failover/exception policy and never reports false success. |
| 16 | Benchmarking | Benchmarks are tenant-scoped and exclude unauthorized cross-tenant customer data. |
| 17 | Capacity | Capacity recommendations are explainable and require configured approval before ownership changes. |
| 18 | Commercial | Signature/payment webhooks unlock the correct downstream nodes idempotently. |
| 19 | Documents | Imported templates fail validation on unknown/missing variables before publication. |
| 20 | Governance | Every consequential agent run has an auditable policy, tool, evidence, model/prompt and outcome record. |

## Multi-agent acceptance scenario

The canonical scenario must execute as:

`Deal Won → Deal-to-Delivery → Requirement Planner → Commercial → Intake → Evidence → Risk → Chase → Scheduling → Implementation → Scope → Approval → Activation → Handoff → Learning`

Agents may run independent low-risk observations concurrently, but all state-changing actions are serialized through the workflow runtime and protected by optimistic concurrency/idempotency. Every handoff persists its objective, context references, allowed tools, deadline, prior attempts and policy state.
