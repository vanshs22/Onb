# OnboardOS v2.1 — 59-Upgrade Completeness Manifest

This release explicitly tracks the first 59 production upgrades from the recommended build order. Every item below is a build requirement, not merely a product idea.

## P0 — Production foundation (1–15)

1. **Tenant model + authorization** — organization, membership, role, client identity, partner hierarchy, server-side authorization on every request.
2. **Canonical PostgreSQL schema** — normalized domain model, foreign keys, constraints, indexes, soft-delete/retention strategy and migration discipline.
3. **Immutable template/version system** — onboarding templates, workflows, forms, policies and communication templates are versioned and pinned to an onboarding.
4. **Onboarding state machine** — controlled lifecycle transitions with guards, invalid-transition errors and auditable state changes.
5. **Requirement engine** — first-class requirements with owner, source, due date, visibility, status, evidence, verification and dependencies.
6. **Evidence + verification model** — uploaded/submitted/connected evidence is stored independently from a requirement and can be machine- or human-verified.
7. **Readiness gates** — explicit gates determine whether stages such as kickoff, implementation and activation may proceed.
8. **Task/dependency graph** — tasks derive from requirements/workflows; dependencies can block, warn or trigger alternate paths.
9. **Transactional outbox** — domain state changes and outbound events commit atomically before asynchronous delivery.
10. **Idempotency** — mutating APIs, jobs and provider side-effects use durable idempotency keys and replay-safe handlers.
11. **Webhook persistence/deduplication** — raw deliveries are persisted, signatures verified, duplicates detected, processing state tracked and replay supported.
12. **Optimistic concurrency** — version/ETag checks prevent stale writes; conflicts return a structured 409 response.
13. **Audit/security events** — privileged actions, authentication/security events and important automated decisions are immutably auditable.
14. **Error contract** — stable machine-readable error codes, correlation IDs, validation details and safe user-facing messages across APIs.
15. **Reconciliation/repair framework** — scheduled reconciliation detects drift between OnboardOS and external systems; repair is controlled, auditable and replayable.

## P1 — Sellable client experience (16–26)

16. **Client portal shell** — branded, responsive, secure client workspace with navigation, session handling, loading/error/empty states and deep links.
17. **Next Best Action** — one primary action is surfaced based on requirements, blockers, dependencies, due dates and readiness impact.
18. **Requirements UI** — clients see only relevant requirements with why-needed, effort estimate, due date, status and completion feedback.
19. **Forms** — autosave, validation, conditional questions, resume later, submission receipts and version-pinned schemas.
20. **Documents + requests** — secure upload/request flows, file validation, virus/malware quarantine, AI extraction and verification status.
21. **Approvals** — approve/request-changes/comment/attach flows with immutable decision records.
22. **Payments** — payment status, invoices/checkout, receipts and provider reconciliation without exposing secret payment data.
23. **Meetings** — booking, rescheduling, cancellation and timezone-safe meeting display with provider synchronization.
24. **Messages** — threaded client/team communication, attachments, unread state, delivery state and optional AI participation.
25. **Timeline** — human-readable lifecycle history with client-safe event projection, not raw internal events.
26. **Client AI assistant** — grounded in current onboarding state + approved knowledge, with safe action boundaries and escalation to humans.

## P1 — Admin operations (27–35)

27. **Command Center** — internal operational dashboard showing portfolio health, attention queue, stage distribution, SLA and recent activity.
28. **Onboarding detail** — 360-degree operational view for one onboarding: requirements, tasks, evidence, readiness, timeline, communications, workflow and audit.
29. **Exception Inbox** — first-class exception records with severity, root cause, impact, AI attempts, owner, SLA and controlled resolution actions.
30. **Requirement/readiness view** — inspect every requirement, evidence item, verification result, dependency and gate contributing to readiness.
31. **Workflow debugger** — per-run node state, attempts, timings, inputs/outputs, provider IDs, errors, retries and replay controls with permissions.
32. **Integration health** — connector status, auth health, webhook health, latency/error rates, last sync and actionable repair paths.
33. **Audit viewer** — searchable audit/security trail with actor, source, timestamp, before/after and correlation ID.
34. **Global search** — tenant-scoped search across clients, onboardings, requirements, documents, exceptions, messages and identifiers.
35. **Saved operational views** — filter/sort/group views can be saved and shared according to role permissions.

## P1 — Automation (36–42)

36. **Workflow engine** — version-pinned event/condition/action execution with durable state.
37. **Wait/condition/action** — timers, conditions, external events and actions compose into deterministic workflows.
38. **Reminder engine** — channel-aware reminders with quiet hours, escalation policy and dedupe.
39. **Escalation engine** — escalation based on overdue requirements, risk, blocked dependencies, failed automations and SLA thresholds.
40. **SLA engine** — business calendars, priority, response/resolve targets, pause/resume rules and breach events.
41. **Human takeover** — automation can pause and route to an authorized operator without losing context or creating duplicate actions.
42. **Retry/replay** — safe retries with backoff, attempt history, idempotency and explicit operator replay for failed steps/events.

## P1 — Integrations (43–50)

43. **Stripe** — payment/checkout/invoice events, reconciliation and secure client payment experience.
44. **E-sign provider** — agreement creation/status/webhooks with provider abstraction for PandaDoc/DocuSign-style integrations.
45. **Calendar** — meeting availability and event synchronization with timezone correctness.
46. **Google Workspace** — Drive/Gmail/Calendar style capabilities through least-privilege OAuth and scoped access.
47. **CRM** — deal/client sync, ownership, lifecycle events and source-of-truth rules.
48. **Twilio** — SMS/voice delivery, inbound/outbound events, consent and delivery status.
49. **Slack** — internal notifications, threads/deep links and controlled action surfaces.
50. **Generic connector framework** — reusable OAuth/API-key/webhook connector abstraction with secrets, health, scopes and replay/reconciliation.

## P2 — AI intelligence (51–59)

51. **Onboard Agent** — orchestrates safe operational reasoning around requirements, blockers, reminders, escalations and next actions.
52. **Document intelligence** — classify/extract/compare documents and attach evidence to requirements with confidence and provenance.
53. **Intake analysis** — analyze submitted intake for missing information, contradictions, risk and implementation implications.
54. **Sales-to-delivery handoff** — transform approved sales/deal context into structured delivery context with source links.
55. **Promise register** — capture documented commitments, source, confidence, owner, deadline and verification state.
56. **Scope detection** — compare agreed scope against intake/requests and route suspected scope changes for human approval.
57. **Risk detection** — detect blockers, inactivity, contradictions, SLA risk and implementation risk with evidence-backed signals.
58. **Communication intelligence** — summarize threads, identify unanswered questions, classify intent and propose safe responses/actions.
59. **AI evidence/confidence** — every consequential AI output records model/agent version, prompt/policy version, evidence references, confidence, action taken, approval requirement and result.

## Definition of done for all 59

- Every feature is tenant-scoped and permission-checked server-side.
- Critical mutations are idempotent and audited.
- External failures become recoverable states/exceptions rather than silent failures.
- Realtime projections update the internal console and client portal without requiring refresh.
- Client-facing UI never leaks internal notes, provider secrets, AI implementation details or staff-only operational data.
- All screens implement loading, empty, success, validation-error, permission-denied and recoverable-error states.
- Production release also requires cross-tenant security tests, duplicate-webhook tests, worker-failure recovery, stale-write 409 tests, backup restore testing and AI golden tests.

## Scope beyond the 59

The architecture also reserves explicit P3 capacity for analytics, white-label, custom domains, usage metering, SSO/SCIM, data residency, advanced compliance, durable workflow migration, vertical packs, adaptive onboarding and Customer Operations expansion. These are not counted as part of the 59-item core checklist.

## Lifecycle and integration completion layer

The 59 upgrades are implemented against the canonical 18-stage lifecycle in `18-lifecycle-playbook/ONBOARDING-LIFECYCLE.md` and the integration strategy in `19-integration-blueprint/INTEGRATION-MATRIX.md`. These documents are part of the same implementation contract and are not optional product ideas.
