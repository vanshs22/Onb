# OnboardOS — Operations Dashboard, End-Customer Workspace, Roles & Modes

## Commercial modes

| Mode | OnboardOS internal console | Paying-client Operations Dashboard | End-customer workspace | White-label |
|---|---|---|---|---|
| Managed | OnboardOS team | Yes | Yes | Optional |
| SaaS | Customer team | Yes | Yes | No |
| White-label | Partner team | Yes | Yes | Yes |
| Enterprise | Customer/OnboardOS according to contract | Yes | Yes | Optional |

## Capability model

Features are controlled by entitlements, not frontend assumptions:

- `end_customer.workspace.enabled`
- `end_customer.ai.enabled`
- `end_customer.payments.enabled`
- `end_customer.approvals.enabled`
- `end_customer.meetings.enabled`
- `end_customer.messaging.enabled`
- `end_customer.resources.enabled`
- `customer_dashboard.custom_domain.enabled`
- `admin.workflow_builder.enabled`
- `admin.ai_policy.enabled`
- `admin.analytics.advanced`
- `white_label.enabled`

Server-side authorization remains mandatory even when a feature is hidden in the UI.

## Domain-to-surface projection rules

```text
Internal domain/event state
        ↓
Authorization + policy
        ↓
Client-safe projection
        ↓
Realtime/API
        ↓
Client portal
```

Never build either surface by sending the entire internal onboarding object to the browser and hiding fields with CSS or client-side logic. Both require server-side, role-specific projections.

## Branding inheritance

```text
Platform
  ↓
Partner (optional)
  ↓
Customer organization
  ↓
Engagement/onboarding
```

The most specific enabled branding configuration wins. Security and platform identity elements remain controlled by platform policy.
