# OnboardOS v2 — Client UX

## Principle

The client should experience **clarity and momentum**, not workflow complexity.

The portal is a productized service experience. It should make the customer feel that the business is actively managing their onboarding.

## Client navigation

- Home
- My Tasks
- Documents
- Forms
- Agreements
- Payments
- Meetings
- Approvals
- Messages
- Timeline
- Help / Ask AI

Hide irrelevant areas based on the onboarding template.

## Home

```text
Welcome, Sarah

ONBOARDING READINESS
82%   On track

YOUR NEXT STEP
Connect Google Analytics
Required · ~2 minutes
[Connect]

COMPLETED
✓ Agreement
✓ Payment
✓ Business details
✓ Brand assets

UP NEXT
○ Analytics verification
○ Kickoff
○ Implementation

NEXT MEETING
Kickoff · Tuesday 11:00 AM

Need help?
[Ask Onboard AI]
```

## Client should NOT see

- internal workflow nodes
- AI model names
- private notes
- internal exception details
- staff-only tasks
- raw health formulas
- sensitive operational metadata

## Client blockers

If the client is blocking progress, explain:
- what is needed
- why it is needed
- how long it should take
- what it unlocks

Example:

> Connect Google Ads to unlock campaign setup. This normally takes about 2 minutes.

## Admin command center

Admin navigation:
- Overview
- Onboardings
- Exceptions
- Clients
- Requirements
- Workflows
- Templates
- Integrations
- AI
- Analytics
- Messages
- Team
- Settings

## Admin onboarding detail

Header:
- client
- engagement
- stage
- readiness
- risk
- owner
- next action

Tabs:
- Overview
- Requirements
- Tasks
- Timeline
- Documents
- Messages
- Approvals
- Workflow
- AI
- Integrations
- Audit

## Exception Inbox

Each card must show:
- severity
- client
- root cause
- impact
- what AI tried
- recommended action
- owner
- SLA

Actions:
- Approve
- Handle manually
- Retry
- Snooze
- Reassign
- Resolve

## Workflow debugger

Show every node with:
- state
- attempts
- duration
- input
- output
- external provider ID
- error
- retry/replay controls

## Responsive / accessibility

Target WCAG 2.2 AA. Support keyboard navigation, visible focus, accessible dialogs, semantic forms, error announcements, sufficient contrast and reduced motion.
