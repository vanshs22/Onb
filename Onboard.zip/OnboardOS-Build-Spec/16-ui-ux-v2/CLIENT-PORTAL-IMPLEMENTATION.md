# OnboardOS — End-Customer Onboarding Workspace Implementation Specification

## 1. Product role

The end-customer workspace is a **first-class action application**, not an admin dashboard with fewer menu items. The paying business client has a separate Operations Dashboard.

It is used in all commercial modes:

- **Managed:** OnboardOS team operates the Command Center; the paying business uses the Operations Dashboard and its customers use the branded end-customer workspace.
- **SaaS:** customer company operates its own Command Center and Operations Dashboard; its customers use the end-customer workspace.
- **White-label:** partner controls branding/domain; partner uses the branded Operations Dashboard and its customers use the branded end-customer workspace.

The workspace is the end-customer action layer of the onboarding engine. The paying-client Operations Dashboard is the business visibility layer; internal automation remains hidden from both.

## 2. End-customer mental model

The portal should answer five questions immediately:

1. Where am I?
2. What do I need to do now?
3. Why do you need it?
4. What happens after I do it?
5. Can I get help without leaving the portal?

Do not make the client understand workflow nodes, automation rules, database states or internal ownership.

## 3. Workspace information architecture

```text
Portal
├── Home
├── My Tasks
├── Forms
├── Documents
├── Agreements
├── Payments
├── Meetings
├── Approvals
├── Messages
├── Timeline
├── Resources
└── Help / Ask Onboard AI
```

Navigation is template-aware. Empty modules are hidden instead of shown disabled.

## 4. Home screen

```text
Good morning, Sarah
Acme Media · Website Growth Program

ONBOARDING
82% ready
Kickoff target: Tue, 30 Sep

YOUR NEXT STEP
Connect Google Analytics
Required · ~2 minutes
[ Connect ]

WHY THIS MATTERS
This unlocks campaign setup and lets the team verify your analytics access.

COMPLETED
✓ Agreement
✓ Payment
✓ Business details
✓ Brand assets

UP NEXT
○ Analytics verification
○ Kickoff
○ Implementation

UPCOMING
Kickoff · Tue 11:00 AM

Need help?
[ Ask Onboard AI ] [ Message the team ]
```

The primary CTA must always be derived from the current Next Best Action service, not hardcoded to a generic “complete onboarding” button.

## 5. Requirement card contract

Every client-visible requirement supports:

- title
- plain-language reason
- required/optional
- estimated effort
- due date/timezone
- status
- CTA
- accepted evidence type
- dependency/unlock explanation
- save/resume state
- success confirmation
- support escalation

Example statuses: `NEEDS_ACTION`, `IN_PROGRESS`, `SUBMITTED`, `VERIFYING`, `COMPLETE`, `BLOCKED`, `WAIVED`.

## 6. Client-visible readiness

Show an understandable readiness indicator, but never expose the internal scoring formula.

Allowed:
- Ready / Nearly ready / Action needed / Waiting on team
- completion percentage
- target kickoff date
- named blockers
- estimated remaining client effort

Not allowed:
- raw risk weights
- internal exception severity
- model confidence values unless explicitly productized
- private SLA data
- internal task ownership

## 7. Forms

Requirements:

- schema version pinned to onboarding
- autosave
- resume later
- conditional sections
- inline validation
- accessible errors
- file attachments where configured
- submission receipt
- edit-after-submit policy
- server-side validation
- audit trail

Never trust browser-only validation.

## 8. Documents

Upload flow:

`select → client-side validation → upload → quarantine → malware scan → metadata extraction → AI analysis (if enabled) → verification → requirement update → client-safe result`

Clients should see clear statuses such as `Uploading`, `Checking`, `Needs attention`, `Verified`, not infrastructure terminology.

## 9. Agreements

Support:

- pending signature
- view agreement
- sign externally or embedded
- signature status
- completed copy/receipt
- expired/voided states

Provider implementation must be abstracted behind an agreement service.

## 10. Payments

Support:

- amount due
- invoice/reference
- payment CTA
- success/failure/pending state
- receipt/history
- provider reconciliation

No card secrets or internal payment IDs are exposed.

## 11. Meetings

Support:

- available meeting types
- timezone-aware times
- book
- reschedule
- cancel
- confirmation
- calendar link
- meeting state synchronized from provider events

## 12. Approvals

Each approval shows:

- what is being approved
- version/date
- context
- attachments/evidence
- Approve
- Request changes
- Comment

Decision is immutable; a new decision/version is created for a changed artifact.

## 13. Messages

Thread model:

```text
Client ↔ Team
       ↕
  Onboard AI (optional)
```

AI must identify itself as AI when participating. Human handoff preserves conversation context.

Unread counts, delivery state and realtime message arrival are required.

## 14. Timeline

The client timeline is a **projection**, not the raw event log.

Show meaningful milestones:

`Welcome → Agreement → Payment → Intake → Documents → Access → Kickoff → Implementation → Approval → Launch → Handoff`

Hide internal retries, failed provider calls, private notes and sensitive audit information.

## 15. Ask Onboard AI

The client assistant may:

- explain requirements
- answer approved knowledge-base questions
- explain current progress
- summarize what is missing
- explain what a submitted document is being checked for
- help complete supported forms
- create a support request

It may not independently:

- change scope
- approve exceptions
- waive requirements
- promise delivery dates
- expose internal notes
- access another client's information
- execute privileged integrations without policy approval

## 16. Realtime behavior

Use a tenant-scoped realtime channel. Portal updates include:

- requirement status
- task completion
- document verification
- approval decisions
- payment status
- meeting changes
- messages
- timeline milestones
- readiness projection

Client UI must reconcile realtime updates with local state and refetch authoritative state after reconnect.

## 17. Offline/reconnect behavior

For network interruption:

- preserve unsaved form data locally where safe
- show connection state
- prevent duplicate mutation submissions
- retry only idempotent operations
- refresh authoritative state after reconnect
- surface unresolved conflicts instead of overwriting silently

## 18. Portal security

- client identity is separate from staff identity
- organization and onboarding scope is server-enforced
- every portal route has explicit authorization
- short-lived signed file URLs
- secure cookie/session strategy
- CSRF protection where applicable
- rate limits on auth/upload/AI endpoints
- audit client mutations
- no tenant IDs accepted as an authorization substitute

## 19. Responsive design

Mobile-first for clients. Desktop may add navigation density but must not change the information hierarchy.

Targets:

- WCAG 2.2 AA
- keyboard support
- semantic forms
- visible focus
- accessible dialogs
- screen-reader status announcements
- reduced motion
- sufficient contrast
- touch-friendly controls

## 20. Branded portal

Per organization/partner:

- logo
- primary/secondary colors
- favicon
- typography choice from approved set
- email sender identity
- portal title
- support contact
- custom domain where enabled

Branding is tenant configuration, not duplicated frontend code.

## 21. Portal URL model

Conceptually:

```text
https://portal.example.com/{tenant-slug}/onboarding/{public-safe-id}
```

For custom domains:

```text
https://onboarding.clientdomain.com/onboarding/{public-safe-id}
```

Public-safe IDs must not replace authorization; they only provide routing/UX.

## 22. Client roles

Minimum roles:

- `CLIENT_OWNER` — full client-side access for the engagement
- `CLIENT_MEMBER` — assigned client requirements/content
- `CLIENT_APPROVER` — approvals/payments/agreement decisions as granted
- `CLIENT_VIEWER` — read-only client-safe information

Role permissions must be scoped to organization + engagement/onboarding.

## 23. Managed-service behavior

For managed customers, the client still receives the portal. The internal team handles:

- workflow configuration
- integrations
- exceptions
- AI policy configuration
- reconciliation
- escalations
- operational tasks

The client should experience the result, not the machinery.

## 24. End-customer workspace acceptance tests

A release is not portal-ready until these work:

1. Invite → sign in → land on correct onboarding.
2. Client sees only its own tenant/engagement data.
3. Next Best Action changes after completion.
4. Form autosave survives refresh.
5. Duplicate submit does not create duplicate side-effects.
6. Document upload cannot expose another file.
7. Approval decision updates admin and client in realtime.
8. Payment webhook updates portal state safely.
9. Meeting reschedule reflects after provider sync.
10. Message arrives without refresh.
11. Reconnect restores authoritative state.
12. Unauthorized route access is rejected.
13. Every important loading/error/empty state is usable.
14. Internal exception/private note never appears in client projection.
15. Branding changes propagate without code deployment.
