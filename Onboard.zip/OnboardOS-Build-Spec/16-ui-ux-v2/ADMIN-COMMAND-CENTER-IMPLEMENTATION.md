# OnboardOS — Internal Command Center Implementation

## Purpose

The Command Center is the operational cockpit used by OnboardOS operators, customer admins and authorized partner staff. It may be information-dense because its users are responsible for outcomes.

## Navigation

```text
Overview
Onboardings
Exceptions
Clients
Requirements
Workflows
Templates
Integrations
AI
Analytics
Messages
Team
Settings
```

## Overview

Show:

- onboardings in progress
- ready / blocked / at-risk counts
- today's required actions
- overdue requirements
- SLA breaches/upcoming breaches
- open exceptions
- provider/integration incidents
- recent activity
- time-to-value trend

Every metric drills into the underlying records.

## Onboarding detail

Header:

`Client · Engagement · Stage · Readiness · Risk · Owner · Next Action`

Tabs:

- Overview
- Requirements
- Tasks
- Evidence
- Timeline
- Documents
- Messages
- Approvals
- Workflow
- AI
- Integrations
- Audit

## Exception Inbox

Default sort is operational urgency, not creation date.

Card fields:

- severity
- client
- onboarding
- root cause
- impact
- detected time
- AI attempts
- recommended action
- owner
- SLA
- current status

Actions are permissioned:

- acknowledge
- handle manually
- retry
- replay
- snooze
- reassign
- resolve
- reopen

Resolution requires a reason where configured.

## Workflow debugger

Operators can inspect:

- workflow version
- run ID
- node state
- attempt number
- start/end/duration
- input/output redacted by policy
- provider request ID
- error code
- retry history
- correlation ID

Replay must create a new auditable attempt and preserve prior history.

## Integration health

For each connector:

- connected/disconnected
- auth expiry
- webhook health
- last successful sync
- recent errors
- provider rate limits
- reconciliation status
- repair action

## Global search

Search is tenant-scoped and permission-aware. Index client-safe and internal entities separately so a staff search result cannot accidentally surface restricted fields.

## Realtime

Command Center receives:

- new exceptions
- state transitions
- requirement changes
- AI decisions
- provider failures
- new messages
- payments
- approvals

Optimistic UI is allowed only where rollback/conflict handling is implemented.

## Operational safety

No admin mutation should depend on a client-supplied `organization_id` alone. Resolve tenant context from authenticated membership/partner context and verify resource ownership server-side.
