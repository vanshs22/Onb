# OnboardOS v2.1 — Recommended Build Order & 59-Upgrade Release Checklist

## P0 — Production foundation

1. Tenant model + authorization
2. Canonical PostgreSQL schema
3. Immutable template/version system
4. Onboarding state machine
5. Requirement engine
6. Evidence + verification model
7. Readiness gates
8. Task/dependency graph
9. Transactional outbox
10. Idempotency
11. Webhook persistence/deduplication
12. Optimistic concurrency
13. Audit/security events
14. Error contract
15. Reconciliation/repair framework

## P1 — Sellable client experience

16. Client portal shell
17. Next Best Action
18. Requirements UI
19. Forms
20. Documents + requests
21. Approvals
22. Payments
23. Meetings
24. Messages
25. Timeline
26. Client AI assistant

## P1 — Admin operations

27. Command Center
28. Onboarding detail
29. Exception Inbox
30. Requirement/readiness view
31. Workflow debugger
32. Integration health
33. Audit viewer
34. Global search
35. Saved operational views

## P1 — Automation

36. Workflow engine
37. Wait/condition/action
38. Reminder engine
39. Escalation engine
40. SLA engine
41. Human takeover
42. Retry/replay

## P1 — Integrations

43. Stripe
44. e-sign provider
45. Calendar
46. Google Workspace
47. CRM
48. Twilio
49. Slack
50. Generic connector framework

## P2 — AI intelligence

51. Onboard Agent
52. Document intelligence
53. Intake analysis
54. Sales-to-delivery handoff
55. Promise register
56. Scope detection
57. Risk detection
58. Communication intelligence
59. AI evidence/confidence

**Items 1–59 are mandatory core release upgrades and are fully enumerated in `V2-UPGRADE-MANIFEST.md` and `59-UPGRADE-TRACEABILITY.md`.**
60. AI policy engine
61. AI evaluation suite
62. AI cost controls

## P2 — Analytics

63. Funnel metrics
64. Delay-cause analysis
65. Client vs internal delay
66. Time-to-value
67. Automation impact
68. AI ROI
69. Template optimization

## P3 — Scale

70. White-label
71. Custom domains
72. Usage metering
73. SSO/SCIM
74. Data residency
75. Advanced compliance
76. Durable workflow engine migration if required
77. Vertical packs
78. Adaptive onboarding
79. Customer Operations expansion

## Release gates

Do not call the system production-ready until:
- cross-tenant security tests pass
- duplicate webhooks are harmless
- retries are idempotent
- workflow resumes after worker failure
- stale writes return 409
- external provider outages create recoverable exceptions
- backups have been restored successfully in a test
- AI golden tests pass
- client portal has complete loading/error/empty states
- all critical actions are audited
