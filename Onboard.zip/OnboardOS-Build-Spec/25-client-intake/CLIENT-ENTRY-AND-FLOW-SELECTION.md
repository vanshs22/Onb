# Client Entry & Flow Selection

## Purpose
A paying OnboardOS customer can create an end customer manually, enter known identity/contact/business/commercial information, choose how that customer will be onboarded, preview the exact execution plan, and activate it.

## Entry modes
- Manual create
- CRM/API import
- Deal-won webhook
- CSV/bulk import
- Duplicate from existing customer

## Manual create fields
### Identity and contact
- Legal/business name
- Display name
- Contact first/last name
- Contact email(s)
- Contact phone(s)
- Website
- Industry
- Country/region
- Address
- Timezone

### Commercial
- Service/package purchased
- Deal value/currency
- Contract status
- Invoice/payment status
- Start date
- Target activation date
- Sales owner
- Account owner
- Notes
- Tags
- External CRM/deal ID

### Optional/custom
- Billing address
- Tax/business identifiers where applicable
- Additional contacts
- Tenant-defined custom fields

## Choose the onboarding flow
The user can select:
1. **Prebuilt OnboardOS flow**
2. **My global flow**
3. **Service-specific flow**
4. **Customize for this customer**
5. **Create from scratch**

Customization can add, remove, reorder, branch, or configure steps, requirements, documents, forms, payments, signatures, reminders, assignments, SLAs, conditions and integrations.

## Activation preview
Before activation, show exactly:
- Customer and recipients
- Selected flow + version
- Step sequence
- Documents/invoices that will be generated
- Signature/payment actions
- Forms and requirements
- Emails/SMS/other messages
- Integrations to connect
- Due dates/SLA
- Client-visible actions
- Internal actions
- Missing configuration and warnings

Actions: Save Draft, Save as Flow, Activate Now, Schedule Activation.

## Flow inheritance
`Customer override > Service flow > Tenant global flow > OnboardOS starter flow`

At activation, the chosen flow and referenced document/template versions are pinned. Later edits do not silently change an active onboarding.

## Safety
- Require validation before activation.
- Clearly distinguish draft from active.
- Never externally send a document or invoice during activation unless the selected policy explicitly allows auto-send; otherwise show it in the activation preview for confirmation.
- Require recipient and sender validation.
- Prevent accidental duplicate activation.
- Use idempotency and audit logging.
- Require approval for tenant-configured high-risk/high-value flows.
