# OnboardOS v3 — Activation, Friction & Learning Intelligence

## Activation model

Every service template defines machine-readable activation criteria.

```json
{
  "service": "website_seo",
  "activation": [
    {"key": "site_live", "type": "verified_event"},
    {"key": "analytics_connected", "type": "integration_health"},
    {"key": "seo_baseline_recorded", "type": "evidence"},
    {"key": "client_approval", "type": "approval"}
  ]
}
```

Completion is not activation. Activation requires all configured gates and successful verification.

## Customer friction model

Track:

- requests sent
- requests repeated
- form completion time
- upload retries
- failed evidence attempts
- customer inactivity
- support questions
- portal navigation loops
- clarification requests
- reschedules
- approval latency
- number of required customer actions

Derived metrics:

- Customer Effort Index
- Friction by stage
- Friction by template
- Friction by segment
- Friction by requirement
- Friction by channel

## Portfolio intelligence

The dashboard should answer:

- What is at risk?
- Why is it at risk?
- What is the root cause?
- What is the predicted impact?
- What can AI do now?
- What requires a human?
- Which bottleneck affects the most customers?
- Which workflow version performs better?

## Scope drift

Every requested change is compared against:

- Promise Graph
- contract
- SOW
- order form
- approved change orders
- current delivery plan

Classification:

`IN_SCOPE | AMBIGUOUS | OUT_OF_SCOPE | DUPLICATE | ALREADY_DELIVERED`

Out-of-scope requests may trigger a change-order draft, never an automatic scope commitment unless explicitly authorized.

## Workflow experimentation

Experiments are versioned and tenant-scoped.

```text
Workflow A → activation 18.2 days → effort 31
Workflow B → activation 15.7 days → effort 24
```

The platform may recommend a winner internally but never silently changes the production workflow. Publishing requires configured approval.

## Learning Agent

Inputs:

- completed onboarding twins
- exceptions
- requirement delays
- evidence failures
- activation outcomes
- customer effort
- scope changes
- provider failures

Outputs:

- proposed template change
- proposed requirement ordering
- proposed reminder timing
- proposed evidence rule
- proposed automation
- proposed policy change

Every proposal contains supporting evidence and expected impact. Publishing is human-controlled.
