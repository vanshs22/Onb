# OnboardOS Premium Starter Wording

These are product-ready business templates intended as editable starting points. They must be reviewed for the user's jurisdiction, industry and transaction before being used as legal advice or a final legal instrument.

## 1. Professional Services Agreement — Core

### 1. Parties and Effective Date
This Professional Services Agreement (the “Agreement”) is entered into as of {{agreement.effective_date}} by and between {{company.legal_name}}, a {{company.entity_type}} (“Provider”), and {{client.legal_name}}, a {{client.entity_type}} (“Client”).

### 2. Services
Provider will perform the services and deliver the deliverables described in one or more Statements of Work (“SOWs”) accepted by the parties. Each SOW identifies the applicable scope, assumptions, deliverables, timing, fees and acceptance criteria.

### 3. Client Responsibilities
Client will provide timely access, information, approvals, materials and decisions reasonably required to perform the Services. Client delays may affect delivery dates and dependencies.

### 4. Fees and Payment
Client will pay the fees stated in the applicable SOW or invoice. Unless otherwise stated, invoices are due {{payment.terms}} from the invoice date. Taxes, duties or similar charges are handled as stated in the applicable SOW and as required by law.

### 5. Changes to Scope
Requests outside the agreed scope may be documented as a Change Order. A Change Order should identify the requested change and any resulting effect on fees, timing, resources or deliverables. Work outside the agreed scope does not become binding merely because it is discussed informally.

### 6. Acceptance
Where an SOW specifies acceptance criteria, Client will review the applicable deliverable within {{acceptance.review_period}} business days. The parties should document rejected deliverables and the applicable reasons for rejection.

### 7. Confidentiality
Each party will use reasonable care to protect non-public information received from the other party and will use such information only for purposes related to the engagement, subject to customary exclusions and permitted disclosures.

### 8. Intellectual Property
Ownership and license rights are governed by the applicable SOW. Unless the SOW states otherwise, Provider retains ownership of its pre-existing materials, tools, methods, templates and know-how, while Client receives the rights expressly granted for the paid deliverables.

### 9. Third-Party Services
Services may depend on third-party platforms. Provider is not responsible for availability, policy changes or failures of third-party services outside Provider’s reasonable control.

### 10. Term and Termination
The term and termination rights are stated in the Agreement and/or applicable SOW. Termination does not remove obligations that accrued before termination.

### 11. Notices
Formal notices will be sent to the contact details designated by each party. Operational communications may be delivered through the agreed communication channels.

### 12. Entire Agreement and Amendments
This Agreement and its SOWs constitute the parties’ agreement concerning the Services and supersede prior written terms concerning the same subject matter, subject to applicable law. Amendments should be documented and approved by authorized representatives.

### Signature
Provider: {{company.legal_name}} — {{signing.provider_name}} — {{signing.provider_date}}
Client: {{client.legal_name}} — {{signing.client_name}} — {{signing.client_date}}

## 2. Statement of Work — Core

**Project:** {{engagement.name}}

**Objective:** {{scope.objective}}

**Deliverables:**
{{scope.deliverables}}

**Out of Scope:**
{{scope.exclusions}}

**Milestones:**
{{scope.milestones}}

**Client Dependencies:**
{{scope.client_dependencies}}

**Fees:** {{pricing.total}}

**Payment Schedule:** {{pricing.schedule}}

**Acceptance Criteria:** {{acceptance.criteria}}

**Target Dates:** {{scope.target_dates}}

## 3. Change Order — Core

**Requested change:** {{change.description}}

**Reason:** {{change.reason}}

**Effect on scope:** {{change.scope_impact}}

**Effect on timing:** {{change.schedule_impact}}

**Additional fee/credit:** {{change.price_impact}}

**Approval:** This Change Order becomes effective when approved by authorized representatives of both parties.

## 4. Professional Invoice — Core

**INVOICE {{invoice.number}}**

From: {{company.legal_name}}
To: {{client.legal_name}}
Issue date: {{invoice.issue_date}}
Due date: {{invoice.due_date}}
Reference: {{invoice.reference}}

| Description | Qty | Unit price | Amount |
|---|---:|---:|---:|
| {{line.description}} | {{line.quantity}} | {{line.unit_price}} | {{line.amount}} |

Subtotal: {{invoice.subtotal}}
Discount: {{invoice.discount}}
Tax: {{invoice.tax}}
Credits/deposit: {{invoice.credits}}
**Amount due: {{invoice.amount_due}}**

**Pay securely:** {{payment.link}}

Payment terms: {{invoice.payment_terms}}
Questions: {{company.billing_email}}

## 5. Payment Reminder — Core

Subject: Payment reminder — {{invoice.number}}

Hello {{client.primary_name}},

This is a friendly reminder that invoice {{invoice.number}} for {{invoice.amount_due}} is due on {{invoice.due_date}}. You can review and pay the invoice securely here: {{payment.link}}.

If payment has already been made, please disregard this message. If you need help with the invoice, contact {{company.billing_email}}.

## 6. Welcome Letter — Core

Subject: Welcome to {{company.legal_name}}

Hello {{client.primary_name}},

Welcome. We’re excited to work with {{client.legal_name}}. Your onboarding workspace is now ready. We’ll use it to collect the information, approvals and access required to begin the engagement and keep you informed of progress.

Your next step is: {{onboarding.next_action}}.

You can return to your workspace here: {{onboarding.portal_url}}.

Thank you,
{{account_manager.name}}
