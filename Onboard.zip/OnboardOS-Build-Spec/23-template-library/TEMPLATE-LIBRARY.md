# OnboardOS — Premium Template Library

## Built-in template families

### Agreements
1. Professional Services Agreement
2. Master Services Agreement
3. Statement of Work
4. Project Agreement
5. Retainer Agreement
6. Consulting Agreement
7. SaaS Implementation Agreement
8. Agency Services Agreement
9. NDA — Mutual
10. NDA — One-way
11. Data Processing Addendum
12. Change Order
13. Renewal / Amendment

### Commercial documents
14. Proposal
15. Quote
16. Order Form
17. Welcome Letter
18. Scope Summary
19. Kickoff Confirmation
20. Project Completion / Handoff

### Billing
21. Standard Invoice
22. Deposit Invoice
23. Milestone Invoice
24. Recurring Invoice
25. Final Invoice
26. Credit Note
27. Payment Request
28. Payment Reminder
29. Receipt / Payment Confirmation
30. Refund Confirmation

## Default wording philosophy
Templates should be:
- plain-English first
- specific about parties, scope, fees, timing and responsibilities
- explicit about acceptance/signature
- explicit about payment terms
- clear about change requests and out-of-scope work
- clear about client dependencies
- clear about approvals and delays
- structured for easy legal review
- free of fake guarantees or unsupported claims

## Agreement block library
Reusable blocks:
- Parties
- Effective Date
- Services
- Deliverables
- Scope / exclusions
- Client responsibilities
- Provider responsibilities
- Fees and payment terms
- Taxes
- Expenses
- Change control
- Acceptance
- Client delays
- Confidentiality
- Intellectual property
- Third-party services
- Data protection
- Security
- Warranties/disclaimers
- Limitation of liability
- Indemnity
- Term/termination
- Suspension for non-payment
- Dispute/governing law placeholder
- Notices
- Entire agreement
- Amendment
- Signature

The legal blocks are configurable and should be reviewed for the customer's jurisdiction before production use.

## Invoice design
Every invoice template includes:
- issuer brand
- invoice number
- issue date
- due date
- bill-to details
- service description
- line items
- subtotal
- discount
- tax
- credits/deposit
- amount due
- currency
- payment CTA
- bank/payment instructions
- terms/footer
- contact details

## Template provenance
Every template has:
- source: built-in / imported / duplicated
- owner
- version
- status: draft / approved / archived
- jurisdiction/locale metadata
- legal-review status
- last updated
- change log

No template can be silently changed after a document is issued. New versions apply only to future documents unless explicitly migrated.
