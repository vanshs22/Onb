# 59 Upgrade Traceability Matrix

This is the implementation cross-reference for upgrades 1–59. The number maps directly to `17-implementation-v2/BUILD-ORDER.md` and `V2-UPGRADE-MANIFEST.md`.

| # | Upgrade | Primary spec | Primary acceptance signal |
|---:|---|---|---|
| 1 | Tenant + authorization | 02, 08, 14 | cross-tenant access denied |
| 2 | Canonical PostgreSQL | 03, 12 | FK/index/migration checks |
| 3 | Immutable versions | 03, 06, 14 | onboarding pinned to versions |
| 4 | State machine | 01, 02, 06 | invalid transition rejected |
| 5 | Requirement engine | 03, 14 | requirement drives readiness |
| 6 | Evidence + verification | 03, 14, 09 | evidence provenance recorded |
| 7 | Readiness gates | 03, 14 | blocked stage cannot advance |
| 8 | Dependency graph | 03, 06 | dependent work recalculates |
| 9 | Transactional outbox | 02, 05, 13 | state + event atomic |
| 10 | Idempotency | 04, 05, 13 | duplicate mutation harmless |
| 11 | Webhook persistence | 05, 10, 13 | duplicate/replay safe |
| 12 | Optimistic concurrency | 04, 13 | stale write returns 409 |
| 13 | Audit/security events | 03, 08, 13 | privileged mutation audited |
| 14 | Error contract | 04, 13 | stable error code + correlation ID |
| 15 | Reconciliation/repair | 10, 13 | provider drift recoverable |
| 16 | Client portal shell | 07, 16 | authenticated branded portal |
| 17 | Next Best Action | 09, 14, 16 | CTA changes with state |
| 18 | Requirements UI | 07, 16 | client sees only assigned needs |
| 19 | Forms | 04, 07, 16 | autosave + version pinning |
| 20 | Documents | 07, 10, 16 | quarantine + verification |
| 21 | Approvals | 04, 07, 16 | immutable decision |
| 22 | Payments | 04, 10, 16 | reconciled payment state |
| 23 | Meetings | 07, 10, 16 | timezone-safe sync |
| 24 | Messages | 07, 10, 16 | realtime thread |
| 25 | Timeline | 07, 16 | client-safe event projection |
| 26 | Client AI | 09, 16 | grounded + permissioned |
| 27 | Command Center | 07, 16 | operational portfolio view |
| 28 | Onboarding detail | 07, 14 | 360° operational record |
| 29 | Exception Inbox | 07, 13 | recoverable exception lifecycle |
| 30 | Readiness view | 07, 14 | evidence-backed readiness |
| 31 | Workflow debugger | 07, 13 | traceable run/replay |
| 32 | Integration health | 10, 13 | connector health visible |
| 33 | Audit viewer | 08, 13 | filtered immutable audit |
| 34 | Global search | 07, 13 | permission-aware search |
| 35 | Saved views | 07 | saved operational filters |
| 36 | Workflow engine | 02, 06 | durable versioned run |
| 37 | Wait/condition/action | 06 | deterministic transitions |
| 38 | Reminder engine | 06, 10 | deduped channel reminders |
| 39 | Escalation engine | 06, 13 | escalation creates work |
| 40 | SLA engine | 06, 15 | business-calendar SLA |
| 41 | Human takeover | 06, 08 | automation pauses safely |
| 42 | Retry/replay | 05, 06, 13 | no duplicate side-effects |
| 43 | Stripe | 10 | webhook/reconciliation |
| 44 | E-sign | 10 | provider abstraction |
| 45 | Calendar | 10 | synced meeting state |
| 46 | Google Workspace | 10 | least-privilege OAuth |
| 47 | CRM | 10 | source-of-truth rules |
| 48 | Twilio | 10 | consent + delivery state |
| 49 | Slack | 10 | internal notification/action |
| 50 | Generic connectors | 10 | reusable connector lifecycle |
| 51 | Onboard Agent | 09 | evidence-backed decisions |
| 52 | Document intelligence | 09 | extracted evidence trace |
| 53 | Intake analysis | 09 | contradiction/missing-field detection |
| 54 | Sales-to-delivery handoff | 09, 14 | source-linked handoff record |
| 55 | Promise register | 09, 14 | commitments have evidence/source |
| 56 | Scope detection | 09, 14 | suspected change routed for review |
| 57 | Risk detection | 09, 14 | risk has evidence/action |
| 58 | Communication intelligence | 09 | thread summary/action extraction |
| 59 | AI evidence/confidence | 09, 13 | model/policy/evidence/result logged |

## Cross-cutting test suites

Every release must exercise the traceability matrix plus:

- tenant isolation
- permission boundaries
- idempotency
- concurrency conflicts
- webhook duplicates
- worker crash/restart
- provider outage
- realtime reconnect
- file security
- AI prompt/policy/version traceability
- client projection leakage
- backup restore
- accessibility
- mobile portal flows
