# OnboardOS v2 — Domain Model

## Core conceptual shift

The system must evolve from **task-centric onboarding** to **requirement-centric readiness**.

A task says someone has work to do. A requirement says something must be true before the customer can progress.

## Primary hierarchy

```text
Organization
  ├── Client
  │     └── Contacts / Stakeholders
  │
  ├── Deal Snapshot
  │     └── Engagement
  │            ├── Scope Version
  │            ├── Promise Register
  │            └── Onboarding Instance
  │
  └── Knowledge / Policies / Integrations
```

## Requirement model

```text
requirements
- id
- organization_id
- onboarding_id
- type
- title
- owner_type
- owner_id
- status
- due_at
- blocking
- client_visible
- verification_policy_id
- source_template_version
- created_at / updated_at
```

### Evidence

```text
requirement_evidence
- requirement_id
- evidence_type
- source_id
- submitted_by
- submitted_at
- metadata
- checksum
```

### Verification

```text
requirement_verifications
- requirement_id
- evidence_id
- method
- ruleset_version
- status
- confidence
- findings
- verified_by
- verified_at
```

## Readiness gates

A gate is a deterministic predicate over requirements and other state.

Examples:

### Ready for Kickoff
- contract signed
- payment complete
- primary contact confirmed
- required intake verified
- required documents verified
- required access verified
- kickoff booked
- internal preflight passed

### Ready to Launch
- implementation tasks complete
- required approvals complete
- tracking verified
- billing active
- launch QA passed

Gate results must store:
- evaluated_at
- policy_version
- pass/fail
- blocking reasons
- warnings
- override information

## Engagement

An engagement represents a commercial service relationship. A client may have many engagements and each engagement may have its own onboarding.

This avoids forcing one client record to represent multiple packages/projects.

## Promise Register

Every material promise can be captured from:
- CRM
- proposal
- contract
- sales notes
- call transcript
- manually entered promise

Each promise has:
- source
- source location
- contracted flag
- owner
- delivery requirement
- status
- conflict status

## Scope Change

A client request that may alter contracted work becomes a scope-change record rather than a chat-only event.

## Exception

Exceptions are first-class operational records, not merely dashboard cards.

Lifecycle:
`OPEN → ACKNOWLEDGED → IN_PROGRESS → SNOOZED → RESOLVED → REOPENED`

Each exception stores root cause, owner, severity, affected objects, SLA, AI attempts, recommended action, and resolution.

## Versioning rule

Any template/workflow/form/policy used by a live onboarding is pinned to an immutable version/snapshot.

Existing onboardings do not silently inherit future template changes.

## Derived state

Fields such as progress, health, risk, current stage and next action are cached read-model values, not the ultimate source of truth.

They must be rebuildable from canonical state.
