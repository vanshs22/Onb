# OnboardOS v2 — Security, Reliability & Compliance Baseline

## Tenant isolation

Every tenant-owned operational table should carry `organization_id` unless there is a documented reason not to. RLS is defense in depth, not a replacement for service-layer authorization.

Every query path must resolve organization membership server-side. Never trust a client-provided organization ID.

## Authentication

Support:
- secure sessions
- refresh-token rotation
- MFA/passkeys for admins where available
- step-up authentication for sensitive actions
- session revocation
- device/session visibility

Enterprise foundation:
- SAML/OIDC SSO
- SCIM

## Authorization

Use RBAC + resource ownership + action policy.

Sensitive actions require explicit permissions:
- refunds
- deleting data
- exporting data
- changing security settings
- sending legal documents
- modifying scope/pricing
- approving high-risk AI actions

## Secrets

Store secret metadata in Postgres; actual credentials/tokens in a dedicated secret-management mechanism. Never expose provider secrets to the browser. Never log raw credentials.

## File security

Upload pipeline:

```text
upload
↓
quarantine
↓
malware/type/size validation
↓
checksum
↓
optional OCR/extraction
↓
AI analysis
↓
verification
↓
trusted storage state
```

Use signed, short-lived URLs.

## HTTP action security

Generic HTTP actions require:
- domain allowlists
- SSRF protection
- private-IP blocking
- DNS rebinding protection
- timeout
- response-size limits
- credential scope restrictions

## Audit

Maintain separate records for:
- business audit
- security events
- AI actions
- integration events

Audit records should be append-only from the application perspective.

## Observability

Every request should have:
- request ID
- trace ID
- organization ID
- actor ID

Every workflow should have:
- workflow ID
- run ID
- onboarding ID
- correlation ID

Track:
- API latency/errors
- queue depth
- workflow failures
- webhook failures
- integration health
- AI latency/cost/errors
- database health

## Backups and disaster recovery

Define and test:
- backup frequency
- point-in-time recovery
- RPO
- RTO
- restore procedure
- restore verification

A backup that has never been restored is not a tested recovery plan.

## AI governance

Every AI action records:
- agent version
- model
- prompt version
- input sources
- evidence
- confidence
- proposed action
- policy decision
- approval
- execution result
- verification result
- cost

AI should not bypass deterministic business rules.
