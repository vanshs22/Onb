# API Error & Concurrency Contract

All API errors use a predictable envelope:

```json
{
  "error": {
    "code": "DEPENDENCY_NOT_MET",
    "message": "Google Ads access is required before campaign setup can begin.",
    "details": {},
    "request_id": "uuid",
    "trace_id": "uuid",
    "retryable": false,
    "field_errors": []
  }
}
```

Core codes:
- `VALIDATION_ERROR`
- `AUTHENTICATION_REQUIRED`
- `FORBIDDEN`
- `NOT_FOUND`
- `CONFLICT`
- `STATE_TRANSITION_INVALID`
- `DEPENDENCY_NOT_MET`
- `RATE_LIMITED`
- `EXTERNAL_PROVIDER_ERROR`
- `INTEGRATION_AUTH_EXPIRED`
- `AI_APPROVAL_REQUIRED`
- `SERVICE_UNAVAILABLE`

Use `409` for stale-version writes and conflicting state changes.
Use `422` for semantically invalid but well-formed requests.
Use `429` for rate limits.
Use `503` for temporary service/provider availability where retry is appropriate.
