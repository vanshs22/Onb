# OnboardOS v2 — Production Architecture

## Non-negotiable architectural rule

**PostgreSQL is the source of truth. n8n is an integration/execution adapter, not the business state machine.**

## Transactional command flow

```text
HTTP/Webhook/Worker command
        ↓
Authentication
        ↓
Tenant authorization
        ↓
Policy validation
        ↓
Domain service
        ↓
DB transaction
  ├─ mutate canonical state
  ├─ write domain event
  └─ write outbox record
        ↓
Commit
        ↓
Outbox publisher
        ↓
Durable consumers
  ├─ workflow engine
  ├─ integrations
  ├─ realtime/read model
  ├─ notifications
  └─ analytics
```

## Durable workflow recommendation

MVP: Postgres + BullMQ is acceptable.

Production long-running workflows: strongly consider a durable workflow engine such as Temporal once workflows require multi-day waits, signals, retries, recovery, approvals and complex branching.

## Event envelope

Every event should contain:

```json
{
  "event_id": "uuid",
  "event_type": "requirement.verified",
  "event_version": 1,
  "organization_id": "uuid",
  "aggregate_type": "onboarding",
  "aggregate_id": "uuid",
  "sequence_number": 42,
  "occurred_at": "timestamp",
  "actor": { "type": "user|client|system|ai", "id": "uuid" },
  "correlation_id": "uuid",
  "causation_id": "uuid|null",
  "idempotency_key": "string|null",
  "source": "api|webhook|worker|workflow",
  "payload": {}
}
```

## Outbox

State mutation and event creation happen in one DB transaction. A publisher delivers outbox messages to consumers. Consumers are idempotent.

## Webhooks

Persist every inbound delivery before processing.

Lifecycle:
`RECEIVED → VERIFIED → QUEUED → PROCESSED`

Failure states:
`DUPLICATE`, `INVALID_SIGNATURE`, `FAILED`, `DEAD_LETTERED`.

Support replay from stored payload after verification.

## Idempotency

All side-effect operations accept an idempotency key. Store the request fingerprint, response/result and expiration.

## Concurrency

Use optimistic versioning on mutable aggregates. Stale writes return `409 CONFLICT` rather than silently overwriting newer state.

## Reconciliation

Periodic reconciliation jobs compare authoritative external systems with OnboardOS:
- Stripe
- e-sign provider
- CRM
- calendar
- communication provider
- integration access

Mismatches become exceptions or deterministic repair actions.

## Repair operations

Authorized operators can:
- rebuild onboarding read model
- recalculate health/progress
- replay event
- retry workflow step
- reprocess webhook
- re-sync integration
- re-run document verification

Every repair is audited.

## Source-of-truth matrix

| Domain | Authority |
|---|---|
| Onboarding requirements | OnboardOS |
| Readiness | OnboardOS |
| Payment status | Stripe |
| Signature status | e-sign provider |
| Calendar booking | Calendar/Calendly |
| CRM lifecycle | CRM |
| Client communications | OnboardOS + provider delivery state |
| Integration credentials | Secret manager |

## Reliability targets

Define per plan:
- API availability target
- worker success target
- webhook processing latency
- realtime propagation latency
- recovery objectives

Do not claim an SLA before it is measured.
