# OnboardOS — AI Layer Specification

## 1. Design principles

- AI is an **operations manager**, not a chatbot bolted on.
- Every AI output is grounded in org knowledge + current onboarding state.
- Human-in-the-loop controls are mandatory for high-risk actions.
- All runs are logged (`ai_runs`, `ai_actions`) for audit and improvement.
- Prefer structured outputs (JSON schema) over free text for system decisions.

---

## 2. Named agents

### 2.1 Onboard Agent (central)
**Questions it continuously answers:**
1. What is missing?
2. What is blocking progress?
3. What should happen next?
4. Can I resolve it automatically?

**Capabilities:**
- Detect overdue / inactive tasks
- Draft or send contextual reminders
- Escalate according to rules
- Update health score explanations
- Recommend next best action to staff
- Answer client questions in portal (grounded)

### 2.2 Document Intelligence Agent
**Input:** Uploaded PDF / image / doc  
**Output (structured):**
```json
{
  "extracted": {
    "company_name": "...",
    "logo_present": true,
    "primary_colors": ["#..."],
    "fonts": ["..."],
    "brand_voice": "...",
    "target_audience": "...",
    "social_links": [],
    "policy_number": "...",
    "expiry_date": "..."
  },
  "validation": [
    { "rule": "logo_required", "status": "pass|fail", "message": "..." },
    { "rule": "coverage_min", "status": "fail", "message": "Coverage below configured minimum" }
  ],
  "conflicts": [
    "Brand guide lists three markets; form listed one — confirm"
  ]
}
```

### 2.3 Intake Analysis Agent
Converts free-text client answers into structured internal data and may auto-adjust checklist (e.g., add Google Ads tasks when “paid acquisition” is detected).

### 2.4 Sales-to-Delivery Handoff Agent
Ingests CRM deal, proposal, contract, emails, call notes → produces **Client Brief**:
- Company, goals, package, scope, deliverables, timeline, stakeholders, budget, pain points, promises, special requirements, risks, integrations, success criteria.

### 2.5 Promise / Scope Detection Agent
Compares proposal vs contract vs sales notes vs current onboarding configuration and flags mismatches.

### 2.6 Risk Detection Agent
Signals:
- No login / no response
- Late task
- Negative sentiment
- Conflicting information
- Missing critical document
- Unpaid / unsigned
- Blocked dependency
- Approaching SLA breach
- Repeated revisions

Outputs risk level: LOW | MEDIUM | HIGH | CRITICAL + explanation + recommended actions.

### 2.7 Communication Intelligence Agent
Summarizes threads:
- Sentiment
- Main concern
- Last request
- Unresolved items

### 2.8 Template Generator Agent
Admin natural language → full onboarding template draft.

### 2.9 Setup Assistant Agent
New customer onboarding of the product itself:
- What do you sell?
- Who do you sell to?
- What happens after someone signs?
- What information / documents do you need?
- What software do you use?
- What normally delays onboarding?
→ Produces first working system ready for review.

---

## 3. Health score model

Score 0–100 composed of weighted factors:

| Factor | Weight example | Notes |
|--------|----------------|-------|
| Required tasks completion | 30% | |
| Critical blockers present | 25% | Binary heavy penalty |
| Days since last client activity | 15% | Decay |
| Payment / contract status | 15% | |
| Overdue task count | 10% | |
| SLA risk | 5% | |

Always return **explanation**:
```
ONBOARDING HEALTH — 82/100  Green
✓ Contract signed
✓ Payment complete
✓ Kickoff booked
⚠ Brand assets incomplete
⚠ Client inactive 2 days
🔴 Google Ads access missing — blocks campaign setup
```

---

## 4. Client AI assistant (portal)

Grounded answers only. Examples:

- “Where do I upload my logo?”  
  → “Go to Brand Assets → Upload Files. We need SVG/PNG. This is the last required asset before kickoff can be finalized.”

- “Why can’t I access the Meta Ads step?”  
  → “That step becomes available after your business questionnaire is completed.”

Never invent policy; fall back to “I don’t have that information — contact your account manager” when knowledge is missing.

---

## 5. Learning loop (post-V1)

After sufficient completed onboardings:
- Discover common extra steps per package
- Correlate delay patterns (e.g., asset delay → 2.4× miss kickoff)
- Surface integration failure rates
- Suggest template optimizations (“Move logo request earlier”)

This becomes long-term data moat.

---

## 6. Technical notes

- Use structured output / function calling for all decision agents.
- Embeddings (pgvector) for knowledge base RAG.
- Rate limit & cost controls per org plan.
- Store prompts + version so behavior is reproducible.
- Redact PII from logs where required by retention policy.

---

## v2 AI governance

AI follows:

```text
Observation
→ Evidence
→ Inference
→ Confidence
→ Recommendation
→ Policy check
→ Human approval if required
→ Execution
→ Verification
```

AI never becomes the source of truth for deterministic state.

Every AI action records agent version, model, prompt version, input sources, evidence, confidence, policy decision, approval, execution result, verification result and cost.

Add:
- AI policy engine
- AI evaluation/golden test suite
- prompt/model versioning
- cost budgets
- source citations for grounded answers
- human override tracking

## v3 agent workforce

The named agents are now an executable workforce. See `26-agentic-onboarding-os/AGENTIC-ONBOARDING-OS.md` and `28-agent-execution/AGENT-EXECUTION-RUNTIME.md`.

Agents collaborate through durable handoff events and typed tools. The Orchestrator does not directly perform provider side effects. Every agent action is authorized, idempotent where required, verified after execution, and recorded in the AI/audit trail.
