# OnboardOS — Workflow Engine & Schema

## 1. Philosophy

- Workflows are **definitions** stored in our database.
- Execution is durable (workflow_runs + steps).
- n8n is an **optional external action runner**, never the source of truth.
- Every step is idempotent and supports retry / timeout / compensation.

---

## 2. Workflow definition (JSON DSL)

```json
{
  "id": "wf_agency_standard",
  "name": "Agency Standard Onboarding",
  "trigger": {
    "type": "event",
    "event": "onboarding.created"
  },
  "nodes": [
    {
      "id": "send_welcome",
      "type": "action",
      "action": "email.send",
      "params": {
        "template": "welcome",
        "to": "{{client.primary_contact.email}}"
      }
    },
    {
      "id": "create_payment",
      "type": "action",
      "action": "payment.create",
      "params": {
        "amount_cents": "{{template.deposit_cents}}",
        "currency": "usd"
      }
    },
    {
      "id": "wait_payment",
      "type": "wait",
      "until": {
        "event": "payment.completed",
        "filter": { "instance_id": "{{instance.id}}" },
        "timeout_hours": 72
      }
    },
    {
      "id": "payment_branch",
      "type": "condition",
      "if": "{{payment.status}} == 'paid'",
      "then": "send_intake",
      "else": "payment_reminder"
    },
    {
      "id": "send_intake",
      "type": "action",
      "action": "task.activate",
      "params": { "task_key": "business_questionnaire" }
    },
    {
      "id": "payment_reminder",
      "type": "action",
      "action": "reminder.send",
      "params": {
        "channel": "email",
        "template": "payment_overdue",
        "escalate_after_hours": 48
      }
    }
  ]
}
```

---

## 3. Node types

| Type | Purpose |
|------|---------|
| `trigger` | Event, schedule, or manual |
| `action` | Send email, create task, call integration, AI action |
| `condition` | Branch on expression |
| `wait` | Wait for event or duration |
| `parallel` | Fan-out / fan-in |
| `approval` | Human-in-the-loop gate |
| `ai` | Invoke named AI agent |
| `webhook` | Call external HTTP endpoint |

---

## 4. Expression language

Simple path + comparison:

- `{{client.name}}`
- `{{instance.health_score}}`
- `{{task.status}}`
- `{{payment.amount_cents}} >= 50000`
- Functions: `days_since(date)`, `is_empty(value)`, `contains(list, item)`

---

## 5. Built-in actions (V1)

| Action | Description |
|--------|-------------|
| `email.send` | Transactional or Gmail |
| `sms.send` | Twilio |
| `whatsapp.send` | Template message |
| `slack.post` | Channel or DM |
| `task.create` / `task.activate` / `task.complete` | Task lifecycle |
| `payment.create` | Stripe checkout / invoice |
| `contract.send` | PandaDoc / DocuSign |
| `calendar.invite` | Google / Calendly |
| `notification.create` | In-app |
| `escalation.trigger` | Raise exception |
| `ai.run` | Named agent |
| `http.request` | Generic outbound |
| `crm.update` | HubSpot / Salesforce field write |

---

## 6. Permission levels for automated actions

| Level | Meaning | Default examples |
|-------|---------|------------------|
| 0 | Observe only | Logging |
| 1 | Draft | Draft email for human review |
| 2 | Low-risk auto | Reminder email, create task |
| 3 | Approved workflows | Reschedule (if policy allows) |
| 4 | Human required | Refund, contract change, data delete |

Org admins configure defaults per action type.

---

## 7. Smart reminder system

Never send dumb “Please complete your task.”

Context variables available to reminder templates:

- Task title & why it matters
- Days overdue
- Downstream blockers it is causing
- Client name & previous response history
- Preferred channel & quiet hours
- Tone (professional / friendly) from org settings

Example generated message:

> Hi Sarah — we’re almost ready for your kickoff. The only thing holding up setup is your Google Analytics connection. Once that is connected, our team can begin configuration.

---

## 8. Escalation rules (example)

```
Task due
  → +24h  → client reminder (email)
  → +48h  → WhatsApp / SMS
  → +72h  → account manager notification + Exception Inbox
  → +96h  → manager escalation
```

Rules are configurable per template / client tier.

---

## 9. Template engine (onboarding templates)

An onboarding template contains:

- Stages (ordered)
- Tasks (with visibility, owner type, SLA, dependencies)
- Forms & document requests
- Default messages & reminders
- Approvals
- Automations (workflow references)
- AI instructions (how to analyze intake, documents, risks)
- Integration requirements (Google Ads, Shopify, etc.)
- Conditional branches (SEO client vs Paid Ads client)

Conditional example:

```
Core
├── Contract
├── Deposit
├── Brand questionnaire
├── Brand assets
├── Access collection
├── Kickoff
└── Approval

SEO Client (if package contains SEO)
├── Google Search Console
├── GA4
├── Website access
└── Competitor list

Paid Ads Client (if package contains Paid)
├── Meta Ads access
├── Google Ads access
├── Pixel verification
└── Billing method
```

---

## 10. AI template generator

Admin prompt:

> “We are a performance marketing agency. Clients need to sign the agreement, pay 50%, submit brand assets, grant Meta and Google access, complete our questionnaire and book kickoff.”

System returns a complete template draft (stages, tasks, dependencies, suggested messages) ready for human edit.

## v3 agentic execution

`ai` nodes now execute named agents through the Agent Execution Gateway. Agents can create durable handoffs, call typed tools, wait for events, and continue after verification. See `28-agent-execution/AGENT-EXECUTION-RUNTIME.md`.

A workflow is not considered complete because an agent claims success; the runtime requires a persisted verification result. Agent budgets, tool allowlists, approval gates, idempotency keys and retry/DLQ behavior are enforced server-side.
