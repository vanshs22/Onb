# OnboardOS — Permissions & RBAC

## 1. Roles (minimum set)

| Role | Scope | Typical users |
|------|-------|---------------|
| Platform Owner | Platform | OnboardOS internal |
| Organization Owner | Org | Customer founder / primary admin |
| Admin | Org | Full operational control |
| Manager | Org | Oversees multiple onboardings |
| Onboarding Manager | Org | Day-to-day onboarding ownership |
| Employee | Org | Limited task execution |
| Viewer | Org | Read-only |
| Client Admin | Client | Primary client contact |
| Client User | Client | Secondary client users |
| External Collaborator | Client/Org | Limited external access |

White-label partners inherit a partner role that can manage sub-accounts.

---

## 2. Permission catalog

### Organization
- `org:view`
- `org:edit`
- `org:billing`
- `org:branding`
- `org:delete`

### Team
- `team:view`
- `team:invite`
- `team:edit_roles`
- `team:remove`

### Clients
- `client:view`
- `client:create`
- `client:edit`
- `client:delete`
- `client:export`

### Onboardings
- `onboarding:view`
- `onboarding:create`
- `onboarding:edit`
- `onboarding:transition`
- `onboarding:delete`
- `onboarding:invite_client`

### Tasks
- `task:view`
- `task:create`
- `task:edit`
- `task:complete`
- `task:assign`

### Documents
- `document:view`
- `document:upload`
- `document:download`
- `document:delete`
- `document:analyze`

### Contracts & Payments
- `contract:view`
- `contract:send`
- `payment:view`
- `payment:create`
- `payment:refund`          ← Level 4 / human only

### Communication
- `message:view`
- `message:send`
- `message:send_whatsapp`

### Approvals
- `approval:view`
- `approval:request`
- `approval:decide`

### Templates & Workflows
- `template:view`
- `template:edit`
- `workflow:view`
- `workflow:edit`
- `workflow:run`

### Integrations
- `integration:view`
- `integration:connect`
- `integration:disconnect`

### AI
- `ai:chat`
- `ai:run`
- `ai:approve_actions`

### Analytics & Audit
- `analytics:view`
- `audit:view`

### Data
- `data:export`
- `data:delete`             ← Level 4 / human only

---

## 3. Default role → permission matrix (summary)

| Permission | Owner | Admin | Manager | Onb Mgr | Employee | Viewer | Client Admin | Client User |
|------------|-------|-------|---------|---------|----------|--------|--------------|-------------|
| org:edit | ✓ | ✓ | | | | | | |
| team:invite | ✓ | ✓ | | | | | | |
| client:create | ✓ | ✓ | ✓ | ✓ | | | | |
| onboarding:create | ✓ | ✓ | ✓ | ✓ | | | | |
| onboarding:transition | ✓ | ✓ | ✓ | ✓ | | | | |
| task:complete | ✓ | ✓ | ✓ | ✓ | ✓ | | ✓ (own) | ✓ (own) |
| document:upload | ✓ | ✓ | ✓ | ✓ | ✓ | | ✓ | ✓ |
| payment:refund | ✓ | ✓ | | | | | | |
| message:send | ✓ | ✓ | ✓ | ✓ | ✓ | | ✓ | ✓ |
| approval:decide | ✓ | ✓ | ✓ | ✓ | | | ✓ (client) | ✓ (client) |
| template:edit | ✓ | ✓ | | | | | | |
| workflow:edit | ✓ | ✓ | | | | | | |
| integration:connect | ✓ | ✓ | | | | | | |
| ai:approve_actions | ✓ | ✓ | ✓ | ✓ | | | | |
| analytics:view | ✓ | ✓ | ✓ | ✓ | | ✓ | | |
| audit:view | ✓ | ✓ | | | | | | |
| data:delete | ✓ | | | | | | | |

---

## 4. Paying-client dashboard and end-customer workspace scoping

Client JWTs are issued with:
- `organization_id`
- `client_id`
- `contact_id`
- limited permission set

They can only see / act on resources belonging to their `client_id` and only client-visible tasks / documents / approvals.

---

## 5. Row Level Security (Postgres)

Every tenant table:

```sql
CREATE POLICY tenant_isolation ON <table>
  USING (organization_id = current_setting('app.current_org_id')::uuid);
```

For paying-client dashboard and end-customer workspace, apply separate organization/member vs engagement/contact scopes:

```sql
AND client_id = current_setting('app.current_client_id')::uuid
```

Set both from validated JWT claims in middleware.

---

## 6. AI action permission levels

| Level | Behavior |
|-------|----------|
| 0 | Observe / log only |
| 1 | Draft for human |
| 2 | Auto-execute low-risk (reminders, create task) |
| 3 | Execute if workflow pre-approved |
| 4 | Always require human approval (refund, legal, delete, price change) |

Org can override per action type in Settings → AI Preferences.

---

## 7. Audit requirements

Every permission-checked mutation that changes:
- client data
- contract / payment
- document
- role / membership
- AI high-level action

must write an audit_log entry with before/after, actor, source, IP where available.

## V2.4 Document/Billing permissions

`template.view`, `template.edit`, `template.publish`, `template.import`, `document.view`, `document.send`, `document.void`, `invoice.view`, `invoice.create`, `invoice.finalize`, `invoice.send`, `invoice.void`, `payment.view`, `commercial_flow.view`, `commercial_flow.edit`, `commercial_flow.override`, `billing.settings`, `billing.audit`.

Finance/legal-sensitive actions require explicit tenant permissions and are always audited.

## V2.5 Customer Creation Permissions

Tenant admins and authorized operations roles may create end customers and activate onboarding flows. Viewer roles may inspect but cannot activate. Activation permissions can require approval for high-value or high-risk commercial flows.
