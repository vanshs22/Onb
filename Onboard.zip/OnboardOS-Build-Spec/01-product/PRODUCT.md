# OnboardOS — Product Specification

## 1. Positioning

**Name:** OnboardOS  
**Category:** AI-powered Client Onboarding & Activation Operating System  

**One-liner:**  
From signed deal to fully onboarded client — automatically.

**What we are NOT:**  
Another client portal + forms + contract tool (Dubsado, Bonsai, Jotform already cover this).

**What we ARE:**  
The orchestration, intelligence, and execution layer that sits above existing tools and ensures the client actually reaches “ready to start / live / activated” without the business constantly chasing them.

---

## 2. Five ways a business can use OnboardOS

1. **Paying-client Operations Dashboard + end-customer onboarding workspace**
2. **Internal onboarding command center**
3. **AI onboarding manager**
4. **Automation layer** connecting existing software
5. **Fully managed onboarding service** (we operate it)

This multi-mode design enables software + services + white-label revenue.

---

## 3. The real problem (seven failure points)

| Failure | What happens |
|---------|--------------|
| Missing information | Client doesn’t submit something |
| Missing documents | Team waits for attachments |
| Unpaid | Work can’t begin |
| Unsigned | Agreement is stuck |
| Scheduling | Kickoff keeps getting delayed |
| Internal handoff | Sales promised something delivery didn’t know |
| Client inactivity | Nobody notices until days/weeks later |

OnboardOS turns these into an **automated state machine** with health scores, blockers, escalations, and AI actions.

---

## 4. Ideal onboarding lifecycle

```
DEAL WON
  → ONBOARDING CREATED
  → WELCOME
  → CONTRACT
  → PAYMENT
  → CLIENT INTAKE
  → DOCUMENT COLLECTION
  → INTERNAL PREFLIGHT
  → KICKOFF SCHEDULING
  → KICKOFF
  → IMPLEMENTATION
  → CLIENT APPROVALS
  → FINAL QA
  → ACTIVATION
  → HANDOFF TO CS
  → DAY 7 CHECK
  → DAY 30 CHECK
  → ONGOING CUSTOMER
```

Not every client follows the exact same path — **adaptive / conditional templates** are foundational.

---

## 5. Competitive strategy

**Integrate, don’t replace.**

Existing coverage we will not rebuild:
- Forms / questionnaires / portals → Dubsado, Bonsai, Jotform
- Structured B2B implementation → Rocketlane, GUIDEcx
- Documents + e-sign + payments → PandaDoc, DocuSign, Stripe
- Scheduling → Calendly / Google Calendar
- Orchestration across Workspace → Google Gemini / Workspace

Our differentiation:
1. Business workflow engine
2. Vertical onboarding templates
3. Onboarding intelligence (health, risk, blockers)
4. Historical onboarding data & learning
5. Exception detection & Exception Inbox
6. Dependency graph
7. AI validation (documents, scope, promises)
8. Deep integrations as orchestration layer
9. Outcome analytics (TTV, bottlenecks, completion rate)
10. Customer-specific business memory

---

## 6. Commercial packages

### Package 1 — Onboard Launch
- Branded portal, intake, documents, scheduling, payment, email automation, basic dashboard, checklist, basic reminders
- **Setup:** $1,000–$2,000 | **Monthly:** $149–$299

### Package 2 — Onboard Pro (primary offer)
- Everything in Launch + multiple templates, conditional workflows, AI assistant, AI document analysis, health, SLA, approvals, team assignments, Slack, CRM, advanced analytics, escalations
- **Setup:** $2,500–$5,000 | **Monthly:** $399–$799

### Package 3 — Revenue & Operations
- Full customer lifecycle: lead handoff → quote → payment → activation → review → renewal
- **Implementation:** $5,000–$10,000+ | **Monthly:** $999–$2,000+

### Package 4 — White Label
- Custom domain, branding, portal, emails, workflows, templates, AI instructions, sub-accounts
- Platform setup + license + per-client usage

### Package 5 — Enterprise / Custom
- SSO, advanced RBAC, custom integrations, multi-BU, audit, dedicated env, priority support

### Add-ons
WhatsApp, AI Document Intelligence, AI Voice, CRM Sync, Stripe, PandaDoc/DocuSign, Google Workspace, Slack/Teams, Advanced Analytics, Custom Integration, White Label, Managed Onboarding, Custom Workflow

---

## 7. Vertical packages (IP)

- Agency Pack
- MSP / IT Pack
- Accounting Pack
- Consulting Pack
- Recruitment Pack

Each contains stages, tasks, forms, documents, dependencies, messages, approvals, AI instructions.

---

## 8. Sales pitch (outcome, not features)

> “We install an automated client onboarding system inside your business that takes a client from signed deal to fully onboarded, automatically chases missing information, detects blockers, handles communications, and tells your team exactly what needs attention.”

Demo sequence (killer demo):
1. “Won Deal” → instant onboarding + portal + contract + invoice + welcome + Slack + tasks + kickoff invite
2. Simulate missing document → risk score rises → reminders → escalation
3. Upload PDF → AI extracts & validates against requirements

---

## 9. Implementation service (high-margin)

1. Map current onboarding  
2. Find bottlenecks  
3. Connect existing tools  
4. Build custom workflow  
5. Import templates / SOPs  
6. Configure AI  
7. Train staff  
8. Launch  
9. Monitor  
10. Optimize after 30 days  

Revenue streams: software + implementation + AI usage + support + custom integrations + managed service.

---

## v2 product evolution

The core product primitive is now a **Requirement**, not a Task.

A requirement defines what must be true for the client to progress. Evidence and verification prove it. Tasks are one way humans or systems satisfy requirements.

This enables:
- readiness gates
- evidence-based verification
- integration verification
- blocker explanations
- adaptive onboarding
- auditability
- predictive analytics

See `14-domain-model-v2/DOMAIN-MODEL.md`.

## Commercial deployment

OnboardOS is delivered through three modes:
- Managed onboarding
- Client-operated SaaS
- White-label partner

See `15-commercial-product/COMMERCIAL-MODEL.md`.
