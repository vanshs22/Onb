# OnboardOS — Integration Contracts

## Strategy

**Integrate, don’t rebuild.**  
Payments, e-sign, calendar, email infrastructure, WhatsApp, file storage connectors are provided by best-of-breed vendors.  
Our value is orchestration, state, intelligence, and client experience.

---

## Tier 1 — Must build for V1 / V1.5

| Integration | Purpose | Auth | Key events / webhooks |
|-------------|---------|------|------------------------|
| Google Workspace | Gmail, Drive, Calendar, Sheets | OAuth2 | message, calendar change |
| Microsoft 365 | Outlook, Calendar, OneDrive | OAuth2 | same |
| Stripe | Payments, invoices, billing portal | API key + webhook | `payment_intent.*`, `invoice.*` |
| PandaDoc / DocuSign | Contracts + e-sign | OAuth / API | document.completed, viewed, declined |
| Calendly | Scheduling | OAuth / webhook | invitee.created, canceled |
| HubSpot | CRM handoff | OAuth | deal.propertyChange (won) |
| Twilio | SMS + WhatsApp | API key | inbound message, status |
| Slack | Internal notifications | OAuth | — |
| Generic Webhooks | Anything else | HMAC signature | configurable |

### Notes
- WhatsApp: business-initiated messages outside the customer service window require **approved templates**. Store template status, consent, last contact, quiet hours.
- Google: leverage Workspace + Gemini orchestration where available, but keep our DB as source of truth.
- All inbound webhooks verified with signature + idempotency key.

---

## Tier 2 — Near-term

- Pipedrive, Salesforce, Zoho
- Monday, ClickUp, Asana, Notion
- QuickBooks, Xero
- Typeform, Jotform (import / compatibility)

---

## Tier 3 — Framework

Generic connector:
- REST API
- OAuth2 / API key
- Inbound webhook
- Outbound webhook / custom HTTP action
- Field mapping UI later

Claim: “Works with anything that has an API.”

---

## Integration record (DB)

```
integrations
  id, organization_id, provider, status, credentials_ref (encrypted),
  scopes, settings, last_sync_at, error_log

integration_credentials  -- encrypted secrets, rotated
```

---

## Common patterns

1. **Connect** → OAuth redirect → store tokens → encrypt → mark active  
2. **Action** → our workflow calls integration service → external API → result stored + event emitted  
3. **Webhook** → verify signature → idempotent process → emit domain event → update state machine  
4. **Failure** → retry → DLQ → surface in Exception Inbox  

---

## Do NOT build from scratch

- Payment processor
- E-signature infrastructure
- Calendar infrastructure
- Email delivery infrastructure (use transactional provider + Gmail/Outlook for connected mailboxes)
- WhatsApp Business Platform (use Twilio or Meta Cloud API)
- Full CRM or project management system

---

## Example: “Won Deal” cascade (HubSpot → OnboardOS)

1. HubSpot webhook: deal stage = Closed Won  
2. Create / update Client  
3. Create Onboarding Instance from matching template  
4. Emit `onboarding.created`  
5. Workflow: send welcome, create payment, create portal, assign tasks, create Slack channel, send kickoff invite  
6. All state lives in OnboardOS DB

---

## v2 connector contract

All connectors implement a common interface:

```text
auth
capabilities
actions
webhooks
healthCheck
fieldMapping
rateLimits
disconnect
```

Every integration has health states:
`CONNECTED | HEALTHY | DEGRADED | AUTH_EXPIRED | PERMISSION_CHANGED | RATE_LIMITED | ERROR | DISCONNECTED`

Every connector supports persisted webhook delivery records, idempotency, retry, replay and reconciliation.
