# Document & Billing UI

## Client Dashboard navigation
- Documents
- Agreements
- Invoices
- Payments
- Commercial Flows
- Templates

## Documents page
Cards/table showing:
- document type
- end-customer
- status
- amount if relevant
- issued date
- due/sign date
- template version
- next action

## Template Library
Sections:
- Recommended
- Agreements
- Proposals
- Billing
- Operations
- Imported by us
- Custom

Actions:
Preview / Duplicate / Edit / Test / Set Default / Archive / View Versions.

## Commercial Flow Builder
Canvas with a readable timeline:
`Agreement → Signature → Invoice → Payment → Intake`

Top controls:
- Global
- Service
- Per Customer

Right panel:
- node settings
- template
- timing
- blocking
- reminders
- escalation

## Invoice editor
Professional invoice preview beside editable fields. Always show calculated subtotal/tax/total and payment status.

## Agreement editor
Document preview + structured clause panel + variable panel + approval/signature settings.

## Client-specific override
At `Customer → Onboarding → Commercial Flow`, show the inherited global flow and allow an authorized user to choose `Use Global` or `Customize for This Customer`.

## UX principle
Never make operators configure raw JSON. Advanced settings can exist behind an Advanced section, but the normal path is visual and form-based.
