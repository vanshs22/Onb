# OnboardOS — Document & Billing Engine

## Purpose
A production-grade document, agreement, invoicing, payment-request, approval and billing layer. It gives every paying OnboardOS customer professional defaults while allowing global policies and per-end-customer overrides.

## Core principle
Documents are first-class workflow objects. A contract, invoice, payment request, approval, receipt or change order can trigger and gate onboarding stages.

## Supported document types
- Proposal / engagement letter
- Master Services Agreement (MSA)
- Service Agreement
- Statement of Work (SOW)
- Order Form
- NDA / mutual NDA
- Data Processing Addendum (DPA)
- Privacy / security addendum
- Change Order / Scope Change
- Renewal / amendment
- Welcome letter
- Kickoff brief / client welcome pack
- Invoice
- Deposit invoice
- Recurring invoice
- Milestone invoice
- Credit note
- Receipt / payment confirmation
- Payment request
- Refund confirmation
- Final handoff / completion certificate
- Custom document

> Legal templates are professionally structured starting points, not jurisdiction-specific legal advice. The business can lock approved legal language and require legal review before publication.

## Document lifecycle
Draft → Internal Review → Approved → Sent → Viewed → Signed/Accepted → Executed → Superseded/Voided/Expired.

Invoices use: Draft → Finalized → Sent → Viewed → Partially Paid → Paid / Overdue / Void / Uncollectible.

## Document generation
Every generated document stores:
- tenant and client ownership
- document type
- template ID + immutable template version
- data snapshot used to render it
- locale, currency, timezone
- issuer identity
- numbering sequence
- generated PDF/document hash
- approval state
- signature/payment provider IDs
- audit trail

Rendered documents must be reproducible from the immutable version and input snapshot.

## Smart variables
Examples:
{{company.legal_name}}
{{client.legal_name}}
{{client.billing_email}}
{{engagement.name}}
{{engagement.start_date}}
{{scope.summary}}
{{scope.deliverables}}
{{pricing.subtotal}}
{{pricing.tax}}
{{pricing.total}}
{{invoice.number}}
{{invoice.due_date}}
{{payment.link}}
{{signing.url}}
{{account_manager.name}}

Variables are typed, validated and previewable. Unknown variables cannot silently render blank in finalized documents.

## Document designer
Support:
- drag/drop sections
- rich text
- tables
- signatures
- initials
- checkboxes
- dates
- dynamic pricing tables
- tax lines
- payment instructions
- page headers/footers
- logo/brand kit
- conditional clauses
- conditional sections
- localization
- custom CSS/theme tokens where safe
- reusable blocks

## Professional default design system
Default documents should feel premium and restrained:
- clean typography
- strong hierarchy
- generous whitespace
- consistent margins
- branded cover/header
- clear section numbering
- accessible tables
- clear signature area
- invoice totals visually prominent
- print/PDF safe layout
- mobile-friendly web preview

Provide Light, Modern, Executive and Minimal variants, all driven by the tenant brand kit.

## Approvals
Configurable approval chains:
- no approval
- one internal approver
- finance approval
- legal approval
- two-person approval
- threshold-based approval

Example: any contract with discount > 20% requires finance approval.

## Signing
Provider abstraction for e-sign. A finalized contract can launch an e-sign envelope. Webhook events update the document without trusting browser state.

## Billing
Invoices support:
- line items
- quantities
- unit price
- discounts
- taxes
- deposits
- credits
- recurring schedules
- payment terms
- PO/reference numbers
- partial payments
- payment links
- hosted invoice page
- PDF download
- receipts
- overdue state
- reminders
- credit notes

## Provider abstraction
Use a BillingProvider interface so Stripe is not hardcoded into the domain. Provider adapters may include Stripe, Razorpay, PayPal, Square, Xero/QuickBooks sync and custom providers.

## Safety and reliability
- Never expose payment provider secrets to clients.
- Verify provider webhooks cryptographically.
- Idempotently process payment events.
- Finalized invoice numbers are immutable.
- Voiding creates an audit event rather than destructive deletion.
- Signed contracts are immutable; amendments create new versions/documents.
- Store signed document hash and provider envelope ID.
- Use signed, expiring file URLs.
- Restrict document download by tenant/client role.
- Log every send, view, sign, approve, void, download and payment transition.
