# Document & Billing Acceptance Tests

1. Create a contract from the default MSA template.
2. Preview with realistic test data.
3. Send for signature.
4. Receive verified signature webhook.
5. Mark agreement executed exactly once.
6. Trigger invoice according to global policy.
7. Verify invoice number is unique and immutable.
8. Send hosted invoice/payment link.
9. Receive verified payment webhook.
10. Mark invoice paid exactly once despite duplicate webhook.
11. Trigger next onboarding stage.
12. Change global policy and confirm existing onboarding remains pinned.
13. Create a per-customer override and verify it wins over global policy.
14. Send agreement + invoice in parallel and verify intake waits for both.
15. Import a DOCX with known and unknown variables.
16. Map variables and block publishing until required mappings are resolved.
17. Publish version 2 and verify version 1 documents remain unchanged.
18. Void an invoice and verify audit trail.
19. Issue a credit note and verify balance calculation.
20. Generate receipt after payment.
21. Test overdue reminders without duplicate sends.
22. Test payment failure escalation.
23. Test signature expiry/re-send.
24. Test permissions for finance, operator, manager, viewer.
25. Verify tenant isolation for all documents and invoices.
26. Verify signed URLs expire.
27. Verify audit events for create/edit/send/view/sign/pay/void/download.
28. Render PDF and verify no page overflow or clipped signature fields.
29. Test currency, tax, timezone and locale formatting.
30. Test provider outage: queued retry + visible exception, no duplicate document or charge.
