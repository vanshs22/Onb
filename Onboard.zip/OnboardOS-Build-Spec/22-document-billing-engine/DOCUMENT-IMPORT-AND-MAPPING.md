# Custom Template Import & Mapping

## Supported import modes
1. Upload DOCX
2. Upload PDF as reference / locked document
3. Paste rich text
4. Import HTML/approved template format
5. Duplicate an existing OnboardOS template
6. Connect an external template provider where supported

## DOCX import
Parse paragraphs, headings, tables, headers/footers and placeholders. Preserve structure where possible. Map detected placeholders into typed OnboardOS variables.

Example detected:
`{{Client Name}}` → `client.legal_name`
`{{Invoice Total}}` → `invoice.total`

Unknown placeholders enter a mapping review queue.

## PDF handling
A PDF can be:
- reference-only
- locked visual template
- converted to a rebuildable template when extraction quality is sufficient

Never silently change a reference PDF.

## Mapping screen
Three columns:
- Imported field
- OnboardOS field
- Preview value

States:
Mapped / Needs mapping / Optional / Unsupported.

## Import validation
Before publishing:
- no unresolved required variables
- no broken signature fields
- no invalid currency/number/date fields
- no unsafe external links
- no inaccessible assets
- page overflow check
- PDF render check
- mobile preview check

## Publish flow
Import → Parse → Map → Preview → Validate → Test data → Internal approval → Publish version.

## Template inheritance
A custom template may inherit:
- tenant brand
- global legal blocks
- invoice numbering
- tax configuration
- footer/contact information

Overrides are explicit; inherited content is visibly labeled.

## Versioning
Imported templates create immutable versions. Documents reference exact versions.

## Rollback
Operators can set a previous approved version as the default for future documents. Existing issued documents remain unchanged.
