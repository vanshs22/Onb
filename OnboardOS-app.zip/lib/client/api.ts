import { getSupabaseBrowserClient } from "@/lib/supabase/client";

const ORG_KEY = "onboardos.organization";
export const activeOrganization = {
  get: () => (typeof window === "undefined" ? null : window.localStorage.getItem(ORG_KEY)),
  set: (id: string) => window.localStorage.setItem(ORG_KEY, id),
};

/** fetch() that attaches the user's Supabase access token and chosen workspace. Falls back to anonymous demo mode when auth is not configured. */
export async function apiFetch(path: string, init: RequestInit = {}) {
  const headers = new Headers(init.headers);
  const supabase = getSupabaseBrowserClient();
  if (supabase) {
    const { data } = await supabase.auth.getSession();
    if (data.session) headers.set("Authorization", `Bearer ${data.session.access_token}`);
  }
  const org = activeOrganization.get();
  if (org && !headers.has("x-organization-id")) headers.set("x-organization-id", org);
  if (init.body && !headers.has("content-type")) headers.set("content-type", "application/json");
  return fetch(path, { ...init, headers });
}

export async function signOut() {
  const supabase = getSupabaseBrowserClient();
  if (supabase) await supabase.auth.signOut();
  window.localStorage.removeItem(ORG_KEY);
  window.location.href = "/login";
}
