import type { OnboardingState } from "./types";

export const ALLOWED_TRANSITIONS: Record<OnboardingState, OnboardingState[]> = {
  DRAFT: ["INVITED", "CANCELLED"],
  INVITED: ["IN_PROGRESS", "CANCELLED"],
  IN_PROGRESS: ["AWAITING_CLIENT", "AWAITING_INTERNAL", "BLOCKED", "READY_FOR_KICKOFF", "PAUSED", "CANCELLED"],
  AWAITING_CLIENT: ["IN_PROGRESS", "BLOCKED", "PAUSED", "CANCELLED"],
  AWAITING_INTERNAL: ["IN_PROGRESS", "BLOCKED", "PAUSED", "CANCELLED"],
  BLOCKED: ["IN_PROGRESS", "AWAITING_CLIENT", "AWAITING_INTERNAL", "PAUSED", "CANCELLED"],
  READY_FOR_KICKOFF: ["IN_KICKOFF", "PAUSED", "CANCELLED"],
  IN_KICKOFF: ["IN_IMPLEMENTATION", "BLOCKED", "PAUSED"],
  IN_IMPLEMENTATION: ["AWAITING_APPROVAL", "BLOCKED", "PAUSED"],
  AWAITING_APPROVAL: ["IN_IMPLEMENTATION", "READY_FOR_ACTIVATION", "BLOCKED", "PAUSED"],
  READY_FOR_ACTIVATION: ["ACTIVATED", "BLOCKED", "PAUSED"],
  ACTIVATED: ["COMPLETED", "PAUSED"],
  COMPLETED: [],
  PAUSED: ["IN_PROGRESS", "CANCELLED"],
  CANCELLED: [],
};

export function canTransition(from: OnboardingState, to: OnboardingState) {
  return ALLOWED_TRANSITIONS[from].includes(to);
}

export function assertTransition(from: OnboardingState, to: OnboardingState) {
  if (!canTransition(from, to)) {
    throw new Error(`STATE_TRANSITION_INVALID:${from}:${to}`);
  }
}

export const EVENT_CATALOG = [
  "onboarding.created",
  "onboarding.launched",
  "onboarding.state_changed",
  "customer.created",
  "requirement.created",
  "requirement.satisfied",
  "requirement.blocked",
  "evidence.created",
  "evidence.verified",
  "contract.sent",
  "contract.signed",
  "payment.requested",
  "payment.succeeded",
  "payment.failed",
  "message.sent",
  "message.received",
  "task.created",
  "task.completed",
  "task.overdue",
  "meeting.scheduled",
  "meeting.completed",
  "approval.requested",
  "approval.approved",
  "approval.rejected",
  "exception.created",
  "exception.resolved",
  "activation.started",
  "activation.verified",
  "activation.completed",
  "handoff.created",
  "handoff.completed",
] as const;

export type EventType = (typeof EVENT_CATALOG)[number];

export interface EventEnvelope<TPayload = Record<string, unknown>> {
  event_id: string;
  event_type: EventType;
  event_version: 1;
  organization_id: string;
  aggregate_type: "onboarding" | "customer" | "requirement" | "payment" | "approval";
  aggregate_id: string;
  sequence: number;
  occurred_at: string;
  correlation_id: string;
  causation_id?: string;
  idempotency_key: string;
  actor: { type: "user" | "agent" | "system" | "customer_contact"; id: string };
  payload: TPayload;
}
