import { randomUUID } from "crypto";
import type { EventEnvelope } from "./domain";

export function createEvent<TPayload>(input: Omit<EventEnvelope<TPayload>, "event_id" | "occurred_at" | "event_version" | "sequence"> & { sequence?: number }): EventEnvelope<TPayload> {
  return {
    ...input,
    event_id: randomUUID(),
    event_version: 1,
    sequence: input.sequence ?? 1,
    occurred_at: new Date().toISOString(),
  } as EventEnvelope<TPayload>;
}
