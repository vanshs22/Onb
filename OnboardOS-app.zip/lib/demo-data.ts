import type { Activity, ExceptionItem, Onboarding } from "./types";

export const onboardings: Onboarding[] = [
  {
    id: "onb_acme_01",
    customer: "Acme Roofing",
    initials: "AR",
    package: "Google Ads + SEO",
    value: "$8,000",
    state: "AWAITING_CLIENT",
    progress: 68,
    health: 62,
    risk: "HIGH",
    blocker: "Google Ads access missing",
    owner: "Maya Chen",
    lastActivity: "19h ago",
    nextAction: "Connect Google Ads",
    requirements: [
      { id: "req_acme_contract", title: "Service agreement", description: "Signed agreement for the selected package", owner: "Customer", stage: "Commercial", status: "SATISFIED", impact: "Commercial gate passed", due: "Complete", clientVisible: true, verified: true },
      { id: "req_acme_payment", title: "Initial payment", description: "Payment received through Stripe", owner: "Customer", stage: "Commercial", status: "SATISFIED", impact: "Commercial gate passed", due: "Complete", clientVisible: true, verified: true },
      { id: "req_acme_assets", title: "Brand assets", description: "Logo, colors, and approved creative references", owner: "Customer", stage: "Intake", status: "SATISFIED", impact: "Creative setup", due: "Complete", clientVisible: true, verified: true },
      { id: "req_acme_ads", title: "Google Ads access", description: "Verified administrator access to the correct Ads account", owner: "Customer", stage: "Access collection", status: "MISSING", impact: "Blocks campaign configuration", due: "Due today", clientVisible: true, verified: false },
      { id: "req_acme_kickoff", title: "Kickoff meeting", description: "Schedule the 45-minute implementation kickoff", owner: "Internal team", stage: "Kickoff", status: "IN_REVIEW", impact: "Depends on access", due: "In 2 days", clientVisible: true, verified: false },
    ],
  },
  {
    id: "onb_nova_02",
    customer: "Nova Dental",
    initials: "ND",
    package: "Paid Search Launch",
    value: "$5,400",
    state: "AWAITING_INTERNAL",
    progress: 82,
    health: 77,
    risk: "MEDIUM",
    blocker: "Landing page QA owner unassigned",
    owner: "Jordan Lee",
    lastActivity: "4h ago",
    nextAction: "Assign QA owner",
    requirements: [
      { id: "req_nova_contract", title: "Service agreement", description: "Signed agreement", owner: "Customer", stage: "Commercial", status: "SATISFIED", impact: "Commercial gate passed", due: "Complete", clientVisible: true, verified: true },
      { id: "req_nova_tracking", title: "Tracking verification", description: "GA4 and conversion events verified", owner: "Internal team", stage: "QA", status: "IN_REVIEW", impact: "Required before activation", due: "Tomorrow", clientVisible: false, verified: false },
      { id: "req_nova_qa", title: "Landing page QA", description: "Final responsive and conversion QA", owner: "Internal team", stage: "QA", status: "BLOCKED", impact: "Delays activation", due: "Tomorrow", clientVisible: false, verified: false },
    ],
  },
  {
    id: "onb_apex_03",
    customer: "Apex Fitness",
    initials: "AF",
    package: "Lead Gen Starter",
    value: "$3,200",
    state: "AWAITING_APPROVAL",
    progress: 91,
    health: 88,
    risk: "LOW",
    owner: "Maya Chen",
    lastActivity: "1h ago",
    nextAction: "Review campaign draft",
    requirements: [
      { id: "req_apex_approval", title: "Campaign approval", description: "Customer approves campaign draft", owner: "Customer", stage: "Approval", status: "IN_REVIEW", impact: "Required before activation", due: "Due in 18h", clientVisible: true, verified: false },
      { id: "req_apex_live", title: "First valid lead", description: "First qualified conversion received", owner: "System", stage: "Activation", status: "MISSING", impact: "Activation proof", due: "After launch", clientVisible: false, verified: false },
    ],
  },
  {
    id: "onb_delta_04",
    customer: "Delta Commerce",
    initials: "DC",
    package: "SEO Growth",
    value: "$6,750",
    state: "READY_FOR_KICKOFF",
    progress: 74,
    health: 93,
    risk: "LOW",
    owner: "Jordan Lee",
    lastActivity: "32m ago",
    nextAction: "Complete kickoff",
    requirements: [
      { id: "req_delta_intake", title: "SEO intake", description: "Goals, audience, and competitive context", owner: "Customer", stage: "Intake", status: "SATISFIED", impact: "Strategy input", due: "Complete", clientVisible: true, verified: true },
      { id: "req_delta_kickoff", title: "Kickoff meeting", description: "Meeting booked and participants confirmed", owner: "Internal team", stage: "Kickoff", status: "SATISFIED", impact: "Ready to start delivery", due: "Booked", clientVisible: true, verified: true },
    ],
  },
  {
    id: "onb_helios_05",
    customer: "Helios Legal",
    initials: "HL",
    package: "Content + CRO",
    value: "$4,800",
    state: "BLOCKED",
    progress: 44,
    health: 39,
    risk: "CRITICAL",
    blocker: "Payment failed after signature",
    owner: "Maya Chen",
    lastActivity: "2d ago",
    nextAction: "Resolve payment failure",
    requirements: [
      { id: "req_helios_signature", title: "Service agreement", description: "Signed agreement", owner: "Customer", stage: "Commercial", status: "SATISFIED", impact: "Agreement executed", due: "Complete", clientVisible: true, verified: true },
      { id: "req_helios_payment", title: "Initial payment", description: "Payment request needs resolution", owner: "Customer", stage: "Commercial", status: "BLOCKED", impact: "Blocks all delivery work", due: "2 days overdue", clientVisible: true, verified: false },
    ],
  },
];

export const exceptions: ExceptionItem[] = [
  { id: "exc_01", severity: "CRITICAL", customer: "Helios Legal", onboardingId: "onb_helios_05", title: "Payment failed after signature", impact: "$4,800 onboarding cannot start; activation promise at risk", detected: "2 days ago", aiAttempt: "Payment retry attempted once. Stripe returned card_declined.", recommendation: "Ask the account manager to contact the customer and send a secure payment link.", owner: "Maya Chen", sla: "Breach in 6h", status: "OPEN" },
  { id: "exc_02", severity: "HIGH", customer: "Acme Roofing", onboardingId: "onb_acme_01", title: "Google Ads access missing", impact: "Campaign configuration and kickoff readiness are blocked", detected: "19h ago", aiAttempt: "Contextual email sent. Customer opened it but has not connected access.", recommendation: "Send an eligible WhatsApp reminder, then escalate in 5 hours.", owner: "Maya Chen", sla: "Breach in 5h", status: "OPEN" },
  { id: "exc_03", severity: "MEDIUM", customer: "Nova Dental", onboardingId: "onb_nova_02", title: "Landing page QA owner unassigned", impact: "Activation may slip even though customer work is complete", detected: "4h ago", aiAttempt: "Suggested Jordan Lee as owner based on workload and service specialty.", recommendation: "Approve assignment to Jordan Lee.", owner: "Jordan Lee", sla: "Due tomorrow", status: "OPEN" },
  { id: "exc_04", severity: "LOW", customer: "Apex Fitness", onboardingId: "onb_apex_03", title: "Campaign approval waiting", impact: "Activation is one approval away", detected: "18h ago", aiAttempt: "Reminder drafted; quiet hours policy prevents sending until 9:00 AM.", recommendation: "Review the reminder or wait for the next eligible window.", owner: "Maya Chen", sla: "Due in 18h", status: "OPEN" },
];

export const activity: Activity[] = [
  { id: "act_01", actor: "Verification Agent", actorType: "AGENT", text: "verified Delta Commerce kickoff booking", time: "32m ago", tone: "positive" },
  { id: "act_02", actor: "Maya Chen", actorType: "USER", text: "approved a reminder for Acme Roofing", time: "1h ago", tone: "neutral" },
  { id: "act_03", actor: "Stripe", actorType: "INTEGRATION", text: "reported a failed payment for Helios Legal", time: "2h ago", tone: "critical" },
  { id: "act_04", actor: "Intake Agent", actorType: "AGENT", text: "extracted 12 fields from Nova Dental intake", time: "4h ago", tone: "positive" },
  { id: "act_05", actor: "Chase Agent", actorType: "AGENT", text: "scheduled an Acme Roofing follow-up for 5h", time: "5h ago", tone: "warning" },
];

export const integrations = [
  { name: "OnboardOS Native", description: "Built-in portal, workflows, requirements, verification, health, and activation", category: "Native", status: "Enabled", lastSync: "Core runtime", color: "#d7ff57" },
  { name: "HubSpot", description: "Deal won triggers and customer sync", category: "CRM", status: "Connected", lastSync: "2m ago", color: "#ff7a59" },
  { name: "Stripe", description: "Checkout, billing, and payment webhooks", category: "Payments", status: "Connected", lastSync: "5m ago", color: "#635bff" },
  { name: "Google Workspace", description: "Gmail, Drive, and Calendar", category: "Productivity", status: "Connected", lastSync: "12m ago", color: "#4285f4" },
  { name: "Calendly", description: "Routing and kickoff scheduling", category: "Scheduling", status: "Needs attention", lastSync: "Auth expires in 4 days", color: "#006bff" },
  { name: "Slack", description: "Exception and SLA notifications", category: "Team", status: "Connected", lastSync: "18m ago", color: "#36c5f0" },
  { name: "PandaDoc", description: "Agreements and e-signature status", category: "Documents", status: "Not connected", lastSync: "—", color: "#ffb000" },
  { name: "Dubsado", description: "Optional portal, forms, contracts, and workflow bridge", category: "External platform", status: "Available via bridge", lastSync: "Zapier/webhook setup", color: "#e76857" },
  { name: "Bonsai", description: "Optional CRM, projects, invoices, and portal sync", category: "External platform", status: "Available via API", lastSync: "API credential required", color: "#5a4bdb" },
  { name: "Jotform", description: "Optional forms, submissions, files, and payments", category: "External platform", status: "Available via API", lastSync: "Webhook setup", color: "#ff5a36" },
  { name: "Rocketlane", description: "Optional PSA projects, tasks, dependencies, and health", category: "External platform", status: "Available via API", lastSync: "API credential required", color: "#1e9c94" },
  { name: "OnRamp", description: "Optional adaptive playbooks and engagement signals", category: "External platform", status: "Available via API", lastSync: "Bearer token required", color: "#eb6b55" },
  { name: "GUIDEcx", description: "Optional projects, analytics, APIs, and MCP access", category: "External platform", status: "Available via API/MCP", lastSync: "Workspace token required", color: "#2d6cdf" },
];

export const agents = [
  ["Orchestrator", "AUTONOMOUS", "Coordinates objective and handoffs"],
  ["Requirements", "ASSISTED_EXECUTION", "Determines required inputs and dependencies"],
  ["Verification", "AUTONOMOUS", "Checks evidence against policies"],
  ["Chase", "AUTONOMOUS", "Sends governed contextual follow-ups"],
  ["Risk", "OBSERVE", "Explains health and deadline exposure"],
  ["Activation & Handoff", "APPROVAL GATE", "Proves first value and packages handoff"],
];

export const templates = [
  { name: "Paid Ads Launch", vertical: "Performance agency", version: "v3", onboardings: 18, activation: "Google Ads live + first valid event", status: "Published" },
  { name: "SEO Growth", vertical: "Marketing agency", version: "v2", onboardings: 12, activation: "Strategy approved + first report", status: "Published" },
  { name: "Lead Gen Starter", vertical: "Performance agency", version: "v1", onboardings: 7, activation: "Campaign approved + first lead", status: "Draft" },
];
