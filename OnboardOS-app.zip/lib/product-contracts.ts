import type { EventType } from "@/lib/domain";
import type { EvidenceType } from "@/lib/types";

export type AutonomyLevel = "OBSERVE" | "DRAFT" | "ASSISTED_EXECUTION" | "AUTONOMOUS" | "AUTONOMOUS_WITH_APPROVAL_GATE";
export type WorkflowNodeType = "trigger" | "condition" | "wait" | "task.create" | "message.send" | "form.send" | "document.request" | "payment.request" | "agreement.request" | "meeting.schedule" | "integration.connect" | "approval.request" | "requirement.check" | "evidence.collect" | "evidence.verify" | "exception.create" | "escalation.create" | "state.transition" | "end";
export type Channel = "EMAIL" | "SMS" | "WHATSAPP" | "IN_APP" | "SLACK" | "TEAMS";

export interface PromiseNode { id: string; statement: string; outcome: string; dependencies: string[]; activationEvidence: EvidenceType[]; }
export interface ScopeItem { id: string; description: string; source: "PROPOSAL" | "CONTRACT" | "SOW" | "SALES_NOTE" | "CUSTOMER_REQUEST"; included: boolean; confidence: number; }
export interface WorkflowNode { id: string; type: WorkflowNodeType; version: number; inputSchema: Record<string, unknown>; outputSchema: Record<string, unknown>; next: string[]; timeoutSeconds?: number; retryPolicy: { maxAttempts: number; backoff: "linear" | "exponential" }; approvalRequired: boolean; }
export interface ToolDefinition { toolId: string; version: number; description: string; inputSchema: Record<string, unknown>; outputSchema: Record<string, unknown>; requiredPermissions: string[]; autonomyCeiling: AutonomyLevel; idempotency: "required" | "optional" | "none"; verification: string; retryable: boolean; audit: "always" | "on_failure" | "never"; }
export interface AgentDefinition { id: string; name: string; purpose: string; autonomy: AutonomyLevel; tools: string[]; independentVerifier?: string; }
export interface ConnectorDefinition { provider: string; category: "CRM" | "PAYMENTS" | "E_SIGN" | "CALENDAR" | "MESSAGING" | "STORAGE" | "AI"; capabilities: string[]; auth: "OAUTH_PKCE" | "API_KEY" | "WEBHOOK"; healthCheck: string; }
export interface ChannelPolicy { channel: Channel; allowed: boolean; consentRequired: boolean; fallbackOrder: number; quietHours: { start: string; end: string; timezone: string }; }
export interface SlaPolicy { id: string; name: string; targetHours: number; escalationHours: number[]; appliesTo: string; }
export interface ActivationDefinition { id: string; name: string; criteria: { id: string; description: string; evidenceType: EvidenceType; required: boolean }[]; }

export const AGENT_ROSTER: AgentDefinition[] = [
  { id: "orchestrator", name: "Orchestrator Agent", purpose: "Own the onboarding objective and delegate work.", autonomy: "AUTONOMOUS", tools: ["requirement.check", "workflow.run", "agent.handoff"] },
  { id: "deal-to-delivery", name: "Deal-to-Delivery Agent", purpose: "Compile authorized sales context into delivery scope.", autonomy: "ASSISTED_EXECUTION", tools: ["scope.extract", "promise.create", "requirement.create"], independentVerifier: "scope.review" },
  { id: "requirements", name: "Requirements Agent", purpose: "Determine required information, assets, access, and actions.", autonomy: "AUTONOMOUS", tools: ["requirement.create", "dependency.create"] },
  { id: "commercial", name: "Commercial Agent", purpose: "Coordinate agreement, payment, and commercial gates.", autonomy: "AUTONOMOUS_WITH_APPROVAL_GATE", tools: ["agreement.send", "payment.request"], independentVerifier: "provider.status" },
  { id: "intake", name: "Intake Agent", purpose: "Collect and structure customer information.", autonomy: "ASSISTED_EXECUTION", tools: ["form.send", "form.extract"] },
  { id: "evidence-document", name: "Evidence & Document Agent", purpose: "Collect, classify, and map evidence.", autonomy: "ASSISTED_EXECUTION", tools: ["document.request", "document.analyze"] },
  { id: "verification", name: "Verification Agent", purpose: "Verify evidence independently against policy.", autonomy: "AUTONOMOUS", tools: ["evidence.verify"], independentVerifier: "provider.verify" },
  { id: "communication", name: "Stakeholder & Communication Agent", purpose: "Select stakeholder, channel, and context.", autonomy: "ASSISTED_EXECUTION", tools: ["message.draft", "consent.check"] },
  { id: "chase", name: "Chase Agent", purpose: "Follow up on stalled customer actions.", autonomy: "AUTONOMOUS", tools: ["message.send", "escalation.create"] },
  { id: "scheduling", name: "Scheduling Agent", purpose: "Book and verify required meetings.", autonomy: "AUTONOMOUS_WITH_APPROVAL_GATE", tools: ["meeting.schedule", "meeting.verify"] },
  { id: "implementation", name: "Implementation Agent", purpose: "Coordinate delivery prerequisites and execution.", autonomy: "ASSISTED_EXECUTION", tools: ["task.create", "dependency.check"] },
  { id: "scope", name: "Scope Agent", purpose: "Detect promises, entitlements, and scope changes.", autonomy: "DRAFT", tools: ["scope.compare", "change-order.draft"], independentVerifier: "scope.review" },
  { id: "risk", name: "Risk Agent", purpose: "Calculate explainable health and predict blockers.", autonomy: "OBSERVE", tools: ["health.calculate", "risk.signal"] },
  { id: "recovery", name: "Exception & Recovery Agent", purpose: "Retry, reconcile, and escalate failures.", autonomy: "AUTONOMOUS_WITH_APPROVAL_GATE", tools: ["action.retry", "action.reconcile", "exception.create"] },
  { id: "approval", name: "Approval Agent", purpose: "Manage customer and internal approval gates.", autonomy: "ASSISTED_EXECUTION", tools: ["approval.request", "approval.decide"] },
  { id: "activation", name: "Activation & Handoff Agent", purpose: "Prove first value and package handoff.", autonomy: "AUTONOMOUS_WITH_APPROVAL_GATE", tools: ["activation.verify", "handoff.create"], independentVerifier: "activation.evidence" },
  { id: "portfolio", name: "Portfolio & Learning Agent", purpose: "Find cross-customer patterns and workflow improvements.", autonomy: "OBSERVE", tools: ["analytics.query", "workflow.recommend"] },
];

export const TOOL_REGISTRY: ToolDefinition[] = [
  { toolId: "message.send", version: 1, description: "Send a governed customer message.", inputSchema: { channel: "string", body: "string", contactId: "uuid" }, outputSchema: { providerMessageId: "string", status: "string" }, requiredPermissions: ["communications.send"], autonomyCeiling: "AUTONOMOUS", idempotency: "required", verification: "message.status", retryable: true, audit: "always" },
  { toolId: "payment.request", version: 1, description: "Create a payment request through a connected provider.", inputSchema: { amountCents: "number", currency: "string" }, outputSchema: { providerRequestId: "string", status: "string" }, requiredPermissions: ["commercial.payment_request"], autonomyCeiling: "AUTONOMOUS_WITH_APPROVAL_GATE", idempotency: "required", verification: "payment.status", retryable: true, audit: "always" },
  { toolId: "evidence.verify", version: 1, description: "Verify evidence using an independent policy verifier.", inputSchema: { requirementId: "uuid", evidenceId: "uuid" }, outputSchema: { status: "PASSED|FAILED", reason: "string" }, requiredPermissions: ["evidence.verify"], autonomyCeiling: "AUTONOMOUS", idempotency: "required", verification: "verifier.result", retryable: true, audit: "always" },
  { toolId: "meeting.schedule", version: 1, description: "Create and verify a required meeting booking.", inputSchema: { contactId: "uuid", durationMinutes: "number" }, outputSchema: { appointmentId: "uuid", providerBookingId: "string" }, requiredPermissions: ["calendar.write"], autonomyCeiling: "AUTONOMOUS_WITH_APPROVAL_GATE", idempotency: "required", verification: "calendar.booking", retryable: true, audit: "always" },
  { toolId: "activation.verify", version: 1, description: "Evaluate activation criteria against verified evidence.", inputSchema: { onboardingId: "uuid" }, outputSchema: { activated: "boolean", missingCriteria: "string[]" }, requiredPermissions: ["activation.verify"], autonomyCeiling: "AUTONOMOUS_WITH_APPROVAL_GATE", idempotency: "required", verification: "activation.evidence", retryable: false, audit: "always" },
];

export const CONNECTOR_REGISTRY: ConnectorDefinition[] = [
  { provider: "HubSpot", category: "CRM", capabilities: ["deal.won", "customer.upsert", "owner.resolve"], auth: "OAUTH_PKCE", healthCheck: "crm.account" },
  { provider: "Stripe", category: "PAYMENTS", capabilities: ["payment.request", "payment.status", "payment.succeeded.webhook"], auth: "API_KEY", healthCheck: "stripe.account" },
  { provider: "PandaDoc", category: "E_SIGN", capabilities: ["agreement.send", "agreement.status"], auth: "OAUTH_PKCE", healthCheck: "esign.account" },
  { provider: "Calendly", category: "CALENDAR", capabilities: ["meeting.schedule", "meeting.booking"], auth: "OAUTH_PKCE", healthCheck: "calendar.account" },
  { provider: "Google Workspace", category: "MESSAGING", capabilities: ["message.send", "message.receive", "calendar.read", "storage.write"], auth: "OAUTH_PKCE", healthCheck: "google.account" },
  { provider: "Slack", category: "MESSAGING", capabilities: ["internal.notify", "exception.notify"], auth: "OAUTH_PKCE", healthCheck: "slack.workspace" },
];

export const CHANNEL_POLICIES: ChannelPolicy[] = [
  { channel: "EMAIL", allowed: true, consentRequired: false, fallbackOrder: 1, quietHours: { start: "21:00", end: "08:00", timezone: "organization" } },
  { channel: "SMS", allowed: true, consentRequired: true, fallbackOrder: 2, quietHours: { start: "21:00", end: "08:00", timezone: "organization" } },
  { channel: "WHATSAPP", allowed: true, consentRequired: true, fallbackOrder: 3, quietHours: { start: "21:00", end: "08:00", timezone: "organization" } },
  { channel: "IN_APP", allowed: true, consentRequired: false, fallbackOrder: 0, quietHours: { start: "00:00", end: "00:00", timezone: "organization" } },
  { channel: "SLACK", allowed: true, consentRequired: false, fallbackOrder: 1, quietHours: { start: "21:00", end: "08:00", timezone: "organization" } },
  { channel: "TEAMS", allowed: false, consentRequired: false, fallbackOrder: 5, quietHours: { start: "21:00", end: "08:00", timezone: "organization" } },
];

export const SLA_POLICIES: SlaPolicy[] = [
  { id: "customer-setup", name: "Customer setup", targetHours: 72, escalationHours: [24, 48, 72, 96], appliesTo: "customer.requirement" },
  { id: "kickoff", name: "Signed to kickoff", targetHours: 168, escalationHours: [96, 144, 168], appliesTo: "onboarding.kickoff" },
  { id: "internal-blocker", name: "Internal blocker response", targetHours: 4, escalationHours: [2, 4], appliesTo: "internal.blocker" },
  { id: "approval", name: "Customer approval", targetHours: 48, escalationHours: [24, 48], appliesTo: "approval.request" },
];

export const PAID_ADS_ACTIVATION: ActivationDefinition = {
  id: "paid-ads-first-value-v1",
  name: "Paid Ads first value",
  criteria: [
    { id: "google-ads-connected", description: "Correct Google Ads account is connected and permissions verified.", evidenceType: "OAUTH", required: true },
    { id: "tracking-verified", description: "Tracking and conversion events are verified.", evidenceType: "API_RECORD", required: true },
    { id: "campaign-approved", description: "Customer approved the campaign configuration.", evidenceType: "APPROVAL", required: true },
    { id: "campaign-live", description: "Campaign is live in the provider account.", evidenceType: "API_RECORD", required: true },
    { id: "first-valid-event", description: "First valid conversion event is recorded.", evidenceType: "WEBHOOK", required: true },
  ],
};

export const CANONICAL_EVENT_RULES: Record<string, EventType | string> = {
  launch: "onboarding.launched",
  activation: "activation.completed",
  payment: "payment.succeeded",
  webhook: "webhook.received",
};
