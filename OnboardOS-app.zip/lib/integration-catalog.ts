export type IntegrationMode = "NATIVE" | "REST_API" | "OAUTH" | "WEBHOOK_BRIDGE" | "MCP" | "AUTOMATION_BRIDGE";
export type IntegrationCategory = "CRM" | "FORM" | "PORTAL" | "WORKFLOW" | "PSA" | "PAYMENTS" | "E_SIGN" | "CALENDAR" | "MESSAGING" | "STORAGE";

export interface ProviderDefinition {
  id: string;
  name: string;
  category: IntegrationCategory;
  modes: IntegrationMode[];
  capabilities: string[];
  sourceOfTruth: "ONBOARDOS" | "EXTERNAL" | "CONFIGURABLE";
  events: string[];
  setup: "AVAILABLE" | "CREDENTIALS_REQUIRED" | "PARTNER_OR_BRIDGE_REQUIRED";
  notes: string;
}

export const PROVIDER_CATALOG: ProviderDefinition[] = [
  { id: "onboardos", name: "OnboardOS native", category: "WORKFLOW", modes: ["NATIVE"], capabilities: ["customer_workspace", "forms", "workflow", "projects", "requirements", "evidence", "verification", "approvals", "documents", "communication", "health", "analytics", "commercial_ux", "scheduling", "concierge", "activation", "crm_compiler", "mcp"], sourceOfTruth: "ONBOARDOS", events: ["onboarding.state_changed", "requirement.satisfied", "evidence.verified", "activation.completed"], setup: "AVAILABLE", notes: "Default execution path and operational source of truth." },
  { id: "dubsado", name: "Dubsado", category: "PORTAL", modes: ["AUTOMATION_BRIDGE", "WEBHOOK_BRIDGE"], capabilities: ["forms", "contracts", "payments", "scheduling", "client_portal", "workflow_trigger"], sourceOfTruth: "CONFIGURABLE", events: ["form.submitted", "contract.signed", "payment.succeeded", "appointment.booked"], setup: "PARTNER_OR_BRIDGE_REQUIRED", notes: "Use authorized Zapier/webhook bridge where direct API access is unavailable; never scrape." },
  { id: "bonsai", name: "Bonsai", category: "PORTAL", modes: ["REST_API", "AUTOMATION_BRIDGE"], capabilities: ["crm", "projects", "contracts", "invoices", "payments", "files", "client_portal"], sourceOfTruth: "CONFIGURABLE", events: ["client.created", "contract.signed", "invoice.paid", "task.updated"], setup: "CREDENTIALS_REQUIRED", notes: "Use customer-authorized API key/OAuth or automation bridge." },
  { id: "jotform", name: "Jotform", category: "FORM", modes: ["REST_API", "WEBHOOK_BRIDGE"], capabilities: ["forms", "submissions", "files", "payments", "signatures", "ai_agent"], sourceOfTruth: "CONFIGURABLE", events: ["form.submitted", "file.uploaded", "payment.succeeded"], setup: "CREDENTIALS_REQUIRED", notes: "Map Jotform questions to OnboardOS requirements and normalize webhook submissions." },
  { id: "rocketlane", name: "Rocketlane", category: "PSA", modes: ["REST_API", "WEBHOOK_BRIDGE"], capabilities: ["projects", "tasks", "dependencies", "health", "portal", "delivery"], sourceOfTruth: "CONFIGURABLE", events: ["project.created", "task.updated", "project.health_changed"], setup: "CREDENTIALS_REQUIRED", notes: "Import delivery data or delegate project execution while OnboardOS owns activation proof." },
  { id: "onramp", name: "OnRamp", category: "WORKFLOW", modes: ["REST_API", "WEBHOOK_BRIDGE"], capabilities: ["playbooks", "tasks", "adaptive_workflows", "health", "customer_engagement"], sourceOfTruth: "CONFIGURABLE", events: ["project.created", "task.completed", "risk.detected"], setup: "CREDENTIALS_REQUIRED", notes: "Sync playbooks and risk signals; keep OnboardOS promise/scope/activation graph authoritative." },
  { id: "guidecx", name: "GUIDEcx", category: "PSA", modes: ["REST_API", "WEBHOOK_BRIDGE", "MCP"], capabilities: ["projects", "tasks", "dependencies", "health", "analytics", "portal", "ai_access"], sourceOfTruth: "CONFIGURABLE", events: ["project.created", "task.updated", "health.changed"], setup: "CREDENTIALS_REQUIRED", notes: "Use Open API/MCP for authorized read/action access; normalize health and project events." },
  { id: "hubspot", name: "HubSpot", category: "CRM", modes: ["OAUTH", "WEBHOOK_BRIDGE"], capabilities: ["deal.won", "customer.upsert", "owner.resolve"], sourceOfTruth: "EXTERNAL", events: ["deal.won", "contact.updated", "company.updated"], setup: "CREDENTIALS_REQUIRED", notes: "Sales source; OnboardOS owns operational onboarding state." },
  { id: "stripe", name: "Stripe", category: "PAYMENTS", modes: ["REST_API", "WEBHOOK_BRIDGE"], capabilities: ["payment.request", "payment.status", "payment.succeeded"], sourceOfTruth: "EXTERNAL", events: ["payment.succeeded", "payment.failed", "payment.refunded"], setup: "CREDENTIALS_REQUIRED", notes: "Hosted checkout and verified webhooks; never store card data." },
  { id: "docusign", name: "DocuSign", category: "E_SIGN", modes: ["OAUTH", "WEBHOOK_BRIDGE"], capabilities: ["agreement.send", "agreement.status", "signature"], sourceOfTruth: "EXTERNAL", events: ["contract.sent", "contract.signed", "contract.declined"], setup: "CREDENTIALS_REQUIRED", notes: "Hosted signature flow and provider event verification." },
  { id: "calendly", name: "Calendly", category: "CALENDAR", modes: ["OAUTH", "WEBHOOK_BRIDGE"], capabilities: ["meeting.schedule", "meeting.booking"], sourceOfTruth: "EXTERNAL", events: ["meeting.scheduled", "meeting.cancelled"], setup: "CREDENTIALS_REQUIRED", notes: "Route and verify meetings through provider webhooks." },
  { id: "google-workspace", name: "Google Workspace", category: "MESSAGING", modes: ["OAUTH", "WEBHOOK_BRIDGE"], capabilities: ["gmail.send", "gmail.read", "drive.write", "calendar.read"], sourceOfTruth: "EXTERNAL", events: ["message.received", "meeting.scheduled"], setup: "CREDENTIALS_REQUIRED", notes: "Customer-authorized Gmail/Drive/Calendar scopes only." },
];

export const CAPABILITY_DEFAULTS: Record<string, { native: string; external: string[] }> = {
  forms: { native: "onboardos", external: ["jotform", "dubsado", "bonsai"] },
  contracts: { native: "onboardos", external: ["docusign", "dubsado", "bonsai"] },
  payments: { native: "onboardos", external: ["stripe", "dubsado", "bonsai"] },
  projects: { native: "onboardos", external: ["rocketlane", "onramp", "guidecx", "bonsai"] },
  health: { native: "onboardos", external: ["rocketlane", "onramp", "guidecx"] },
  scheduling: { native: "onboardos", external: ["calendly", "dubsado"] },
  crm: { native: "onboardos", external: ["hubspot", "bonsai"] },
  ai_access: { native: "onboardos", external: ["guidecx"] },
};
