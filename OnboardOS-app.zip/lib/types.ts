export const ONBOARDING_STATES = [
  "DRAFT",
  "INVITED",
  "IN_PROGRESS",
  "AWAITING_CLIENT",
  "AWAITING_INTERNAL",
  "BLOCKED",
  "READY_FOR_KICKOFF",
  "IN_KICKOFF",
  "IN_IMPLEMENTATION",
  "AWAITING_APPROVAL",
  "READY_FOR_ACTIVATION",
  "ACTIVATED",
  "COMPLETED",
  "PAUSED",
  "CANCELLED",
] as const;

export type OnboardingState = (typeof ONBOARDING_STATES)[number];
export type RiskBand = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
export type RequirementStatus = "SATISFIED" | "MISSING" | "IN_REVIEW" | "BLOCKED";
export type EvidenceType = "FILE" | "SIGNATURE" | "PAYMENT" | "OAUTH" | "FORM" | "APPROVAL" | "WEBHOOK" | "API_RECORD" | "MESSAGE";
export type ActorType = "USER" | "SYSTEM" | "AGENT" | "INTEGRATION" | "CUSTOMER_CONTACT";

export interface Requirement {
  id: string;
  title: string;
  description: string;
  owner: "Customer" | "Internal team" | "System";
  stage: string;
  status: RequirementStatus;
  impact: string;
  due: string;
  clientVisible: boolean;
  verified: boolean;
}

export interface Onboarding {
  id: string;
  customer: string;
  initials: string;
  package: string;
  value: string;
  state: OnboardingState;
  progress: number;
  health: number;
  risk: RiskBand;
  blocker?: string;
  owner: string;
  lastActivity: string;
  nextAction: string;
  requirements: Requirement[];
}

export interface ExceptionItem {
  id: string;
  severity: RiskBand;
  customer: string;
  onboardingId: string;
  title: string;
  impact: string;
  detected: string;
  aiAttempt: string;
  recommendation: string;
  owner: string;
  sla: string;
  status: "OPEN" | "SNOOZED" | "RESOLVED";
}

export interface Activity {
  id: string;
  actor: string;
  actorType: ActorType;
  text: string;
  time: string;
  tone: "positive" | "warning" | "neutral" | "critical";
}
