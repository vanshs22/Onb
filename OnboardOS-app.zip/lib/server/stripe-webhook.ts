import { createHash } from "node:crypto";
import type { Queryable } from "@/lib/server/sql";

export interface StripeEventLike { id: string; type: string; data: { object: Record<string, unknown> } }
export type StripeOutcome = { status: "APPLIED" | "DUPLICATE" | "IGNORED" | "REJECTED"; reason?: string };
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Idempotent at two levels: the delivery (provider, event id) and the payment (provider, payment id).
 * A delivery that failed transiently is reprocessed on Stripe's retry; a processed one is acknowledged untouched.
 */
export async function applyStripeEvent(db: Queryable, event: StripeEventLike): Promise<StripeOutcome> {
  const object = event.data.object;
  const metadata = (object.metadata ?? {}) as Record<string, string>;
  const organizationId = UUID.test(metadata.organizationId ?? "") ? metadata.organizationId : null;
  await db.query("insert into webhook_deliveries (organization_id, provider, provider_event_id, signature_valid, payload_hash) values ($1,'stripe',$2,true,$3) on conflict (provider, provider_event_id) do nothing", [organizationId, event.id, createHash("sha256").update(JSON.stringify(event)).digest("hex")]);
  const delivery = (await db.query("select id, status from webhook_deliveries where provider='stripe' and provider_event_id=$1", [event.id])).rows[0];
  if (delivery.status === "PROCESSED") return { status: "DUPLICATE" };
  const finish = async (outcome: StripeOutcome): Promise<StripeOutcome> => {
    await db.query("update webhook_deliveries set status='PROCESSED', error=$2, processed_at=now() where id=$1", [delivery.id, outcome.reason ?? null]);
    return outcome;
  };

  if (event.type !== "checkout.session.completed" || object.payment_status !== "paid") return finish({ status: "IGNORED", reason: `Unhandled event ${event.type}` });
  const amount = Number(object.amount_total);
  const invoiceId = metadata.invoiceId;
  if (!organizationId || !UUID.test(invoiceId ?? "") || !Number.isInteger(amount) || amount <= 0) return finish({ status: "REJECTED", reason: "MISSING_OR_INVALID_METADATA" });
  try {
    await db.query("insert into payments (organization_id, invoice_id, amount_cents, provider, provider_payment_id) values ($1,$2,$3,'stripe',$4)", [organizationId, invoiceId, amount, String(object.payment_intent ?? object.id)]);
    return finish({ status: "APPLIED" });
  } catch (error) {
    const code = (error as { code?: string }).code;
    if (code === "23505") return finish({ status: "DUPLICATE", reason: "Payment already recorded" });
    if (code === "23514" || code === "23503") return finish({ status: "REJECTED", reason: (error as Error).message });
    throw error; // transient: leave the delivery unprocessed so Stripe's retry applies it
  }
}
