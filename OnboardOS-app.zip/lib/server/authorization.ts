export type WorkspaceRole = "OWNER" | "ADMIN" | "OPERATOR" | "MEMBER" | "VIEWER" | "CUSTOMER_CONTACT";
export type Permission = "workspace.read" | "workspace.manage" | "onboarding.read" | "onboarding.write" | "requirement.write" | "evidence.verify" | "workflow.execute" | "integration.manage" | "audit.read";

const rolePermissions: Record<WorkspaceRole, Permission[]> = {
  OWNER: ["workspace.read", "workspace.manage", "onboarding.read", "onboarding.write", "requirement.write", "evidence.verify", "workflow.execute", "integration.manage", "audit.read"],
  ADMIN: ["workspace.read", "workspace.manage", "onboarding.read", "onboarding.write", "requirement.write", "evidence.verify", "workflow.execute", "integration.manage", "audit.read"],
  OPERATOR: ["workspace.read", "onboarding.read", "onboarding.write", "requirement.write", "evidence.verify", "workflow.execute", "audit.read"],
  MEMBER: ["workspace.read", "onboarding.read", "requirement.write", "audit.read"],
  VIEWER: ["workspace.read", "onboarding.read"],
  CUSTOMER_CONTACT: ["onboarding.read", "requirement.write"],
};

export interface ActorContext {
  actorId: string;
  organizationId: string;
  role: WorkspaceRole;
}

export function permissionsFor(role: WorkspaceRole) {
  return rolePermissions[role];
}

export function can(actor: ActorContext, permission: Permission) {
  return rolePermissions[actor.role].includes(permission);
}

export function requirePermission(actor: ActorContext, permission: Permission) {
  if (!can(actor, permission)) {
    const error = new Error(`FORBIDDEN:${permission}`);
    error.name = "FORBIDDEN";
    throw error;
  }
}

// Production authentication resolves this from the verified server session/JWT.
// It intentionally never accepts organization_id from a mutation body.
export function demoOperatorContext(): ActorContext {
  return { actorId: "demo-user", organizationId: "demo-organization", role: "ADMIN" };
}
