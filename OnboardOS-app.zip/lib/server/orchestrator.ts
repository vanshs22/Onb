import { randomUUID } from "node:crypto";
import { createEvent } from "@/lib/api";
import { onboardings } from "@/lib/demo-data";
import { AGENT_ROSTER, CONNECTOR_REGISTRY, TOOL_REGISTRY } from "@/lib/product-contracts";
import { activationReadiness, calculateHealth, promiseGraph } from "@/lib/server/operations";
import { registerOutbox } from "@/lib/server/outbox";

const lifecycle = ["deal.won", "onboarding.created", "onboarding.launched", "agreement.signed", "payment.succeeded", "intake.completed", "evidence.verified", "access.verified", "kickoff.completed", "implementation.completed", "approval.approved", "activation.completed"] as const;
const stateToLifecycleIndex: Record<string, number> = { DRAFT: 1, INVITED: 2, IN_PROGRESS: 5, AWAITING_CLIENT: 6, AWAITING_INTERNAL: 6, BLOCKED: 6, READY_FOR_KICKOFF: 8, IN_KICKOFF: 9, IN_IMPLEMENTATION: 9, AWAITING_APPROVAL: 10, READY_FOR_ACTIVATION: 11, ACTIVATED: 11, COMPLETED: 12, PAUSED: 5, CANCELLED: 12 };

export function onboardingTwin(onboardingId: string) {
  const onboarding = onboardings.find((item) => item.id === onboardingId);
  if (!onboarding) return null;
  const health = calculateHealth(onboardingId);
  const activation = activationReadiness(onboardingId);
  const openRequirements = onboarding.requirements.filter((item) => item.status !== "SATISFIED");
  return {
    onboarding: { id: onboarding.id, customer: onboarding.customer, package: onboarding.package, value: onboarding.value, state: onboarding.state, progress: onboarding.progress },
    promiseGraph: promiseGraph(onboardingId),
    requirements: { total: onboarding.requirements.length, satisfied: onboarding.requirements.filter((item) => item.status === "SATISFIED").length, open: openRequirements.map((item) => ({ id: item.id, title: item.title, owner: item.owner, impact: item.impact, status: item.status })) },
    evidence: { verified: onboarding.requirements.filter((item) => item.verified).map((item) => item.title), pending: openRequirements.map((item) => item.title) },
    health,
    activation,
    blockers: openRequirements.filter((item) => item.status === "BLOCKED" || item.impact.toLowerCase().includes("block")).map((item) => ({ requirement: item.title, impact: item.impact })),
    nextAction: openRequirements[0] ? { title: openRequirements[0].title, owner: openRequirements[0].owner, reason: openRequirements[0].impact } : { title: "Verify activation", owner: "System", reason: "All requirements are satisfied" },
  };
}

export function orchestrate(onboardingId: string, actorId = "orchestrator") {
  const twin = onboardingTwin(onboardingId);
  if (!twin) return null;
  const next = twin.nextAction;
  const eligibleAgent = AGENT_ROSTER.find((agent) => agent.name.toLowerCase().includes(next.owner.toLowerCase())) ?? AGENT_ROSTER.find((agent) => agent.id === "orchestrator");
  const tool = TOOL_REGISTRY.find((candidate) => candidate.toolId.includes("requirement") || candidate.toolId.includes("message"));
  const event = createEvent({ event_type: "onboarding.state_changed", organization_id: "demo-organization", aggregate_type: "onboarding", aggregate_id: onboardingId, correlation_id: randomUUID(), idempotency_key: `orchestrate.${onboardingId}.${Date.now()}`, actor: { type: "agent", id: actorId }, payload: { objective: "Move customer toward verified activation", nextAction: next, agent: eligibleAgent?.id, tool: tool?.toolId } });
  return {
    objective: "Move customer from signed deal to verified activation",
    context: twin,
    plan: { lifecycle, currentState: twin.onboarding.state, remaining: lifecycle.slice(stateToLifecycleIndex[twin.onboarding.state] ?? 0), dependencies: twin.blockers },
    capabilityRouting: { agent: eligibleAgent, tool, connectors: CONNECTOR_REGISTRY.map((connector) => connector.provider) },
    execution: { status: "PLANNED", sideEffect: "none", approvalRequired: true },
    verification: { required: true, independent: true, activationReady: twin.activation?.ready ?? false },
    commit: { event, outbox: registerOutbox({ organizationId: "demo-organization", eventId: event.event_id }) },
    handoff: { required: Boolean(twin.blockers.length === 0), nextAgent: twin.blockers.length === 0 ? "activation" : eligibleAgent?.id ?? "orchestrator" },
  };
}
