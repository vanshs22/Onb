import type { Onboarding, Requirement } from "@/lib/types";
import type { Queryable, Row } from "@/lib/server/sql";

export class PlatformError extends Error {
  constructor(public code: "NOT_FOUND" | "VALIDATION_ERROR" | "VERIFICATION_REJECTED", message: string, public details: Record<string, unknown> = {}) { super(message); }
}

export interface CreateOnboardingInput {
  organizationId: string; actorId: string; idempotencyKey: string;
  customer: { name: string; externalRef?: string };
  title: string; valueCents?: number; templateVersionId?: string;
  contact?: { name: string; email?: string; phone?: string; timezone?: string };
}
interface TemplateRequirement { title?: string; description?: string; owner?: string; stage?: string; clientVisible?: boolean; dueInHours?: number }

/** Deal won → customer (deduplicated by CRM id) → onboarding → requirements from the pinned template version, in one transaction. */
export async function createOnboardingDb(tx: Queryable, input: CreateOnboardingInput) {
  if (!input.customer.name?.trim() || !input.title?.trim()) throw new PlatformError("VALIDATION_ERROR", "Customer name and title are required.");
  const eventKey = `${input.idempotencyKey}:created`;
  const prior = (await tx.query("select aggregate_id from events where organization_id=$1 and idempotency_key=$2", [input.organizationId, eventKey])).rows[0];
  if (prior) {
    const existing = (await tx.query("select id, customer_id, (select count(*) from requirements r where r.onboarding_id = o.id) as n from onboarding_instances o where id=$1 and organization_id=$2", [prior.aggregate_id, input.organizationId])).rows[0];
    if (existing) return { onboardingId: existing.id as string, customerId: existing.customer_id as string, requirementCount: Number(existing.n), replayed: true };
  }

  let definition: { requirements?: TemplateRequirement[] } = {};
  if (input.templateVersionId) {
    const version = (await tx.query("select definition from onboarding_template_versions where id=$1 and organization_id=$2 and published_at is not null", [input.templateVersionId, input.organizationId])).rows[0];
    if (!version) throw new PlatformError("NOT_FOUND", "Template version not found or not published.");
    definition = version.definition as typeof definition;
  }
  const customer = input.customer.externalRef
    ? (await tx.query("insert into customers (organization_id, name, external_ref) values ($1,$2,$3) on conflict (organization_id, external_ref) do update set name = excluded.name returning id", [input.organizationId, input.customer.name.trim(), input.customer.externalRef])).rows[0]
    : (await tx.query("insert into customers (organization_id, name) values ($1,$2) returning id", [input.organizationId, input.customer.name.trim()])).rows[0];
  const onboarding = (await tx.query("insert into onboarding_instances (organization_id, customer_id, template_version_id, owner_user_id, title, value_cents) values ($1,$2,$3,$4,$5,$6) returning id", [input.organizationId, customer.id, input.templateVersionId ?? null, /^[0-9a-f-]{36}$/i.test(input.actorId) ? input.actorId : null, input.title.trim(), input.valueCents ?? 0])).rows[0];

  const owners = new Set(["CUSTOMER", "INTERNAL", "SYSTEM"]);
  let count = 0;
  for (const r of (definition.requirements ?? []).slice(0, 200)) {
    if (!r.title) continue;
    await tx.query("insert into requirements (organization_id, onboarding_id, title, description, owner_type, stage, client_visible, priority, due_at) values ($1,$2,$3,$4,$5,$6,$7,$8, case when $9::int is null then null else now() + make_interval(hours => $9::int) end)", [input.organizationId, onboarding.id, r.title, r.description ?? "", owners.has(r.owner ?? "") ? r.owner : "CUSTOMER", r.stage ?? "General", r.clientVisible ?? false, 200 - count, Number.isInteger(r.dueInHours) ? r.dueInHours : null]);
    count += 1;
  }
  if (input.contact?.name) {
    const contact = (await tx.query("insert into customer_contacts (organization_id, customer_id, name, email, phone, timezone, is_primary) values ($1,$2,$3,$4,$5,$6,true) returning id", [input.organizationId, customer.id, input.contact.name, input.contact.email ?? null, input.contact.phone ?? null, input.contact.timezone ?? "UTC"])).rows[0];
    await tx.query("insert into onboarding_contacts (organization_id, onboarding_id, contact_id, role) values ($1,$2,$3,'PRIMARY')", [input.organizationId, onboarding.id, contact.id]);
  }
  const event = (await tx.query("insert into events (organization_id, aggregate_type, aggregate_id, event_type, sequence, idempotency_key, actor_type, actor_id, payload) values ($1,'onboarding',$2,'onboarding.created',1,$3,'USER',$4,$5::jsonb) returning id", [input.organizationId, onboarding.id, eventKey, input.actorId, JSON.stringify({ customerId: customer.id, requirements: count })])).rows[0];
  await tx.query("insert into outbox_messages (organization_id, event_id) values ($1,$2)", [input.organizationId, event.id]);
  await tx.query("insert into audit_logs (organization_id, actor_type, actor_id, action, resource_type, resource_id) values ($1,'USER',$2,'onboarding.created','onboarding',$3)", [input.organizationId, input.actorId, onboarding.id]);
  return { onboardingId: onboarding.id as string, customerId: customer.id as string, requirementCount: count, replayed: false };
}

/** A human/provider verifies evidence; the producer of the evidence can never be its own verifier. */
export async function verifyRequirementDb(tx: Queryable, input: { organizationId: string; requirementId: string; evidenceType: string; source: string; producer: string; verifier: string; idempotencyKey: string }) {
  const eventKey = `${input.idempotencyKey}:verified`;
  if ((await tx.query("select 1 from events where organization_id=$1 and idempotency_key=$2", [input.organizationId, eventKey])).rows.length) return { requirementId: input.requirementId, replayed: true };
  const requirement = (await tx.query("select id from requirements where id=$1 and organization_id=$2 for update", [input.requirementId, input.organizationId])).rows[0];
  if (!requirement) throw new PlatformError("NOT_FOUND", "Requirement was not found.");
  if (input.producer === input.verifier) throw new PlatformError("VERIFICATION_REJECTED", "The party that produced the evidence cannot verify it.");
  const evidence = (await tx.query("insert into evidence (organization_id, requirement_id, type, source, producer) values ($1,$2,$3,$4,$5) returning id", [input.organizationId, input.requirementId, input.evidenceType, input.source, input.producer])).rows[0];
  const verification = (await tx.query("insert into verifications (organization_id, requirement_id, evidence_id, status, verifier) values ($1,$2,$3,'PASSED',$4) returning id", [input.organizationId, input.requirementId, evidence.id, input.verifier])).rows[0];
  await tx.query("update requirements set status='SATISFIED' where id=$1 and organization_id=$2", [input.requirementId, input.organizationId]);
  const sequence = Number((await tx.query("select coalesce(max(sequence),0)+1 as n from events where aggregate_type='requirement' and aggregate_id=$1", [input.requirementId])).rows[0].n);
  const event = (await tx.query("insert into events (organization_id, aggregate_type, aggregate_id, event_type, sequence, idempotency_key, actor_type, actor_id, payload) values ($1,'requirement',$2,'evidence.verified',$3,$4,'USER',$5,$6::jsonb) returning id", [input.organizationId, input.requirementId, sequence, eventKey, input.verifier, JSON.stringify({ evidenceId: evidence.id, verifier: input.verifier })])).rows[0];
  await tx.query("insert into outbox_messages (organization_id, event_id) values ($1,$2)", [input.organizationId, event.id]);
  return { requirementId: input.requirementId, evidenceId: evidence.id as string, verificationId: verification.id as string, replayed: false };
}

// ───── read model shaped for the admin UI ─────
export function relativeTime(date: Date, now = new Date()): string {
  const minutes = Math.round((now.getTime() - date.getTime()) / 60_000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  if (minutes < 1440) return `${Math.round(minutes / 60)}h ago`;
  return `${Math.round(minutes / 1440)}d ago`;
}
const dueLabel = (due: Date | null, done: boolean, now: Date) => done ? "Complete" : !due ? "No deadline" : due < now ? `Overdue ${relativeTime(due, now).replace(" ago", "")}` : `Due in ${Math.max(1, Math.round((due.getTime() - now.getTime()) / 3_600_000))}h`;
const ownerLabel: Record<string, Requirement["owner"]> = { CUSTOMER: "Customer", INTERNAL: "Internal team", SYSTEM: "System" };

export function mapOnboardingRow(row: Row, now = new Date()): Onboarding {
  const reqs = ((row.requirements as Row[] | null) ?? []).map((r): Requirement => {
    const done = r.status === "SATISFIED" || r.status === "WAIVED";
    return { id: String(r.id), title: String(r.title), description: String(r.description ?? ""), owner: ownerLabel[String(r.owner)] ?? "Customer", stage: String(r.stage), status: (r.status === "WAIVED" ? "SATISFIED" : r.status) as Requirement["status"], impact: `Required for ${String(r.stage)}`, due: dueLabel(r.due_at ? new Date(String(r.due_at)) : null, done, now), clientVisible: Boolean(r.client_visible), verified: r.status === "SATISFIED" };
  });
  const satisfied = reqs.filter((r) => r.status === "SATISFIED").length;
  const open = reqs.find((r) => r.status !== "SATISFIED");
  const blocked = reqs.find((r) => r.status === "BLOCKED");
  const customer = String(row.customer);
  return {
    id: String(row.id), customer, initials: customer.split(/\s+/).map((p) => p[0]).slice(0, 2).join("").toUpperCase(), package: String(row.title),
    value: new Intl.NumberFormat("en-US", { style: "currency", currency: String(row.currency ?? "USD"), maximumFractionDigits: 0 }).format(Number(row.value_cents ?? 0) / 100),
    state: row.state as Onboarding["state"], progress: reqs.length ? Math.round((satisfied / reqs.length) * 100) : 0,
    health: Number(row.health_score ?? 100), risk: row.risk as Onboarding["risk"], blocker: blocked?.title, owner: String(row.owner ?? "Unassigned"),
    lastActivity: relativeTime(new Date(String(row.updated_at)), now), nextAction: open?.title ?? "Verify activation", requirements: reqs,
  };
}

export async function listOnboardingsDb(tx: Queryable, organizationId: string, now = new Date()): Promise<Onboarding[]> {
  const rows = (await tx.query(
    `select o.id, o.title, o.state, o.risk, o.health_score, o.value_cents, o.currency, o.updated_at, c.name as customer, p.display_name as owner,
       coalesce(json_agg(json_build_object('id', r.id, 'title', r.title, 'description', r.description, 'owner', r.owner_type, 'stage', r.stage, 'status', r.status, 'due_at', r.due_at, 'client_visible', r.client_visible) order by r.priority desc, r.created_at) filter (where r.id is not null), '[]'::json) as requirements
     from onboarding_instances o
     join customers c on c.id = o.customer_id and c.organization_id = o.organization_id
     left join profiles p on p.id = o.owner_user_id
     left join requirements r on r.onboarding_id = o.id and r.organization_id = o.organization_id
     where o.organization_id = $1 group by o.id, c.name, p.display_name order by o.updated_at desc limit 200`, [organizationId])).rows;
  return rows.map((row) => mapOnboardingRow(row, now));
}
