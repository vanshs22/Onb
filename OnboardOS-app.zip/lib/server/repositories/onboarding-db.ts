import { createHash } from "node:crypto";
import { assertTransition } from "@/lib/domain";
import type { OnboardingState } from "@/lib/types";
import type { Queryable } from "@/lib/server/sql";
import { TransitionError } from "@/lib/server/transition-service";

export interface DbTransitionCommand { organizationId: string; onboardingId: string; to: OnboardingState; expectedVersion: number; idempotencyKey: string; actor: { type: "USER" | "AGENT" | "SYSTEM"; id: string } }
export interface DbTransitionResult { onboarding: { id: string; state: OnboardingState; version: number }; eventId: string; replayed: boolean }

/** One transaction: idempotency claim, row lock, optimistic version check, state change, event, outbox, audit. */
export async function transitionOnboardingDb(tx: Queryable, cmd: DbTransitionCommand): Promise<DbTransitionResult> {
  const hash = createHash("sha256").update(JSON.stringify([cmd.onboardingId, cmd.to, cmd.expectedVersion])).digest("hex");
  const claimed = await tx.query(
    "insert into idempotency_keys (organization_id, key, request_hash, expires_at) values ($1,$2,$3, now() + interval '24 hours') on conflict (organization_id, key) do nothing returning id",
    [cmd.organizationId, cmd.idempotencyKey, hash],
  );
  if (claimed.rows.length === 0) {
    const prior = (await tx.query("select request_hash, status, response_body from idempotency_keys where organization_id=$1 and key=$2", [cmd.organizationId, cmd.idempotencyKey])).rows[0];
    if (!prior || prior.request_hash !== hash) throw new TransitionError("IDEMPOTENCY_CONFLICT", "The idempotency key was already used for a different command.");
    if (prior.status !== "SUCCEEDED") throw new TransitionError("CONFLICT", "A request with this idempotency key is still in progress.");
    return { ...(prior.response_body as Omit<DbTransitionResult, "replayed">), replayed: true };
  }

  const current = (await tx.query("select state, version from onboarding_instances where id=$1 and organization_id=$2 for update", [cmd.onboardingId, cmd.organizationId])).rows[0];
  if (!current) throw new TransitionError("NOT_FOUND", "Onboarding was not found.");
  if (Number(current.version) !== cmd.expectedVersion) throw new TransitionError("CONFLICT", "The onboarding changed since it was read.", { expectedVersion: cmd.expectedVersion, currentVersion: Number(current.version) });
  try { assertTransition(current.state as OnboardingState, cmd.to); } catch { throw new TransitionError("STATE_TRANSITION_INVALID", `Cannot transition ${current.state} to ${cmd.to}.`, { from: current.state, to: cmd.to }); }

  let updated;
  try {
    updated = (await tx.query("update onboarding_instances set state=$3 where id=$1 and organization_id=$2 returning version", [cmd.onboardingId, cmd.organizationId, cmd.to])).rows[0];
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (message.includes("ACTIVATION_")) throw new TransitionError("ACTIVATION_BLOCKED", message.replace(/^[\s\S]*?(ACTIVATION_\w+)[\s\S]*$/, "$1"), { to: cmd.to });
    throw error;
  }
  if (!updated) throw new TransitionError("NOT_FOUND", "Onboarding was not found.");

  const sequence = Number((await tx.query("select coalesce(max(sequence),0)+1 as next from events where aggregate_type='onboarding' and aggregate_id=$1", [cmd.onboardingId])).rows[0].next);
  const event = (await tx.query(
    "insert into events (organization_id, aggregate_type, aggregate_id, event_type, sequence, idempotency_key, actor_type, actor_id, payload) values ($1,'onboarding',$2,'onboarding.state_changed',$3,$4,$5,$6,$7::jsonb) returning id",
    [cmd.organizationId, cmd.onboardingId, sequence, `${cmd.idempotencyKey}:state_changed`, cmd.actor.type, cmd.actor.id, JSON.stringify({ from: current.state, to: cmd.to, version: Number(updated.version) })],
  )).rows[0];
  await tx.query("insert into outbox_messages (organization_id, event_id) values ($1,$2)", [cmd.organizationId, event.id]);
  await tx.query("insert into audit_logs (organization_id, actor_type, actor_id, action, resource_type, resource_id, metadata) values ($1,$2,$3,'onboarding.state_changed','onboarding',$4,$5::jsonb)", [cmd.organizationId, cmd.actor.type, cmd.actor.id, cmd.onboardingId, JSON.stringify({ from: current.state, to: cmd.to })]);

  const result = { onboarding: { id: cmd.onboardingId, state: cmd.to, version: Number(updated.version) }, eventId: event.id as string };
  await tx.query("update idempotency_keys set status='SUCCEEDED', response_code=200, response_body=$3::jsonb where organization_id=$1 and key=$2", [cmd.organizationId, cmd.idempotencyKey, JSON.stringify(result)]);
  return { ...result, replayed: false };
}
