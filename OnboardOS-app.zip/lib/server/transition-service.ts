import { createHash } from "node:crypto";
import { createEvent } from "@/lib/api";
import { assertTransition } from "@/lib/domain";
import { onboardings } from "@/lib/demo-data";
import type { OnboardingState } from "@/lib/types";

type Actor = { type: "user" | "agent" | "system" | "customer_contact"; id: string };
type VersionedOnboarding = (typeof onboardings)[number] & { version: number };
type TransitionCommand = {
  organizationId: string;
  onboardingId: string;
  to: OnboardingState;
  expectedVersion: number;
  idempotencyKey: string;
  actor: Actor;
};

export class TransitionError extends Error {
  constructor(public code: "NOT_FOUND" | "STATE_TRANSITION_INVALID" | "CONFLICT" | "IDEMPOTENCY_CONFLICT" | "ACTIVATION_BLOCKED", message: string, public details: Record<string, unknown> = {}) {
    super(message);
  }
}

interface StoredIdempotencyResult {
  requestHash: string;
  result: TransitionResult;
}

export interface TransitionResult {
  onboarding: VersionedOnboarding;
  event: ReturnType<typeof createEvent>;
  outbox: { id: string; status: "PENDING"; eventId: string; idempotencyKey: string };
}

// This module is the executable contract used by the API today. Replace the maps with
// Prisma transaction calls in deployment; the command/result shape remains identical.
const versions = new Map(onboardings.map((item) => [item.id, 1]));
const idempotency = new Map<string, StoredIdempotencyResult>();
const sequences = new Map<string, number>();

function requestHash(command: TransitionCommand) {
  return createHash("sha256").update(JSON.stringify({ onboardingId: command.onboardingId, to: command.to, expectedVersion: command.expectedVersion })).digest("hex");
}

export function transitionOnboarding(command: TransitionCommand): TransitionResult {
  const scopeKey = `${command.organizationId}:${command.idempotencyKey}`;
  const hash = requestHash(command);
  const prior = idempotency.get(scopeKey);
  if (prior) {
    if (prior.requestHash !== hash) throw new TransitionError("IDEMPOTENCY_CONFLICT", "The idempotency key was already used for a different command.");
    return prior.result;
  }

  const source = onboardings.find((item) => item.id === command.onboardingId);
  if (!source) throw new TransitionError("NOT_FOUND", "Onboarding was not found.");
  const currentVersion = versions.get(source.id) ?? 1;
  if (currentVersion !== command.expectedVersion) {
    throw new TransitionError("CONFLICT", "The onboarding changed since it was read.", { expectedVersion: command.expectedVersion, currentVersion });
  }

  try {
    assertTransition(source.state, command.to);
  } catch {
    throw new TransitionError("STATE_TRANSITION_INVALID", `Cannot transition ${source.state} to ${command.to}.`, { from: source.state, to: command.to });
  }

  const nextVersion = currentVersion + 1;
  const next = { ...source, state: command.to, version: nextVersion } as VersionedOnboarding;
  const nextSequence = (sequences.get(source.id) ?? 0) + 1;
  const event = createEvent({
    event_type: "onboarding.state_changed",
    organization_id: command.organizationId,
    aggregate_type: "onboarding",
    aggregate_id: source.id,
    correlation_id: command.idempotencyKey,
    idempotency_key: command.idempotencyKey,
    actor: command.actor,
    sequence: nextSequence,
    payload: { from: source.state, to: command.to, version: nextVersion },
  });
  const result: TransitionResult = {
    onboarding: next,
    event,
    outbox: { id: `outbox_${event.event_id}`, status: "PENDING", eventId: event.event_id, idempotencyKey: command.idempotencyKey },
  };

  // The production transaction performs all four writes atomically:
  // aggregate mutation, event, outbox message, and idempotency response.
  versions.set(source.id, nextVersion);
  sequences.set(source.id, nextSequence);
  idempotency.set(scopeKey, { requestHash: hash, result });
  return result;
}
