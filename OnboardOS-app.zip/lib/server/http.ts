import { NextResponse } from "next/server";
import { AuthenticationError, authenticateRequest } from "@/lib/server/authentication";
import { can, type ActorContext, type Permission } from "@/lib/server/authorization";
import { ConfigurationError } from "@/lib/server/config";

export function fail(code: string, message: string, status: number, details: Record<string, unknown> = {}) {
  return NextResponse.json({ error: { code, message, details, request_id: crypto.randomUUID(), retryable: status >= 500, field_errors: [] } }, { status });
}

/** Maps authentication/configuration errors to HTTP responses; returns null for anything else. */
export function toAuthResponse(error: unknown): NextResponse | null {
  if (error instanceof AuthenticationError) {
    const status = error.code === "AUTHENTICATION_REQUIRED" ? 401 : error.code === "ORGANIZATION_REQUIRED" ? 409 : 403;
    return fail(error.code, error.message, status, error.details);
  }
  if (error instanceof ConfigurationError) return fail("SERVICE_UNAVAILABLE", error.message, 503);
  return null;
}

export async function guard(request: Request, permission: Permission): Promise<{ actor: ActorContext } | { response: NextResponse }> {
  try {
    const actor = await authenticateRequest(request);
    if (!can(actor, permission)) return { response: fail("FORBIDDEN", `Missing permission ${permission}.`, 403) };
    return { actor };
  } catch (error) {
    const response = toAuthResponse(error);
    if (response) return { response };
    throw error;
  }
}
