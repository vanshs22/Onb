import Stripe from "stripe";
import { runtimeConfig } from "@/lib/server/config";

export class PaymentConfigurationError extends Error { constructor(message: string) { super(message); this.name = "PAYMENT_CONFIGURATION_ERROR"; } }
function stripeClient() {
  const config = runtimeConfig();
  if (!config.stripeSecretKey) {
    if (config.demoMode) return null;
    throw new PaymentConfigurationError("STRIPE_SECRET_KEY is required for production payment execution.");
  }
  // Test seam: lets the end-to-end suite point at a local Stripe stand-in. Ignored for live keys.
  const override = process.env.STRIPE_API_BASE && config.stripeSecretKey.startsWith("sk_test_") ? new URL(process.env.STRIPE_API_BASE) : null;
  return new Stripe(config.stripeSecretKey, override ? { host: override.hostname, port: override.port, protocol: override.protocol.replace(":", "") as "http" | "https", maxNetworkRetries: 0 } : undefined);
}

export async function createCheckout(input: { invoiceId: string; organizationId: string; amountCents: number; currency: string; customerEmail?: string; description: string; idempotencyKey: string }) {
  if (!Number.isInteger(input.amountCents) || input.amountCents < 50) throw new PaymentConfigurationError("Payment amount must be an integer of at least 50 minor units.");
  const stripe = stripeClient();
  const base = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  if (!stripe) return { mode: "demo", sessionId: `cs_demo_${input.invoiceId}`, url: `${base}/demo-payment/${input.invoiceId}`, status: "PENDING", amountCents: input.amountCents };
  const session = await stripe.checkout.sessions.create({
    mode: "payment", customer_email: input.customerEmail,
    line_items: [{ price_data: { currency: input.currency.toLowerCase(), product_data: { name: input.description }, unit_amount: input.amountCents }, quantity: 1 }],
    metadata: { invoiceId: input.invoiceId, organizationId: input.organizationId },
    payment_intent_data: { metadata: { invoiceId: input.invoiceId, organizationId: input.organizationId } },
    success_url: `${base}/?payment=success`, cancel_url: `${base}/?payment=cancelled`,
  }, { idempotencyKey: input.idempotencyKey });
  return { mode: "stripe", sessionId: session.id, url: session.url, status: session.status, amountCents: input.amountCents };
}

export function verifyStripeWebhook(rawBody: string, signature: string) {
  const config = runtimeConfig();
  if (!config.stripeWebhookSecret) throw new PaymentConfigurationError("STRIPE_WEBHOOK_SECRET is required to verify payment webhooks.");
  return Stripe.webhooks.constructEvent(rawBody, signature, config.stripeWebhookSecret);
}
