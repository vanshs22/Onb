import { randomUUID } from "node:crypto";
import { createEvent } from "@/lib/api";
import type { EventEnvelope } from "@/lib/domain";
import { canSend, getCommunicationPreferences } from "@/lib/server/communication-preferences";

type DemoStep = { key: string; label: string; status: "PASSED" | "SIMULATED"; eventType: string; detail: string; evidence?: string[]; elapsedHours: number; scheduledAt: string };
interface DemoRun { runId: string; customer: { id: string; name: string; contact: string }; onboarding: { id: string; state: "COMPLETED"; progress: 100 }; invoice: { id: string; amountCents: number; status: "PAID"; provider: "demo-stripe" }; communication: { preferences: ReturnType<typeof getCommunicationPreferences>; followUpPolicy: { firstReminderAfterHours: number; secondChannelAfterHours: number; escalationAfterHours: number; optOutEnforced: boolean }; followUpDecision: ReturnType<typeof canSend> }; steps: DemoStep[]; events: EventEnvelope[]; activationCertificate: { certificateId: string; status: "ACTIVATED"; criteria: string[]; activatedAt: string }; handoff: { status: "COMPLETED"; owner: string; openIssues: string[] }; completedAt: string; }

const runs = new Map<string, DemoRun>();

export function runDemoCustomer(idempotencyKey = "demo-customer-default"): DemoRun {
  const existing = runs.get(idempotencyKey);
  if (existing) return existing;
  const organizationId = "demo-organization";
  const customerId = `customer_${randomUUID()}`;
  const onboardingId = `onboarding_${randomUUID()}`;
  const invoiceId = `invoice_${randomUUID()}`;
  const start = new Date();
  const at = (hours: number) => new Date(start.getTime() + hours * 60 * 60 * 1000).toISOString();
  const events: EventEnvelope[] = [];
  const steps: DemoStep[] = [];
  let sequence = 0;
  const add = (key: string, label: string, eventType: EventEnvelope["event_type"], detail: string, evidence: string[] = [], elapsedHours = 0) => {
    sequence += 1;
    events.push(createEvent({ event_type: eventType, organization_id: organizationId, aggregate_type: "onboarding", aggregate_id: onboardingId, sequence, correlation_id: idempotencyKey, idempotency_key: `${idempotencyKey}:${key}`, actor: { type: "system", id: "demo-runner" }, payload: { customerId, detail, evidence, scheduledAt: at(elapsedHours) } }));
    steps.push({ key, label, status: "SIMULATED", eventType, detail, evidence, elapsedHours, scheduledAt: at(elapsedHours) });
  };

  const followUpDecision = canSend(customerId, "EMAIL");
  add("deal-won", "Deal won imported from CRM", "customer.created", "Acme Demo Agency deal imported and customer resolved.", [], 0);
  add("onboarding-created", "Onboarding generated", "onboarding.created", "Paid Ads Launch v3 snapshot created with promise and scope graph.", [], 0);
  add("launched", "Onboarding launched", "onboarding.launched", "Customer workspace invitation issued.", [], 0);
  add("agreement-sent", "Agreement sent", "contract.sent", "Demo agreement sent through the simulated e-sign adapter.", [], 0);
  add("agreement-signed", "Agreement signed", "contract.signed", "Signature evidence received and independently recorded.", ["signature:demo-agreement"], 6);
  add("invoice-created", "Invoice created", "payment.requested", `Invoice ${invoiceId} created for $8,000.00.`, [`invoice:${invoiceId}`], 6);
  add("payment-succeeded", "Payment succeeded", "payment.succeeded", "Simulated Stripe checkout completed; commercial gate passed.", [`payment:demo-${invoiceId}`], 8);
  add("intake-completed", "Intake completed", "task.completed", "Customer questionnaire submitted and normalized into structured intake.", ["form:demo-intake"], 24);
  add("assets-verified", "Brand assets verified", "evidence.verified", "Uploaded logo and brand guide passed document verification.", ["document:demo-brand-guide"], 36);
  add("access-requested", "Access requested", "requirement.created", "Google Ads access requirement created with campaign setup dependency.", [], 36);
  add("follow-up-sent", "Contextual follow-up sent", "message.sent", followUpDecision.allowed ? "Chase Agent sent an email reminder after 24 hours of inactivity; SMS/WhatsApp remain consent-gated." : `Follow-up suppressed: ${followUpDecision.reason}.`, ["message:demo-reminder"], 60);
  add("access-verified", "Google Ads access verified", "evidence.verified", "Simulated OAuth callback verified account identity and permissions.", ["oauth:demo-google-ads", "permission:campaign.write"], 84);
  add("kickoff-scheduled", "Kickoff scheduled", "meeting.scheduled", "Kickoff booking created and participants confirmed.", ["appointment:demo-kickoff"], 84);
  add("kickoff-completed", "Kickoff completed", "meeting.completed", "Kickoff notes stored in the onboarding twin.", [], 108);
  add("implementation-completed", "Implementation completed", "task.completed", "Campaign configuration and tracking validation completed.", ["api-record:demo-campaign", "api-record:demo-tracking"], 132);
  add("approval-requested", "Customer approval requested", "approval.requested", "Campaign draft sent to the customer approval workspace.", [], 144);
  add("approval-approved", "Customer approval received", "approval.approved", "Approval event stored as activation evidence.", ["approval:demo-campaign"], 168);
  add("activation-started", "Activation verification started", "activation.started", "Activation Agent evaluated first-value criteria.", [], 169);
  add("first-value", "First valid event received", "activation.verified", "Simulated provider webhook recorded the first qualified lead.", ["webhook:demo-first-lead"], 192);
  add("activation-completed", "Customer activated", "activation.completed", "All configured activation criteria passed independently.", ["certificate:demo-activation"], 192);
  add("handoff", "Handoff completed", "handoff.completed", "Goals, scope, configuration, evidence, risks, and next milestones handed to customer success.", ["handoff:demo-package"], 193);

  const result: DemoRun = {
    runId: `demo_run_${randomUUID()}`,
    customer: { id: customerId, name: "Acme Demo Agency", contact: "demo-customer@example.test" },
    onboarding: { id: onboardingId, state: "COMPLETED", progress: 100 },
    invoice: { id: invoiceId, amountCents: 800000, status: "PAID", provider: "demo-stripe" },
    communication: { preferences: getCommunicationPreferences(customerId), followUpPolicy: { firstReminderAfterHours: 24, secondChannelAfterHours: 48, escalationAfterHours: 72, optOutEnforced: true }, followUpDecision },
    steps,
    events,
    activationCertificate: { certificateId: `certificate_${randomUUID()}`, status: "ACTIVATED", criteria: ["agreement signed", "payment succeeded", "intake completed", "brand assets verified", "Google Ads access verified", "campaign approved", "campaign live", "first valid lead"], activatedAt: at(192) },
    handoff: { status: "COMPLETED", owner: "Customer Success", openIssues: [] },
    completedAt: at(193),
  };
  runs.set(idempotencyKey, result);
  return result;
}
