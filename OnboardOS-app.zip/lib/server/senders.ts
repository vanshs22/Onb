import type { MessageSender } from "@/lib/server/followups";

/** Real provider adapters. They need credentials; without them sending fails loudly so jobs retry instead of pretending. */
export function createSender(): MessageSender {
  return {
    async send({ channel, to, subject, body, idempotencyKey, unsubscribeUrl }) {
      if (channel === "EMAIL") {
        const key = process.env.RESEND_API_KEY; const from = process.env.EMAIL_FROM;
        if (!key || !from || !to.email) throw new Error("EMAIL_PROVIDER_NOT_CONFIGURED");
        const response = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json", "Idempotency-Key": idempotencyKey }, body: JSON.stringify({ from, to: [to.email], subject, text: `${body}\n\nUnsubscribe: ${unsubscribeUrl}`, headers: { "List-Unsubscribe": `<${unsubscribeUrl}>`, "List-Unsubscribe-Post": "List-Unsubscribe=One-Click" } }) });
        if (!response.ok) throw new Error(`EMAIL_PROVIDER_ERROR_${response.status}`);
        return { providerMessageId: String(((await response.json()) as { id?: string }).id ?? idempotencyKey) };
      }
      if (channel === "SMS" || channel === "WHATSAPP") {
        const sid = process.env.TWILIO_ACCOUNT_SID; const token = process.env.TWILIO_AUTH_TOKEN; const from = process.env.TWILIO_FROM;
        if (!sid || !token || !from || !to.phone) throw new Error("MESSAGING_PROVIDER_NOT_CONFIGURED");
        const wa = channel === "WHATSAPP";
        const form = new URLSearchParams({ To: wa ? `whatsapp:${to.phone}` : to.phone, From: wa ? `whatsapp:${from}` : from, Body: `${body}${wa ? "" : " Reply STOP to opt out."}` });
        const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, { method: "POST", headers: { Authorization: `Basic ${Buffer.from(`${sid}:${token}`).toString("base64")}`, "Content-Type": "application/x-www-form-urlencoded" }, body: form });
        if (!response.ok) throw new Error(`MESSAGING_PROVIDER_ERROR_${response.status}`);
        return { providerMessageId: String(((await response.json()) as { sid?: string }).sid ?? idempotencyKey) };
      }
      throw new Error(`UNSUPPORTED_CHANNEL_${channel}`);
    },
  };
}
