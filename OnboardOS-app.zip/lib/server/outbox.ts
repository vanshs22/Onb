import { randomUUID } from "node:crypto";

type OutboxStatus = "PENDING" | "PUBLISHED" | "FAILED";
export interface OutboxRecord {
  id: string;
  organizationId: string;
  eventId: string;
  status: OutboxStatus;
  attempts: number;
  availableAt: string;
  lastError?: string;
}

const records = new Map<string, OutboxRecord>();

export function registerOutbox(record: Omit<OutboxRecord, "id" | "status" | "attempts" | "availableAt"> & Partial<Pick<OutboxRecord, "id" | "status" | "attempts" | "availableAt">>) {
  const next: OutboxRecord = { id: record.id ?? `outbox_${randomUUID()}`, status: "PENDING", attempts: 0, availableAt: new Date().toISOString(), ...record };
  records.set(next.id, next);
  return next;
}

export function replayOutbox(organizationId: string, limit = 50) {
  const pending = [...records.values()].filter((record) => record.organizationId === organizationId && record.status !== "PUBLISHED").slice(0, limit);
  return pending.map((record) => {
    const next = { ...record, status: "PUBLISHED" as const, attempts: record.attempts + 1 };
    records.set(record.id, next);
    return next;
  });
}

export function outboxHealth(organizationId: string) {
  const scoped = [...records.values()].filter((record) => record.organizationId === organizationId);
  return { pending: scoped.filter((record) => record.status === "PENDING").length, failed: scoped.filter((record) => record.status === "FAILED").length, published: scoped.filter((record) => record.status === "PUBLISHED").length };
}
