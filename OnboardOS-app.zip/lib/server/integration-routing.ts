import { CAPABILITY_DEFAULTS, PROVIDER_CATALOG } from "@/lib/integration-catalog";

export function routeCapability(input: { capability: string; preferredProvider?: string; connectedProviders?: string[] }) {
  const defaults = CAPABILITY_DEFAULTS[input.capability];
  if (!defaults) return { capability: input.capability, selected: "onboardos", reason: "native_default", available: false };
  const connected = new Set(input.connectedProviders ?? ["onboardos"]);
  const candidates = input.preferredProvider ? [input.preferredProvider, defaults.native, ...defaults.external] : [defaults.native, ...defaults.external];
  const selected = candidates.find((provider) => connected.has(provider)) ?? defaults.native;
  const provider = PROVIDER_CATALOG.find((candidate) => candidate.id === selected);
  return { capability: input.capability, selected, mode: provider?.modes[0] ?? "NATIVE", sourceOfTruth: provider?.sourceOfTruth ?? "ONBOARDOS", reason: selected === defaults.native ? "native_or_fallback" : input.preferredProvider === selected ? "customer_preference" : "connected_external_provider", available: connected.has(selected), provider };
}

export function normalizeProviderEvent(provider: string, providerEvent: string, payload: Record<string, unknown>) {
  const eventMap: Record<string, string> = { "contract.signed": "contract.signed", "invoice.paid": "payment.succeeded", "payment.succeeded": "payment.succeeded", "form.submitted": "task.completed", "task.updated": "task.completed", "project.health_changed": "onboarding.health.changed", "health.changed": "onboarding.health.changed", "deal.won": "onboarding.created" };
  return { eventId: typeof payload.id === "string" ? payload.id : `${provider}:${Date.now()}`, provider, providerEvent, canonicalEvent: eventMap[providerEvent] ?? "integration.event.received", payload, normalizedAt: new Date().toISOString() };
}
