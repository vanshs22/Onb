import { randomUUID } from "node:crypto";
import { createEvent } from "@/lib/api";
import { onboardings } from "@/lib/demo-data";
import { registerOutbox } from "@/lib/server/outbox";
import type { EvidenceType } from "@/lib/types";

type VerificationCommand = { organizationId: string; requirementId: string; evidenceType: EvidenceType; source: string; actorId: string; idempotencyKey: string };
export class VerificationError extends Error {
  constructor(public code: "NOT_FOUND" | "VALIDATION_ERROR" | "VERIFICATION_CONFLICT", message: string) { super(message); }
}

type VerificationResult = {
  requirement: (typeof onboardings)[number]["requirements"][number];
  evidence: { id: string; requirementId: string; type: EvidenceType; source: string; createdAt: string };
  verification: { id: string; evidenceId: string; requirementId: string; status: "PASSED"; verifier: string; checkedAt: string };
  event: ReturnType<typeof createEvent>;
  outbox: ReturnType<typeof registerOutbox>;
};
const processed = new Map<string, VerificationResult>();

export function verifyRequirement(command: VerificationCommand): VerificationResult {
  const prior = processed.get(`${command.organizationId}:${command.idempotencyKey}`);
  if (prior) return prior;
  const match = onboardings.flatMap((onboarding) => onboarding.requirements.map((requirement) => ({ onboarding, requirement }))).find(({ requirement }) => requirement.id === command.requirementId);
  if (!match) throw new VerificationError("NOT_FOUND", "Requirement was not found.");
  if (match.requirement.status === "SATISFIED" && match.requirement.verified) throw new VerificationError("VERIFICATION_CONFLICT", "This requirement is already verified.");

  const evidence = { id: `evidence_${randomUUID()}`, requirementId: command.requirementId, type: command.evidenceType, source: command.source, createdAt: new Date().toISOString() };
  const verification = { id: `verification_${randomUUID()}`, evidenceId: evidence.id, requirementId: command.requirementId, status: "PASSED" as const, verifier: `${command.evidenceType}_PROVIDER`, checkedAt: new Date().toISOString() };
  match.requirement.status = "SATISFIED";
  match.requirement.verified = true;
  const event = createEvent({
    event_type: "evidence.verified",
    organization_id: command.organizationId,
    aggregate_type: "requirement",
    aggregate_id: command.requirementId,
    correlation_id: command.idempotencyKey,
    idempotency_key: command.idempotencyKey,
    actor: { type: "system", id: command.actorId },
    payload: { requirement_id: command.requirementId, evidence_id: evidence.id, verifier: verification.verifier },
  });
  const outbox = registerOutbox({ organizationId: command.organizationId, eventId: event.event_id });
  const result = { requirement: match.requirement, evidence, verification, event, outbox };
  processed.set(`${command.organizationId}:${command.idempotencyKey}`, result);
  return result;
}
