export class ConfigurationError extends Error { constructor(message: string) { super(message); this.name = "CONFIGURATION_ERROR"; } }

export function runtimeConfig() {
  const isProduction = process.env.NODE_ENV === "production";
  const authSecret = process.env.AUTH_SECRET;
  if (isProduction && (!authSecret || authSecret.length < 32)) throw new ConfigurationError("AUTH_SECRET must be configured with at least 32 characters in production.");
  return {
    isProduction,
    demoMode: !isProduction && process.env.ONBOARDOS_DEMO_MODE !== "false",
    authSecret: authSecret ?? "development-only-auth-secret-change-me",
    databaseUrl: process.env.DATABASE_URL ?? null,
    stripeSecretKey: process.env.STRIPE_SECRET_KEY ?? null,
    stripeWebhookSecret: process.env.STRIPE_WEBHOOK_SECRET ?? null,
  };
}
