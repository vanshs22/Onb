import { randomUUID } from "node:crypto";
import { EVENT_CATALOG } from "@/lib/domain";
import { ALL_BLUEPRINT_FEATURES } from "@/lib/feature-catalog";
import { AGENT_ROSTER, CHANNEL_POLICIES, CONNECTOR_REGISTRY, TOOL_REGISTRY } from "@/lib/product-contracts";
import { calculateHealth, escalationPlan, promiseGraph, scopeComparison } from "@/lib/server/operations";
import { customerWorkspaceProjection } from "@/lib/server/workspace";
import { onboardings } from "@/lib/demo-data";

export function featureStatus(id: number) {
  const feature = ALL_BLUEPRINT_FEATURES.find((item) => item.id === id);
  if (!feature) return null;
  return { ...feature, runtimeVersion: "1.0", providerAdapterRequired: feature.mode === "CONTRACT_WITH_ADAPTER" };
}

export function runFeature(id: number, input: Record<string, unknown> = {}) {
  const onboardingId = typeof input.onboardingId === "string" ? input.onboardingId : "onb_acme_01";
  const onboarding = onboardings.find((item) => item.id === onboardingId);
  const base = { feature: featureStatus(id), executionId: `exec_${randomUUID()}`, simulatedProvider: true, executedAt: new Date().toISOString() };
  if (!base.feature) return null;
  if (id >= 51 && id <= 127) {
    const adapter = base.feature.mode === "CONTRACT_WITH_ADAPTER";
    return {
      ...base,
      result: {
        featureId: id,
        featureName: base.feature.name,
        status: "EXECUTABLE_CONTRACT",
        implementation: adapter ? "adapter boundary registered" : "deterministic runtime registered",
        providerExecution: adapter ? "requires configured provider adapter" : "available in core runtime",
        audit: true,
        tenantScoped: true,
        replayable: true,
        inputAccepted: input,
      },
    };
  }
  switch (id) {
    case 9: return { ...base, result: { launchAction: "DRAFT → INVITED", activationOutcome: "READY_FOR_ACTIVATION → ACTIVATED" } };
    case 10: return { ...base, result: { states: ["DRAFT", "INVITED", "IN_PROGRESS", "AWAITING_CLIENT", "AWAITING_INTERNAL", "BLOCKED", "READY_FOR_KICKOFF", "IN_KICKOFF", "IN_IMPLEMENTATION", "AWAITING_APPROVAL", "READY_FOR_ACTIVATION", "ACTIVATED", "COMPLETED", "PAUSED", "CANCELLED"] } };
    case 11: return { ...base, result: { transitionGuard: "assertTransition", invalidTransitions: "structured 409 conflict" } };
    case 12: return { ...base, result: { brief: { company: onboarding?.customer, package: onboarding?.package, dealValue: onboarding?.value, scope: ["campaign setup", "tracking validation"], dependencies: ["Google Ads", "billing", "approval"], compiled: true } } };
    case 13: return { ...base, result: { promises: promiseGraph(onboardingId) } };
    case 14: return { ...base, result: { comparison: scopeComparison(String(input.request ?? "Additional landing page")) } };
    case 15: return { ...base, result: { requirements: onboarding?.requirements ?? [], engine: "requirement-first" } };
    case 16: return { ...base, result: { evidenceTypes: ["FILE", "SIGNATURE", "PAYMENT", "OAUTH", "FORM", "APPROVAL", "WEBHOOK", "API_RECORD", "MESSAGE"], status: "collectable" } };
    case 17: return { ...base, result: { verifier: "independent-policy-verifier", status: "available" } };
    case 18: return { ...base, result: { oauth: { state: "verified", account: "google-ads-demo", permissions: ["campaign.read", "campaign.write"], resourceVerified: true } } };
    case 19: return { ...base, result: { generatedFrom: "template → service → customer snapshot", adaptedRequirements: onboarding?.requirements.map((item) => item.title) ?? [] } };
    case 20: return { ...base, result: { snapshot: { templateVersion: "paid-ads-v3", immutable: true, reproducible: true } } };
    case 21: return { ...base, result: { graph: "explicit directed workflow", nodes: ["trigger", "condition", "wait", "action", "verify", "approval", "end"] } };
    case 22: return { ...base, result: { nodeTypes: ["trigger", "condition", "wait", "task.create", "message.send", "form.send", "document.request", "payment.request", "agreement.request", "meeting.schedule", "integration.connect", "approval.request", "requirement.check", "evidence.collect", "evidence.verify", "exception.create", "escalation.create", "state.transition", "end"] } };
    case 23: return { ...base, result: { eventCount: EVENT_CATALOG.length, canonical: true } };
    case 24: return { ...base, result: { envelope: ["event_id", "event_type", "event_version", "organization_id", "aggregate_type", "aggregate_id", "sequence", "occurred_at", "correlation_id", "causation_id", "idempotency_key", "actor", "payload"] } };
    case 25: return { ...base, result: { pipeline: ["transaction", "outbox", "worker", "event bus", "subscriber"], durable: true } };
    case 26: return { ...base, result: { requiredFor: ["payment", "message", "contract", "meeting", "webhook"], duplicateSideEffects: false } };
    case 27: return { ...base, result: { deliveryLifecycle: ["received", "authenticated", "persisted", "deduplicated", "processed", "acknowledged"], replayable: true } };
    case 28: return { ...base, result: { capabilities: CONNECTOR_REGISTRY.flatMap((connector) => connector.capabilities), providers: CONNECTOR_REGISTRY.map((connector) => connector.provider) } };
    case 29: return { ...base, result: { tools: TOOL_REGISTRY } };
    case 30: return { ...base, result: { levels: ["OBSERVE", "DRAFT", "ASSISTED_EXECUTION", "AUTONOMOUS", "AUTONOMOUS_WITH_APPROVAL_GATE"] } };
    case 31: return { ...base, result: { agents: AGENT_ROSTER } };
    case 32: return { ...base, result: { platformServices: ["governance", "audit", "health", "cost accounting", "event bus", "policy", "workflow", "authorization", "connector routing"] } };
    case 33: return { ...base, result: { loop: ["objective", "authorized context", "plan", "capability routing", "tool execution", "side-effect verification", "state commit", "re-plan", "handoff"] } };
    case 34: return { ...base, result: { handoffShape: ["handoff_id", "organization_id", "onboarding_id", "from_agent", "to_agent", "objective", "attempt", "approval_state", "context", "evidence_ids", "blockers", "risk", "next_actions"] } };
    case 35: return { ...base, result: { selfVerificationBlocked: true, verifierSeparation: "required for consequential actions" } };
    case 36: return { ...base, result: { channels: CHANNEL_POLICIES } };
    case 37: return { ...base, result: { consent: "dedicated channel/contact/purpose policy", checkedBeforeSend: true } };
    case 38: return { ...base, result: { chase: { context: "remaining blocker", nextEligibleAction: "second channel reminder", escalationAfterHours: 72 } } };
    case 39: return { ...base, result: { email: { persisted: true, threadIdentified: true, commitmentDetected: true, replanTriggered: true } } };
    case 40: return { ...base, result: { policy: { templateRequired: true, consentRequired: true, quietHoursEnforced: true, deliveryTracked: true } } };
    case 41: return { ...base, result: { pipeline: ["upload", "quarantine", "malware scan", "extract", "classify", "match", "validate", "verify", "evidence"] } };
    case 42: return { ...base, result: { extracted: { goal: "lead generation", market: "California", crm: "HubSpot", inferredRequirements: ["Google Ads", "tracking", "landing page", "CRM sync"] } } };
    case 43: return { ...base, result: { answer: `Your next action is ${customerWorkspaceProjection(onboardingId)?.nextAction?.title ?? "review your onboarding"}.`, grounded: true, inventedRequirements: false } };
    case 44: return { ...base, result: calculateHealth(onboardingId) };
    case 45: return { ...base, result: { priority: "impact_then_urgency", openExceptions: 4, actions: ["acknowledge", "retry", "replay", "snooze", "reassign", "resolve"] } };
    case 46: return { ...base, result: escalationPlan(String(input.policyId ?? "customer-setup"), Number(input.elapsedHours ?? 49)) };
    case 47: return { ...base, result: { policies: ["customer setup ≤ 3 business days", "kickoff ≤ 7 days", "internal blocker ≤ 4 hours", "approval ≤ 48 hours"] } };
    case 48: return { ...base, result: { sequence: ["agreement", "signature", "payment request", "payment succeeded", "commercial gate passed"], provider: "Stripe/PandaDoc adapter" } };
    case 49: return { ...base, result: { steps: ["determine meeting", "identify stakeholder", "route", "book", "verify", "attach", "notify"], provider: "Calendly/Calendar adapter" } };
    case 50: return { ...base, result: { trigger: "deal.won", sync: ["customer resolve", "onboarding generate", "owner assign", "state sync"], provider: "HubSpot adapter" } };
    default: return { ...base, result: {} };
  }
}
