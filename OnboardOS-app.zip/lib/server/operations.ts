import { randomUUID } from "node:crypto";
import { createEvent } from "@/lib/api";
import { onboardings } from "@/lib/demo-data";
import { PAID_ADS_ACTIVATION, SLA_POLICIES, type Channel, type PromiseNode, type ScopeItem } from "@/lib/product-contracts";
import { registerOutbox } from "@/lib/server/outbox";

export function calculateHealth(onboardingId: string) {
  const onboarding = onboardings.find((item) => item.id === onboardingId);
  if (!onboarding) return null;
  const missing = onboarding.requirements.filter((item) => item.status !== "SATISFIED");
  const blocked = onboarding.requirements.filter((item) => item.status === "BLOCKED");
  const score = Math.max(0, Math.min(100, 100 - (missing.length * 7) - (blocked.length * 18) - (onboarding.risk === "CRITICAL" ? 25 : onboarding.risk === "HIGH" ? 14 : onboarding.risk === "MEDIUM" ? 6 : 0)));
  const riskBand = score < 40 ? "CRITICAL" : score < 60 ? "HIGH" : score < 80 ? "MEDIUM" : "LOW";
  return { score, riskBand, calculationVersion: "health-v1", calculatedAt: new Date().toISOString(), reasonCodes: [...blocked.map((item) => `BLOCKED:${item.title}`), ...missing.filter((item) => item.status !== "BLOCKED").map((item) => `MISSING:${item.title}`)], inputs: { missingRequirements: missing.length, blockedRequirements: blocked.length, activationProximity: onboarding.progress } };
}

export function activationReadiness(onboardingId: string) {
  const onboarding = onboardings.find((item) => item.id === onboardingId);
  if (!onboarding) return null;
  const criterionMatchers: Record<string, (title: string) => boolean> = {
    "google-ads-connected": (title) => title.toLowerCase().includes("google ads"),
    "tracking-verified": (title) => title.toLowerCase().includes("tracking"),
    "campaign-approved": (title) => title.toLowerCase().includes("approval"),
    "campaign-live": (title) => title.toLowerCase().includes("campaign live"),
    "first-valid-event": (title) => title.toLowerCase().includes("valid event"),
  };
  const criteria = PAID_ADS_ACTIVATION.criteria.map((criterion) => {
    const requirement = onboarding.requirements.find((item) => criterionMatchers[criterion.id]?.(item.title));
    return { ...criterion, satisfied: Boolean(requirement?.verified && requirement.status === "SATISFIED"), evidence: requirement?.verified ? `verified:${requirement.id}` : null };
  });
  return { definition: PAID_ADS_ACTIVATION, criteria, ready: criteria.every((criterion) => !criterion.required || criterion.satisfied), missingCriteria: criteria.filter((criterion) => criterion.required && !criterion.satisfied).map((criterion) => criterion.description) };
}

export function promiseGraph(onboardingId: string): PromiseNode[] {
  return [{ id: `${onboardingId}:promise:1`, statement: "Launch paid acquisition in 14 days", outcome: "Campaign live with first qualified event", dependencies: ["Google Ads access", "Billing", "Tracking", "Landing page", "Creative", "Approval"], activationEvidence: ["OAUTH", "API_RECORD", "APPROVAL", "WEBHOOK"] }];
}

export function scopeComparison(request: string): { requested: string; matched: ScopeItem[]; inScope: boolean; recommendedAction: "CONTINUE" | "CHANGE_ORDER" } {
  const normalized = request.toLowerCase();
  const inScope = !normalized.includes("additional landing page") && !normalized.includes("extra landing page") && !normalized.includes("new service");
  return { requested: request, matched: [{ id: "scope_1", description: "Google Ads campaign setup and optimization", source: "CONTRACT", included: true, confidence: 0.96 }, { id: "scope_2", description: request, source: "CUSTOMER_REQUEST", included: inScope, confidence: 0.82 }], inScope, recommendedAction: inScope ? "CONTINUE" : "CHANGE_ORDER" };
}

export function communicationDecision(channel: Channel, consentGranted: boolean, localHour = new Date().getHours()) {
  const policy = { EMAIL: { allowed: true, consentRequired: false }, SMS: { allowed: true, consentRequired: true }, WHATSAPP: { allowed: true, consentRequired: true }, IN_APP: { allowed: true, consentRequired: false }, SLACK: { allowed: true, consentRequired: false }, TEAMS: { allowed: false, consentRequired: false } }[channel];
  const quietHours = localHour >= 21 || localHour < 8;
  const allowed = policy.allowed && (!policy.consentRequired || consentGranted) && !quietHours;
  return { channel, allowed, reason: !policy.allowed ? "CHANNEL_DISABLED" : policy.consentRequired && !consentGranted ? "CONSENT_REQUIRED" : quietHours ? "QUIET_HOURS" : "ELIGIBLE", nextEligibleAt: quietHours ? "08:00 local time" : null };
}

export function escalationPlan(policyId: string, elapsedHours: number) {
  const policy = SLA_POLICIES.find((item) => item.id === policyId) ?? SLA_POLICIES[0];
  const reached = policy.escalationHours.filter((hour) => elapsedHours >= hour);
  return { policy, elapsedHours, breached: elapsedHours > policy.targetHours, nextEscalationAt: policy.escalationHours.find((hour) => elapsedHours < hour) ?? null, reachedSteps: reached.length };
}

export function createHandoff(onboardingId: string) {
  const onboarding = onboardings.find((item) => item.id === onboardingId);
  if (!onboarding) return null;
  const event = createEvent({ event_type: "handoff.created", organization_id: "demo-organization", aggregate_type: "onboarding", aggregate_id: onboardingId, correlation_id: randomUUID(), idempotency_key: `handoff.${onboardingId}.v1`, actor: { type: "agent", id: "activation-handoff" }, payload: { goals: [onboarding.package], scope: promiseGraph(onboardingId), openRequirements: onboarding.requirements.filter((item) => item.status !== "SATISFIED").map((item) => item.title), risk: calculateHealth(onboardingId), activation: activationReadiness(onboardingId) } });
  return { handoffId: `handoff_${randomUUID()}`, onboardingId, status: "DRAFT", goals: [onboarding.package], scope: promiseGraph(onboardingId), openIssues: onboarding.requirements.filter((item) => item.status !== "SATISFIED").map((item) => item.title), event, outbox: registerOutbox({ organizationId: "demo-organization", eventId: event.event_id }) };
}
