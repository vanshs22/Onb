import { createHmac, timingSafeEqual } from "node:crypto";
import type { Queryable, Row } from "@/lib/server/sql";

// ───── timezone-aware quiet hours ─────
export function localHour(date: Date, timeZone: string): number {
  const hour = new Intl.DateTimeFormat("en-US", { hour: "numeric", hourCycle: "h23", timeZone }).formatToParts(date).find((part) => part.type === "hour")?.value ?? "0";
  return Number(hour) % 24;
}
export function isQuietHour(date: Date, timeZone: string, startHour = 21, endHour = 8) {
  const hour = localHour(date, timeZone);
  return hour >= startHour || hour < endHour;
}
export function nextAllowedTime(date: Date, timeZone: string, startHour = 21, endHour = 8): Date {
  let cursor = new Date(date);
  for (let i = 0; i < 48 * 4 && isQuietHour(cursor, timeZone, startHour, endHour); i += 1) cursor = new Date(cursor.getTime() + 15 * 60_000);
  return cursor;
}

// ───── follow-up planning ─────
export interface PlannedJob { kind: "reminder" | "escalate"; runAt: Date; idempotencyKey: string; payload: Record<string, unknown> }
export function planFollowUps(input: { requirementId: string; onboardingId: string; contactId: string; startedAt: Date; timezone: string; consentedChannels: string[] }): PlannedJob[] {
  const second = input.consentedChannels.includes("SMS") ? "SMS" : input.consentedChannels.includes("WHATSAPP") ? "WHATSAPP" : "EMAIL";
  const steps: { step: number; afterHours: number; kind: PlannedJob["kind"]; channel: string }[] = [
    { step: 1, afterHours: 24, kind: "reminder", channel: "EMAIL" },
    { step: 2, afterHours: 48, kind: "reminder", channel: second },
    { step: 3, afterHours: 72, kind: "escalate", channel: "INTERNAL" },
  ];
  return steps.map(({ step, afterHours, kind, channel }) => {
    const due = new Date(input.startedAt.getTime() + afterHours * 3_600_000);
    return { kind, runAt: kind === "reminder" ? nextAllowedTime(due, input.timezone) : due, idempotencyKey: `followup:${input.requirementId}:${step}`, payload: { requirementId: input.requirementId, onboardingId: input.onboardingId, contactId: input.contactId, channel, step, timezone: input.timezone } };
  });
}
export async function enqueueFollowUps(db: Queryable, organizationId: string, jobs: PlannedJob[]) {
  for (const job of jobs) {
    await db.query("insert into scheduled_jobs (organization_id, kind, run_at, payload, idempotency_key) values ($1,$2,$3,$4::jsonb,$5) on conflict (organization_id, idempotency_key) do nothing", [organizationId, job.kind, job.runAt.toISOString(), JSON.stringify(job.payload), job.idempotencyKey]);
  }
}

// ───── worker ─────
export interface MessageSender { send(input: { channel: string; to: { email?: string; phone?: string }; subject: string; body: string; idempotencyKey: string; unsubscribeUrl: string }): Promise<{ providerMessageId: string }> }
export interface WorkerOptions { secret: string; appUrl: string; now?: Date; limit?: number }

export async function processDueJobs(db: Queryable, sender: MessageSender, options: WorkerOptions) {
  const now = options.now ?? new Date();
  const claimed = (await db.query("select * from app.claim_due_jobs($1)", [options.limit ?? 10])).rows;
  const results: { key: string; outcome: string }[] = [];
  for (const job of claimed) {
    const key = job.idempotency_key as string;
    try {
      const outcome = await handleJob(db, sender, job, options, now);
      if (outcome.reschedule) await db.query("update scheduled_jobs set status='PENDING', run_at=$2, attempts=greatest(attempts-1,0), locked_until=null where id=$1", [job.id, outcome.reschedule.toISOString()]);
      else await db.query("select app.complete_job($1, $2::jsonb)", [job.id, JSON.stringify({ outcome: outcome.outcome })]);
      results.push({ key, outcome: outcome.outcome });
    } catch (error) {
      await db.query("select app.fail_job($1,$2)", [job.id, error instanceof Error ? error.message : String(error)]);
      results.push({ key, outcome: "RETRY_SCHEDULED" });
    }
  }
  return results;
}

async function handleJob(db: Queryable, sender: MessageSender, job: Row, options: WorkerOptions, now: Date): Promise<{ outcome: string; reschedule?: Date }> {
  const p = job.payload as { requirementId: string; onboardingId: string; contactId: string; channel: string; step: number; timezone: string };
  const org = job.organization_id as string;
  const requirement = (await db.query("select title, description, status from requirements where id=$1", [p.requirementId])).rows[0];
  if (!requirement || requirement.status === "SATISFIED" || requirement.status === "WAIVED") return { outcome: "SKIPPED_REQUIREMENT_DONE" };

  if (job.kind === "escalate") {
    await db.query("insert into exceptions (organization_id, onboarding_id, title, severity, impact, recommendation) values ($1,$2,$3,'HIGH',$4,$5)", [org, p.onboardingId, `Customer unresponsive: ${requirement.title}`, "No customer action after automated reminders; activation is at risk.", "Account manager should contact the customer directly."]);
    return { outcome: "ESCALATED" };
  }
  if (isQuietHour(now, p.timezone)) return { outcome: "RESCHEDULED_QUIET_HOURS", reschedule: nextAllowedTime(now, p.timezone) };

  const body = `We're ready to keep your onboarding moving. The only thing still needed is: ${requirement.title}. ${requirement.description ?? ""}`.trim();
  const allowed = (await db.query("select app.can_contact($1,$2) as ok", [p.contactId, p.channel])).rows[0].ok === true;
  if (!allowed) {
    await db.query("insert into messages (organization_id, onboarding_id, contact_id, direction, channel, status, body, idempotency_key) values ($1,$2,$3,'OUTBOUND',$4,'SUPPRESSED',$5,$6) on conflict (organization_id, idempotency_key) where idempotency_key is not null do nothing", [org, p.onboardingId, p.contactId, p.channel, body, `${job.idempotency_key}:suppressed`]);
    return { outcome: "SUPPRESSED_NO_CONSENT_OR_OPTED_OUT" };
  }

  const message = (await db.query(
    "insert into messages (organization_id, onboarding_id, contact_id, direction, channel, status, body, idempotency_key) values ($1,$2,$3,'OUTBOUND',$4,'QUEUED',$5,$6) on conflict (organization_id, idempotency_key) where idempotency_key is not null do update set status='QUEUED' where messages.status='FAILED' returning id",
    [org, p.onboardingId, p.contactId, p.channel, body, job.idempotency_key],
  )).rows[0];
  if (!message) return { outcome: "ALREADY_SENT" };

  const contact = (await db.query("select email, phone from customer_contacts where id=$1", [p.contactId])).rows[0];
  try {
    const sent = await sender.send({ channel: p.channel, to: { email: contact?.email as string | undefined, phone: contact?.phone as string | undefined }, subject: `Next step: ${requirement.title}`, body, idempotencyKey: job.idempotency_key as string, unsubscribeUrl: `${options.appUrl}/api/v1/unsubscribe?token=${createUnsubscribeToken({ contactId: p.contactId, channel: p.channel, organizationId: org }, options.secret)}` });
    await db.query("update messages set status='SENT', provider_message_id=$2, sent_at=now() where id=$1", [message.id, sent.providerMessageId]);
    return { outcome: "SENT" };
  } catch (error) {
    await db.query("update messages set status='FAILED' where id=$1", [message.id]);
    throw error;
  }
}

// ───── unsubscribe links & SMS keywords ─────
export interface UnsubscribePayload { contactId: string; channel: string; organizationId: string }
const b64 = (value: string) => Buffer.from(value).toString("base64url");
export function createUnsubscribeToken(payload: UnsubscribePayload, secret: string) {
  const body = b64(JSON.stringify(payload));
  return `${body}.${createHmac("sha256", secret).update(body).digest("base64url")}`;
}
export function verifyUnsubscribeToken(token: string, secret: string): UnsubscribePayload | null {
  const [body, signature] = token.split(".");
  if (!body || !signature) return null;
  const expected = createHmac("sha256", secret).update(body).digest("base64url");
  if (expected.length !== signature.length || !timingSafeEqual(Buffer.from(expected), Buffer.from(signature))) return null;
  try { return JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as UnsubscribePayload; } catch { return null; }
}
export async function revokeConsent(db: Queryable, payload: UnsubscribePayload, source: string) {
  await db.query("insert into channel_consents (organization_id, contact_id, channel, status, source, revoked_at) values ($1,$2,$3,'REVOKED',$4, now()) on conflict (contact_id, channel, purpose) do update set status='REVOKED', source=excluded.source, revoked_at=now()", [payload.organizationId, payload.contactId, payload.channel, source]);
}
/** Carrier-standard keywords: the entire message must match. */
export function parseOptKeyword(text: string): "OPT_OUT" | "OPT_IN" | "HELP" | null {
  const word = text.trim().toUpperCase();
  if (["STOP", "STOPALL", "UNSUBSCRIBE", "CANCEL", "END", "QUIT"].includes(word)) return "OPT_OUT";
  if (["START", "UNSTOP", "YES"].includes(word)) return "OPT_IN";
  return word === "HELP" ? "HELP" : null;
}
