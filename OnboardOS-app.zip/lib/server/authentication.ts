import { createRemoteJWKSet, jwtVerify, type JWTPayload } from "jose";
import { db } from "@/lib/server/db";
import { demoOperatorContext, type ActorContext, type WorkspaceRole } from "@/lib/server/authorization";
import { ConfigurationError, runtimeConfig } from "@/lib/server/config";
import type { Queryable } from "@/lib/server/sql";

export type AuthErrorCode = "AUTHENTICATION_REQUIRED" | "FORBIDDEN" | "NO_ORGANIZATION" | "ORGANIZATION_REQUIRED";
export class AuthenticationError extends Error {
  constructor(public code: AuthErrorCode, message: string, public details: Record<string, unknown> = {}) { super(message); this.name = code; }
}

const WORKSPACE_ROLES = new Set<string>(["OWNER", "ADMIN", "OPERATOR", "MEMBER", "VIEWER", "CUSTOMER_CONTACT"]);
const encode = (secret: string) => new TextEncoder().encode(secret);
const jwksByUrl = new Map<string, ReturnType<typeof createRemoteJWKSet>>();
const supabaseConfigured = () => Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL);

/** Accepts (1) tokens we issue, signed with AUTH_SECRET, and (2) Supabase Auth tokens (HS256 secret or asymmetric JWKS). */
export async function verifyAccessToken(token: string): Promise<JWTPayload> {
  const attempts: (() => Promise<JWTPayload>)[] = [async () => (await jwtVerify(token, encode(runtimeConfig().authSecret), { algorithms: ["HS256"] })).payload];
  const supabaseSecret = process.env.SUPABASE_JWT_SECRET;
  if (supabaseSecret) attempts.push(async () => (await jwtVerify(token, encode(supabaseSecret), { algorithms: ["HS256"], audience: "authenticated" })).payload);
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  if (url) attempts.push(async () => {
    const jwks = jwksByUrl.get(url) ?? createRemoteJWKSet(new URL(`${url}/auth/v1/.well-known/jwks.json`));
    jwksByUrl.set(url, jwks);
    return (await jwtVerify(token, jwks, { algorithms: ["ES256", "RS256"], audience: "authenticated" })).payload;
  });
  for (const attempt of attempts) {
    try { return await attempt(); } catch { continue; }
  }
  throw new AuthenticationError("AUTHENTICATION_REQUIRED", "The bearer token is invalid or expired.");
}

export interface Identity { userId: string; claims: JWTPayload; demo: boolean }
export async function identify(request: Request): Promise<Identity> {
  const config = runtimeConfig();
  const demoAllowed = config.demoMode && !supabaseConfigured();
  const header = request.headers.get("authorization");
  if (!header) {
    if (demoAllowed) return { userId: demoOperatorContext().actorId, claims: {}, demo: true };
    throw new AuthenticationError("AUTHENTICATION_REQUIRED", "A bearer token is required.");
  }
  const [scheme, token] = header.split(" ");
  if (scheme !== "Bearer" || !token) throw new AuthenticationError("AUTHENTICATION_REQUIRED", "Use the Bearer authentication scheme.");
  if (demoAllowed && token === "demo") return { userId: demoOperatorContext().actorId, claims: {}, demo: true };
  const claims = await verifyAccessToken(token);
  if (typeof claims.sub !== "string") throw new AuthenticationError("AUTHENTICATION_REQUIRED", "The token has no subject.");
  return { userId: claims.sub, claims, demo: false };
}

export interface MembershipSummary { organizationId: string; name: string; slug: string; role: WorkspaceRole }
export async function listMemberships(q: Queryable, userId: string): Promise<MembershipSummary[]> {
  const rows = (await q.query("select m.organization_id, o.name, o.slug, m.role from memberships m join organizations o on o.id = m.organization_id where m.user_id = $1 and m.status = 'ACTIVE' order by o.name", [userId])).rows;
  return rows.map((r) => ({ organizationId: r.organization_id as string, name: r.name as string, slug: r.slug as string, role: r.role as WorkspaceRole }));
}

/** Users may belong to several organizations: one is chosen explicitly via x-organization-id, never guessed. */
export async function resolveMembership(q: Queryable, userId: string, requestedOrg: string | null) {
  const memberships = await listMemberships(q, userId);
  if (memberships.length === 0) throw new AuthenticationError("NO_ORGANIZATION", "This account does not belong to a workspace yet.");
  if (requestedOrg) {
    const match = memberships.find((m) => m.organizationId === requestedOrg);
    if (!match) throw new AuthenticationError("FORBIDDEN", "You are not a member of that workspace.");
    return { organizationId: match.organizationId, role: match.role };
  }
  if (memberships.length > 1) throw new AuthenticationError("ORGANIZATION_REQUIRED", "Choose a workspace with the x-organization-id header.", { organizations: memberships.map((m) => ({ id: m.organizationId, name: m.name })) });
  return { organizationId: memberships[0].organizationId, role: memberships[0].role };
}

export async function authenticateRequest(request: Request, lookup?: Queryable): Promise<ActorContext> {
  const identity = await identify(request);
  if (identity.demo) return demoOperatorContext();
  const claimedOrg = typeof identity.claims.organization_id === "string" ? identity.claims.organization_id : null;
  const claimedRole = typeof identity.claims.role === "string" && WORKSPACE_ROLES.has(identity.claims.role) ? (identity.claims.role as WorkspaceRole) : null;
  if (claimedOrg && claimedRole) return { actorId: identity.userId, organizationId: claimedOrg, role: claimedRole };
  const q = lookup ?? (db as unknown as Queryable | null);
  if (!q) throw new ConfigurationError("Database is not configured.");
  const membership = await resolveMembership(q, identity.userId, request.headers.get("x-organization-id"));
  return { actorId: identity.userId, ...membership };
}
