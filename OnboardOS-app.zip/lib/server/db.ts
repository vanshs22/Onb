import { Pool } from "pg";

declare global {
  var onboardosPool: Pool | undefined;
}

const connectionString = process.env.DATABASE_URL;
export const db = connectionString ? globalThis.onboardosPool ?? new Pool({ connectionString, max: Number(process.env.DATABASE_POOL_MAX ?? 10), idleTimeoutMillis: 30000, connectionTimeoutMillis: 5000, ssl: process.env.DATABASE_SSL === "require" ? { rejectUnauthorized: true } : undefined }) : null;
if (db && process.env.NODE_ENV !== "production") globalThis.onboardosPool = db;
