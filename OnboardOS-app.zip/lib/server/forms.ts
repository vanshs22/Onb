export type FieldType = "text" | "textarea" | "email" | "phone" | "url" | "number" | "select" | "multiselect" | "checkbox" | "date" | "file" | "oauth";
export interface Condition { field: string; op: "eq" | "neq" | "in" | "gt" | "lt" | "truthy"; value?: unknown }
export interface FieldDef { id: string; type: FieldType; label: string; required?: boolean; options?: string[]; min?: number; max?: number; maxLength?: number; visibleIf?: Condition; mapsToRequirement?: string }
export interface FormSchema { fields: FieldDef[] }
export interface FieldError { field: string; code: string; message: string }

const EMAIL = /^[^\s@]{1,64}@[^\s@]+\.[^\s@]{2,}$/;
const PHONE = /^\+?[0-9 ()-]{7,20}$/;

export function evaluate(condition: Condition | undefined, answers: Record<string, unknown>): boolean {
  if (!condition) return true;
  const v = answers[condition.field];
  switch (condition.op) {
    case "eq": return v === condition.value;
    case "neq": return v !== condition.value;
    case "in": return Array.isArray(condition.value) && condition.value.includes(v);
    case "gt": return typeof v === "number" && typeof condition.value === "number" && v > condition.value;
    case "lt": return typeof v === "number" && typeof condition.value === "number" && v < condition.value;
    case "truthy": return Boolean(v) && !(Array.isArray(v) && v.length === 0);
  }
}

/** Server-side validation: hidden fields are ignored (and stripped), unknown fields are rejected, requirements are mapped. */
export function validateForm(schema: FormSchema, raw: Record<string, unknown>) {
  const errors: FieldError[] = [];
  const known = new Set(schema.fields.map((f) => f.id));
  for (const key of Object.keys(raw)) if (!known.has(key)) errors.push({ field: key, code: "UNKNOWN_FIELD", message: "This field is not part of the form." });

  const visible = schema.fields.filter((f) => evaluate(f.visibleIf, raw));
  const answers: Record<string, unknown> = {};
  for (const f of visible) {
    let value = raw[f.id];
    if (typeof value === "string") value = value.trim();
    const empty = value === undefined || value === null || value === "" || (Array.isArray(value) && value.length === 0);
    if (empty) { if (f.required) errors.push({ field: f.id, code: "REQUIRED", message: `${f.label} is required.` }); continue; }
    const bad = (code: string, message: string) => errors.push({ field: f.id, code, message });
    switch (f.type) {
      case "email": if (typeof value !== "string" || !EMAIL.test(value)) bad("INVALID_EMAIL", "Enter a valid email address."); break;
      case "phone": if (typeof value !== "string" || !PHONE.test(value)) bad("INVALID_PHONE", "Enter a valid phone number."); break;
      case "url": try { const u = new URL(String(value)); if (!["http:", "https:"].includes(u.protocol)) throw new Error(); } catch { bad("INVALID_URL", "Enter a valid http(s) URL."); } break;
      case "number": if (typeof value !== "number" || !Number.isFinite(value)) bad("INVALID_NUMBER", "Enter a number."); else if ((f.min !== undefined && value < f.min) || (f.max !== undefined && value > f.max)) bad("OUT_OF_RANGE", `Must be between ${f.min ?? "−∞"} and ${f.max ?? "∞"}.`); break;
      case "select": if (typeof value !== "string" || !f.options?.includes(value)) bad("INVALID_OPTION", "Choose one of the listed options."); break;
      case "multiselect": if (!Array.isArray(value) || value.some((x) => !f.options?.includes(String(x)))) bad("INVALID_OPTION", "Choose only listed options."); break;
      case "checkbox": if (typeof value !== "boolean") bad("INVALID_BOOLEAN", "Must be true or false."); break;
      case "date": if (typeof value !== "string" || Number.isNaN(Date.parse(value))) bad("INVALID_DATE", "Enter a valid date."); break;
      default: if (typeof value !== "string" && typeof value !== "object") bad("INVALID_VALUE", "Invalid value.");
    }
    if (typeof value === "string" && value.length > (f.maxLength ?? 5000)) bad("TOO_LONG", `Must be at most ${f.maxLength ?? 5000} characters.`);
    answers[f.id] = value;
  }
  const satisfiedRequirements = schema.fields.filter((f) => f.mapsToRequirement && f.id in answers && !errors.some((e) => e.field === f.id)).map((f) => f.mapsToRequirement as string);
  return { valid: errors.length === 0, errors, answers, visibleFields: visible.map((f) => f.id), satisfiedRequirements };
}

/** Turns a free-text intake answer into structured goals and the requirements it implies. */
export function extractIntake(text: string) {
  const t = text.toLowerCase();
  const pick = <T extends string>(table: Record<string, T>) => Object.entries(table).find(([k]) => t.includes(k))?.[1];
  const goal = pick({ "leads": "Lead generation", "lead gen": "Lead generation", "traffic": "Traffic growth", "sales": "Sales growth", "ecommerce": "E-commerce growth", "brand": "Brand awareness" });
  const industry = pick({ roofing: "Roofing", dental: "Dental", legal: "Legal", fitness: "Fitness", hvac: "HVAC", plumbing: "Plumbing", "real estate": "Real estate", saas: "SaaS" });
  const crm = pick({ hubspot: "HubSpot", salesforce: "Salesforce", pipedrive: "Pipedrive", zoho: "Zoho" });
  const market = ["California", "Texas", "Florida", "New York", "London", "Toronto", "Sydney"].find((m) => t.includes(m.toLowerCase()));
  const requirements = new Set<string>();
  if (goal === "Lead generation") ["Google Ads access", "Landing page", "Call tracking", "Tracking validation"].forEach((r) => requirements.add(r));
  if (goal === "Traffic growth") ["Google Search Console access", "Analytics access"].forEach((r) => requirements.add(r));
  if (crm) requirements.add(`${crm} sync`);
  return { goal, industry, market, crm, requirements: [...requirements] };
}
