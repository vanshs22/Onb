import { randomUUID } from "node:crypto";
import { NATIVE_CAPABILITIES } from "@/lib/native-capabilities";

export function nativeCapability(id: string) {
  const capability = NATIVE_CAPABILITIES.find((item) => item.id === id);
  if (!capability) return null;
  return { ...capability, execution: "native", executionId: `native_${randomUUID()}`, auditRequired: true, tenantScoped: true };
}

export function runNativeCapability(id: string, input: Record<string, unknown> = {}) {
  const capability = nativeCapability(id);
  if (!capability) return null;
  return { capability, inputAccepted: input, status: "READY", result: { nativeExecution: true, externalProviderRequired: false, fallbackAvailable: capability.externalFallbacks.length > 0, next: capability.features[0] } };
}
