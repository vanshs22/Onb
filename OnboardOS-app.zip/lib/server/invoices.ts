export class InvoiceError extends Error {}
export interface LineInput { description: string; quantity: number; unitPriceCents: number; taxRateBps?: number }
export type Discount = { type: "PERCENT_BPS" | "FIXED_CENTS"; value: number };

const sum = (values: number[]) => values.reduce((a, b) => a + b, 0);

/** Integer-cent invoice math. The discount is allocated across lines by largest remainder so totals never drift. */
export function computeInvoice(lines: LineInput[], discount?: Discount) {
  if (!lines.length || lines.length > 100) throw new InvoiceError("An invoice needs 1–100 line items.");
  for (const l of lines) {
    if (!l.description?.trim()) throw new InvoiceError("Each line needs a description.");
    if (!Number.isFinite(l.quantity) || l.quantity <= 0) throw new InvoiceError("Quantity must be greater than zero.");
    if (!Number.isInteger(l.unitPriceCents) || l.unitPriceCents < 0) throw new InvoiceError("Unit price must be a non-negative integer number of cents.");
    const bps = l.taxRateBps ?? 0;
    if (!Number.isInteger(bps) || bps < 0 || bps > 10000) throw new InvoiceError("Tax rate must be 0–10000 basis points.");
  }
  const base = lines.map((l) => Math.round(l.quantity * l.unitPriceCents));
  const subtotal = sum(base);
  if (discount && (!Number.isInteger(discount.value) || discount.value < 0 || (discount.type === "PERCENT_BPS" && discount.value > 10000))) throw new InvoiceError("Invalid discount.");
  const discountTotal = !discount ? 0 : discount.type === "PERCENT_BPS" ? Math.round((subtotal * discount.value) / 10000) : discount.value;
  if (discountTotal > subtotal) throw new InvoiceError("Discount cannot exceed the subtotal.");

  const exact = base.map((b) => (subtotal === 0 ? 0 : (b * discountTotal) / subtotal));
  const allocated = exact.map(Math.floor);
  let remainder = discountTotal - sum(allocated);
  [...exact.keys()].sort((a, b) => (exact[b] - allocated[b]) - (exact[a] - allocated[a])).forEach((index) => { if (remainder > 0) { allocated[index] += 1; remainder -= 1; } });

  const items = lines.map((l, i) => {
    const net = base[i] - allocated[i];
    const taxCents = Math.round((net * (l.taxRateBps ?? 0)) / 10000);
    return { ...l, subtotalCents: base[i], discountCents: allocated[i], taxCents, totalCents: net + taxCents };
  });
  const taxCents = sum(items.map((i) => i.taxCents));
  return { items, subtotalCents: subtotal, discountCents: discountTotal, taxCents, totalCents: subtotal - discountTotal + taxCents };
}

export const invoiceNumber = (year: number, sequence: number) => `INV-${year}-${String(sequence).padStart(6, "0")}`;

/** Payment reminders relative to the due date; SMS only when the contact has consented. */
export function planDunning(dueAt: Date, smsConsented = false) {
  const at = (days: number) => new Date(dueAt.getTime() + days * 86_400_000);
  return [
    { step: "UPCOMING", runAt: at(-3), channel: "EMAIL", tone: "friendly" },
    { step: "DUE", runAt: at(0), channel: "EMAIL", tone: "neutral" },
    { step: "OVERDUE_1", runAt: at(3), channel: "EMAIL", tone: "firm" },
    { step: "OVERDUE_2", runAt: at(7), channel: smsConsented ? "SMS" : "EMAIL", tone: "firm" },
    { step: "ESCALATE", runAt: at(14), channel: "INTERNAL", tone: "escalation" },
  ];
}
