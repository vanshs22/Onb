import type { Pool } from "pg";

export type Row = Record<string, unknown>;
export interface Queryable { query(sql: string, params?: unknown[]): Promise<{ rows: Row[] }> }

async function inTransaction<T>(pool: Pool, prepare: (client: Queryable) => Promise<void>, fn: (tx: Queryable) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  const tx = client as unknown as Queryable;
  try {
    await client.query("begin");
    await prepare(tx);
    const result = await fn(tx);
    await client.query("commit");
    return result;
  } catch (error) {
    await client.query("rollback").catch(() => undefined);
    throw error;
  } finally {
    client.release();
  }
}

/** Runs fn in one transaction as the signed-in user, so Postgres RLS (not just app code) enforces tenant isolation. */
export function withTenantTransaction<T>(pool: Pool, userId: string, fn: (tx: Queryable) => Promise<T>): Promise<T> {
  return inTransaction(pool, async (tx) => {
    await tx.query("select set_config('request.jwt.claims', $1, true), set_config('request.jwt.claim.sub', $2, true)", [JSON.stringify({ sub: userId, role: "authenticated" }), userId]);
    await tx.query("set local role authenticated");
  }, fn);
}

/** Service-level transaction for trusted backend work (webhooks, verification). Every statement must still filter by organization_id. */
export function withServiceTransaction<T>(pool: Pool, fn: (tx: Queryable) => Promise<T>): Promise<T> {
  return inTransaction(pool, async () => undefined, fn);
}
