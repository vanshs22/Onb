import type { Channel } from "@/lib/product-contracts";

type ChannelPreference = { channel: Channel; purpose: string; consent: "GRANTED" | "NOT_GRANTED"; optedOut: boolean; source: string; updatedAt: string };
const preferences = new Map<string, ChannelPreference[]>();
const channels: Channel[] = ["EMAIL", "SMS", "WHATSAPP", "IN_APP"];

function defaults(contactId: string) {
  return preferences.get(contactId) ?? channels.map((channel) => ({ channel, purpose: "ONBOARDING_COMMUNICATION", consent: channel === "EMAIL" || channel === "IN_APP" ? "GRANTED" : "NOT_GRANTED", optedOut: false, source: "demo_default", updatedAt: new Date().toISOString() }));
}

export function getCommunicationPreferences(contactId: string) {
  const result = defaults(contactId);
  preferences.set(contactId, result);
  return result;
}

export function setOptOut(contactId: string, channel: Channel | "ALL", source = "customer_request") {
  const current = getCommunicationPreferences(contactId);
  const updated = current.map((preference) => channel === "ALL" || preference.channel === channel ? { ...preference, optedOut: true, consent: "NOT_GRANTED" as const, source, updatedAt: new Date().toISOString() } : preference);
  preferences.set(contactId, updated);
  return updated;
}

export function canSend(contactId: string, channel: Channel) {
  const preference = getCommunicationPreferences(contactId).find((item) => item.channel === channel);
  return { allowed: Boolean(preference && preference.consent === "GRANTED" && !preference.optedOut), reason: !preference ? "CHANNEL_UNCONFIGURED" : preference.optedOut ? "OPTED_OUT" : preference.consent !== "GRANTED" ? "CONSENT_REQUIRED" : "ELIGIBLE" };
}
