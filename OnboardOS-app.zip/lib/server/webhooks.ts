import { createHash, createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { runtimeConfig } from "@/lib/server/config";

interface WebhookDelivery { id: string; provider: string; providerEventId: string; signatureValid: boolean; payloadHash: string; status: "RECEIVED" | "PROCESSED" | "DUPLICATE" | "FAILED"; receivedAt: string; }
const deliveries = new Map<string, WebhookDelivery>();

function secretFor(provider: string) {
  const key = `${provider.toUpperCase().replace(/[^A-Z0-9]/g, "_")}_WEBHOOK_SECRET`;
  return process.env[key] ?? (provider.toLowerCase() === "stripe" ? process.env.STRIPE_WEBHOOK_SECRET : undefined) ?? (runtimeConfig().demoMode ? "demo-webhook-secret" : undefined);
}

export function verifyWebhookSignature(provider: string, rawBody: string, signature: string) {
  const secret = secretFor(provider);
  if (!secret || !signature) return false;
  const expected = createHmac("sha256", secret).update(rawBody).digest("hex");
  const supplied = signature.replace(/^sha256=/, "");
  if (expected.length !== supplied.length) return false;
  return timingSafeEqual(Buffer.from(expected, "utf8"), Buffer.from(supplied, "utf8"));
}

export function receiveWebhook(input: { provider: string; providerEventId: string; signature: string; rawBody: string; payload: unknown }) {
  const key = `${input.provider}:${input.providerEventId}`;
  const payloadHash = createHash("sha256").update(input.rawBody).digest("hex");
  const existing = deliveries.get(key);
  if (existing) return { ...existing, status: "DUPLICATE" as const, replayOf: existing.id };
  const signatureValid = verifyWebhookSignature(input.provider, input.rawBody, input.signature);
  const record: WebhookDelivery = { id: `wh_${randomUUID()}`, provider: input.provider, providerEventId: input.providerEventId, signatureValid, payloadHash, status: signatureValid ? "PROCESSED" : "FAILED", receivedAt: new Date().toISOString() };
  deliveries.set(key, record);
  return record;
}
