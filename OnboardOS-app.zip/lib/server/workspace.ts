import { randomUUID } from "node:crypto";
import { createEvent } from "@/lib/api";
import { onboardings } from "@/lib/demo-data";
import { registerOutbox } from "@/lib/server/outbox";

const submissions = new Map<string, unknown>();

export function customerWorkspaceProjection(onboardingId: string) {
  const onboarding = onboardings.find((item) => item.id === onboardingId);
  if (!onboarding) return null;
  const visibleRequirements = onboarding.requirements.filter((requirement) => requirement.clientVisible);
  const next = visibleRequirements.find((requirement) => requirement.status !== "SATISFIED");
  return {
    id: onboarding.id,
    customer: onboarding.customer,
    package: onboarding.package,
    progress: onboarding.progress,
    state: onboarding.state,
    nextAction: next ? { id: next.id, title: next.title, description: next.description, due: next.due } : null,
    requirements: visibleRequirements.map(({ id, title, status, due, clientVisible }) => ({ id, title, status, due, clientVisible })),
    timeline: ["Agreement", "Payment", "Questionnaire", "Brand assets", "Google Ads access", "Kickoff"].map((title, index) => ({ title, status: index < 4 ? "COMPLETED" : index === 4 ? "CURRENT" : "UPCOMING" })),
  };
}

export function submitForm(input: { organizationId: string; onboardingId: string; formId: string; answers: Record<string, unknown>; idempotencyKey: string; actorId: string }) {
  const onboarding = onboardings.find((item) => item.id === input.onboardingId);
  if (!onboarding) throw new Error("NOT_FOUND");
  const key = `${input.organizationId}:${input.idempotencyKey}`;
  if (submissions.has(key)) return submissions.get(key);
  const submission = { id: `submission_${randomUUID()}`, onboardingId: input.onboardingId, formId: input.formId, answers: input.answers, status: "SUBMITTED", createdAt: new Date().toISOString() };
  const event = createEvent({ event_type: "task.completed", organization_id: input.organizationId, aggregate_type: "onboarding", aggregate_id: input.onboardingId, correlation_id: input.idempotencyKey, idempotency_key: input.idempotencyKey, actor: { type: "customer_contact", id: input.actorId }, payload: { form_id: input.formId, submission_id: submission.id } });
  const result = { submission, event, outbox: registerOutbox({ organizationId: input.organizationId, eventId: event.event_id }) };
  submissions.set(key, result);
  return result;
}

export function quarantineDocument(input: { organizationId: string; onboardingId: string; name: string; mimeType: string; sizeBytes: number; actorId: string; idempotencyKey: string }) {
  const onboarding = onboardings.find((item) => item.id === input.onboardingId);
  if (!onboarding) throw new Error("NOT_FOUND");
  const objectKey = `${input.organizationId}/${input.onboardingId}/${randomUUID()}-${input.name.replace(/[^a-zA-Z0-9._-]/g, "-")}`;
  const document = { id: `document_${randomUUID()}`, onboardingId: input.onboardingId, name: input.name, mimeType: input.mimeType, sizeBytes: input.sizeBytes, objectKey, status: "QUARANTINED", scanRequired: true, createdAt: new Date().toISOString() };
  const event = createEvent({ event_type: "evidence.created", organization_id: input.organizationId, aggregate_type: "onboarding", aggregate_id: input.onboardingId, correlation_id: input.idempotencyKey, idempotency_key: input.idempotencyKey, actor: { type: "customer_contact", id: input.actorId }, payload: { document_id: document.id, status: document.status } });
  return { document, event, outbox: registerOutbox({ organizationId: input.organizationId, eventId: event.event_id }) };
}
