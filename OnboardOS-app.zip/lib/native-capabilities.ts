export type NativeCapabilityStatus = "AVAILABLE" | "ADAPTER_OPTIONAL";
export interface NativeCapability {
  id: string;
  name: string;
  category: "PORTAL" | "INTAKE" | "WORKFLOW" | "DELIVERY" | "COMMUNICATION" | "DOCUMENTS" | "COMMERCIAL" | "SCHEDULING" | "INTELLIGENCE" | "GOVERNANCE";
  status: NativeCapabilityStatus;
  features: string[];
  sourceOfTruth: "ONBOARDOS" | "PROVIDER_RAIL";
  externalFallbacks: string[];
}

export const NATIVE_CAPABILITIES: NativeCapability[] = [
  { id: "native.customer-workspace", name: "Customer workspace", category: "PORTAL", status: "AVAILABLE", features: ["branded home", "next action", "progress", "timeline", "messages", "support"], sourceOfTruth: "ONBOARDOS", externalFallbacks: ["dubsado", "bonsai", "rocketlane", "guidecx"] },
  { id: "native.form-builder", name: "Forms and intake builder", category: "INTAKE", status: "AVAILABLE", features: ["versioned schemas", "conditional fields", "save progress", "validation", "submission mapping"], sourceOfTruth: "ONBOARDOS", externalFallbacks: ["jotform", "dubsado", "bonsai"] },
  { id: "native.workflow-builder", name: "Workflow and playbook builder", category: "WORKFLOW", status: "AVAILABLE", features: ["explicit graph", "conditions", "waits", "retries", "approvals", "test run"], sourceOfTruth: "ONBOARDOS", externalFallbacks: ["rocketlane", "onramp", "guidecx", "dubsado"] },
  { id: "native.delivery-board", name: "Delivery project board", category: "DELIVERY", status: "AVAILABLE", features: ["stages", "tasks", "dependencies", "owners", "deadlines", "client visibility"], sourceOfTruth: "ONBOARDOS", externalFallbacks: ["rocketlane", "onramp", "guidecx", "bonsai"] },
  { id: "native.requirements", name: "Requirements and dependency engine", category: "WORKFLOW", status: "AVAILABLE", features: ["owners", "blocking impact", "evidence required", "dependency graph", "readiness"], sourceOfTruth: "ONBOARDOS", externalFallbacks: [] },
  { id: "native.evidence", name: "Evidence and verification", category: "GOVERNANCE", status: "AVAILABLE", features: ["evidence collection", "independent verification", "provider checks", "rejection reasons"], sourceOfTruth: "ONBOARDOS", externalFallbacks: [] },
  { id: "native.approvals", name: "Approval center", category: "GOVERNANCE", status: "AVAILABLE", features: ["customer approval", "internal approval", "request changes", "approval evidence"], sourceOfTruth: "ONBOARDOS", externalFallbacks: ["jotform", "rocketlane"] },
  { id: "native.document-center", name: "Document center", category: "DOCUMENTS", status: "AVAILABLE", features: ["secure upload", "quarantine", "scan gate", "extraction", "classification", "requirement mapping"], sourceOfTruth: "ONBOARDOS", externalFallbacks: ["jotform", "dubsado", "bonsai"] },
  { id: "native.communication", name: "Communication and chase center", category: "COMMUNICATION", status: "ADAPTER_OPTIONAL", features: ["threading", "templates", "consent", "quiet hours", "contextual chase", "escalation"], sourceOfTruth: "ONBOARDOS", externalFallbacks: ["google-workspace", "twilio", "whatsapp"] },
  { id: "native.health-exceptions", name: "Health and exception center", category: "INTELLIGENCE", status: "AVAILABLE", features: ["explainable score", "risk bands", "reasons", "SLA", "recovery", "reassignment"], sourceOfTruth: "ONBOARDOS", externalFallbacks: ["rocketlane", "onramp", "guidecx"] },
  { id: "native.analytics", name: "Activation and portfolio analytics", category: "INTELLIGENCE", status: "AVAILABLE", features: ["funnel", "time to activation", "bottlenecks", "revenue at risk", "learning loop"], sourceOfTruth: "ONBOARDOS", externalFallbacks: ["guidecx", "rocketlane"] },
  { id: "native.commercial-ux", name: "Commercial flow workspace", category: "COMMERCIAL", status: "ADAPTER_OPTIONAL", features: ["agreement templates", "payment requests", "receipts", "commercial gates", "change orders"], sourceOfTruth: "ONBOARDOS", externalFallbacks: ["stripe", "docusign", "pandadoc", "dubsado", "bonsai"] },
  { id: "native.scheduling", name: "Scheduling and availability workspace", category: "SCHEDULING", status: "ADAPTER_OPTIONAL", features: ["availability rules", "routing", "booking record", "reschedule", "calendar sync"], sourceOfTruth: "ONBOARDOS", externalFallbacks: ["calendly", "google-workspace", "dubsado"] },
  { id: "native.ai-concierge", name: "Grounded AI concierge", category: "INTELLIGENCE", status: "AVAILABLE", features: ["live onboarding state", "approved knowledge", "next action", "support answers", "no invented requirements"], sourceOfTruth: "ONBOARDOS", externalFallbacks: ["jotform", "onramp", "guidecx"] },
  { id: "native.activation", name: "Activation proof and certificate", category: "GOVERNANCE", status: "AVAILABLE", features: ["criteria", "first-value events", "independent verification", "certificate", "handoff"], sourceOfTruth: "ONBOARDOS", externalFallbacks: [] },
  { id: "native.crm-compiler", name: "Deal-to-delivery compiler", category: "INTELLIGENCE", status: "ADAPTER_OPTIONAL", features: ["CRM import", "proposal/contract context", "promise extraction", "scope mismatch", "delivery brief"], sourceOfTruth: "ONBOARDOS", externalFallbacks: ["hubspot", "salesforce", "pipedrive", "bonsai"] },
  { id: "native.mcp", name: "Controlled MCP surface", category: "GOVERNANCE", status: "AVAILABLE", features: ["read tools", "action tools", "approval gates", "tenant scope", "audit"], sourceOfTruth: "ONBOARDOS", externalFallbacks: ["guidecx"] },
];
