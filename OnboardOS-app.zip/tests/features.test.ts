import { describe, expect, it } from "vitest";
import { BLUEPRINT_50_127 } from "@/lib/feature-catalog";
import { runFeature } from "@/lib/server/feature-runtime";

describe("blueprint coverage", () => {
  it("contains every requested feature from 50 through 127", () => {
    expect(BLUEPRINT_50_127).toHaveLength(78);
    expect(BLUEPRINT_50_127[0].id).toBe(50);
    expect(BLUEPRINT_50_127.at(-1)?.id).toBe(127);
  });

  it("executes a representative production and adapter-backed feature", () => {
    const activation = runFeature(57);
    const oauth = runFeature(86);
    expect(activation).not.toBeNull();
    expect(oauth).not.toBeNull();
    if (!activation || !oauth) throw new Error("feature runtime unavailable");
    expect(activation.result).toMatchObject({ featureId: 57, status: "EXECUTABLE_CONTRACT" });
    expect(oauth.result).toMatchObject({ featureId: 86, providerExecution: "requires configured provider adapter" });
  });
});
