import { describe, expect, it } from "vitest";
import { canSend, getCommunicationPreferences, setOptOut } from "@/lib/server/communication-preferences";

describe("communication consent and opt-out", () => {
  it("allows email by default but blocks unconsented SMS", () => {
    const contact = "contact-communication-test";
    expect(canSend(contact, "EMAIL").allowed).toBe(true);
    expect(canSend(contact, "SMS")).toMatchObject({ allowed: false, reason: "CONSENT_REQUIRED" });
  });

  it("blocks future messages immediately after opt-out", () => {
    const contact = "contact-optout-test";
    setOptOut(contact, "EMAIL");
    expect(canSend(contact, "EMAIL")).toMatchObject({ allowed: false, reason: "OPTED_OUT" });
    expect(getCommunicationPreferences(contact).find((preference) => preference.channel === "EMAIL")?.optedOut).toBe(true);
  });
});
