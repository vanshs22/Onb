import { describe, expect, it } from "vitest";
import { BLUEPRINT_50_127 } from "@/lib/feature-catalog";
import { routeCapability, normalizeProviderEvent } from "@/lib/server/integration-routing";

describe("provider-neutral integration routing", () => {
  it("uses a connected customer provider when explicitly selected", () => {
    const result = routeCapability({ capability: "forms", preferredProvider: "jotform", connectedProviders: ["onboardos", "jotform"] });
    expect(result.selected).toBe("jotform");
    expect(result.reason).toBe("customer_preference");
  });

  it("falls back to native OnboardOS when an external provider is unavailable", () => {
    const result = routeCapability({ capability: "health", preferredProvider: "guidecx", connectedProviders: ["onboardos"] });
    expect(result.selected).toBe("onboardos");
    expect(result.sourceOfTruth).toBe("ONBOARDOS");
  });

  it("normalizes provider events without changing the source payload", () => {
    const result = normalizeProviderEvent("jotform", "form.submitted", { id: "sub_1", answer: "yes" });
    expect(result.canonicalEvent).toBe("task.completed");
    expect(result.payload).toEqual({ id: "sub_1", answer: "yes" });
  });

  it("keeps the feature catalog available after adding provider routing", () => {
    expect(BLUEPRINT_50_127).toHaveLength(78);
  });
});
