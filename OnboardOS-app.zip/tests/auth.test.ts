import { SignJWT } from "jose";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { authenticateRequest, verifyAccessToken } from "@/lib/server/authentication";
import type { Queryable } from "@/lib/server/sql";

const SUPABASE_SECRET = "supabase-jwt-secret-supabase-jwt-secret-0123";
const AUTH_SECRET = "internal-auth-secret-internal-auth-secret-01";
const USER = "6f1b2a4e-9d3c-4f5a-8b7e-1c2d3e4f5a6b";
const sign = (claims: Record<string, unknown>, secret: string, opts: { aud?: string; exp?: string } = {}) => {
  const jwt = new SignJWT({ role: "authenticated", ...claims }).setProtectedHeader({ alg: "HS256" }).setSubject(USER).setExpirationTime(opts.exp ?? "5m");
  if (opts.aud) jwt.setAudience(opts.aud);
  return jwt.sign(new TextEncoder().encode(secret));
};
const request = (token?: string, org?: string) => new Request("http://localhost/api", { headers: { ...(token ? { authorization: `Bearer ${token}` } : {}), ...(org ? { "x-organization-id": org } : {}) } });
const lookup = (rows: Record<string, unknown>[]): Queryable => ({ query: async () => ({ rows }) });
const saved = { ...process.env };

beforeEach(() => { process.env.AUTH_SECRET = AUTH_SECRET; process.env.SUPABASE_JWT_SECRET = SUPABASE_SECRET; delete process.env.NEXT_PUBLIC_SUPABASE_URL; });
afterEach(() => { process.env = { ...saved }; });

describe("sign-in tokens", () => {
  it("accepts a genuine Supabase Auth token (audience 'authenticated')", async () => {
    const claims = await verifyAccessToken(await sign({}, SUPABASE_SECRET, { aud: "authenticated" }));
    expect(claims.sub).toBe(USER);
  });
  it("rejects forged, wrong-secret, expired and audience-less tokens", async () => {
    await expect(verifyAccessToken("not.a.token")).rejects.toMatchObject({ code: "AUTHENTICATION_REQUIRED" });
    await expect(verifyAccessToken(await sign({}, "a-completely-different-secret-value-123456", { aud: "authenticated" }))).rejects.toMatchObject({ code: "AUTHENTICATION_REQUIRED" });
    await expect(verifyAccessToken(await sign({}, SUPABASE_SECRET, { aud: "authenticated", exp: "-1m" }))).rejects.toMatchObject({ code: "AUTHENTICATION_REQUIRED" });
    await expect(verifyAccessToken(await sign({}, SUPABASE_SECRET))).rejects.toMatchObject({ code: "AUTHENTICATION_REQUIRED" });
  });
  it("accepts internally issued tokens that carry their own workspace and role, without a database lookup", async () => {
    const token = await sign({ organization_id: "org-9", role: "OPERATOR" }, AUTH_SECRET);
    expect(await authenticateRequest(request(token), lookup([]))).toEqual({ actorId: USER, organizationId: "org-9", role: "OPERATOR" });
  });
});

describe("who is this user and what can they do", () => {
  const supabaseToken = () => sign({}, SUPABASE_SECRET, { aud: "authenticated" });
  it("takes workspace and role from the database, not from anything the user can edit", async () => {
    const actor = await authenticateRequest(request(await supabaseToken()), lookup([{ organization_id: "org-1", name: "A", slug: "a", role: "VIEWER" }]));
    expect(actor).toEqual({ actorId: USER, organizationId: "org-1", role: "VIEWER" });
  });
  it("a token claiming to be an admin is ignored when the claim is not a workspace role", async () => {
    const actor = await authenticateRequest(request(await sign({ role: "service_role", organization_id: "org-evil" }, SUPABASE_SECRET, { aud: "authenticated" })), lookup([{ organization_id: "org-1", name: "A", slug: "a", role: "MEMBER" }]));
    expect(actor.organizationId).toBe("org-1");
    expect(actor.role).toBe("MEMBER");
  });
  it("asks multi-workspace users to choose, and refuses a workspace they do not belong to", async () => {
    const rows = [{ organization_id: "org-1", name: "A", slug: "a", role: "OWNER" }, { organization_id: "org-2", name: "B", slug: "b", role: "VIEWER" }];
    const token = await supabaseToken();
    await expect(authenticateRequest(request(token), lookup(rows))).rejects.toMatchObject({ code: "ORGANIZATION_REQUIRED" });
    expect((await authenticateRequest(request(token, "org-2"), lookup(rows))).role).toBe("VIEWER");
    await expect(authenticateRequest(request(token, "org-3"), lookup(rows))).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
  it("signed-in users without a workspace are told to create one", async () => {
    await expect(authenticateRequest(request(await supabaseToken()), lookup([]))).rejects.toMatchObject({ code: "NO_ORGANIZATION" });
  });
});

describe("anonymous access", () => {
  it("is allowed only in local demo mode without Supabase configured", async () => {
    expect((await authenticateRequest(request())).actorId).toBe("demo-user");
    process.env.NEXT_PUBLIC_SUPABASE_URL = "https://example.supabase.co";
    await expect(authenticateRequest(request())).rejects.toMatchObject({ code: "AUTHENTICATION_REQUIRED" });
  });
  it("is never allowed when demo mode is off", async () => {
    process.env.ONBOARDOS_DEMO_MODE = "false";
    await expect(authenticateRequest(request())).rejects.toMatchObject({ code: "AUTHENTICATION_REQUIRED" });
  });
});
