import { describe, expect, it } from "vitest";
import { assertTransition, canTransition } from "@/lib/domain";
import { transitionOnboarding, TransitionError } from "@/lib/server/transition-service";

describe("onboarding state machine", () => {
  it("allows valid lifecycle transitions and rejects invalid transitions", () => {
    expect(canTransition("DRAFT", "INVITED")).toBe(true);
    expect(canTransition("ACTIVATED", "DRAFT")).toBe(false);
    expect(() => assertTransition("COMPLETED", "IN_PROGRESS")).toThrow("STATE_TRANSITION_INVALID");
  });

  it("returns the same result for an idempotent command and rejects stale versions", () => {
    const command = { organizationId: "test-org", onboardingId: "onb_delta_04", to: "IN_KICKOFF" as const, expectedVersion: 1, idempotencyKey: "test-transition-1", actor: { type: "user" as const, id: "test-user" } };
    const first = transitionOnboarding(command);
    const replay = transitionOnboarding(command);
    expect(replay.event.event_id).toBe(first.event.event_id);
    expect(() => transitionOnboarding({ ...command, idempotencyKey: "test-transition-2" })).toThrow(TransitionError);
  });
});
