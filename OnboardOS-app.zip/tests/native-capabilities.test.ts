import { describe, expect, it } from "vitest";
import { NATIVE_CAPABILITIES } from "@/lib/native-capabilities";
import { runNativeCapability } from "@/lib/server/native-engine";

describe("native OnboardOS capabilities", () => {
  it("provides built-in substitutes for portal, forms, workflows, delivery, and activation", () => {
    for (const id of ["native.customer-workspace", "native.form-builder", "native.workflow-builder", "native.delivery-board", "native.activation"]) {
      expect(runNativeCapability(id)?.capability.execution).toBe("native");
    }
  });

  it("keeps payment and signature rails optional without making them the source of truth", () => {
    const commercial = NATIVE_CAPABILITIES.find((item) => item.id === "native.commercial-ux");
    expect(commercial?.sourceOfTruth).toBe("ONBOARDOS");
    expect(commercial?.externalFallbacks).toContain("stripe");
    expect(commercial?.externalFallbacks).toContain("docusign");
  });
});
