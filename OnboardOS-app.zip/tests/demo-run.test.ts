import { describe, expect, it } from "vitest";
import { runDemoCustomer } from "@/lib/server/demo-run";

describe("full demo customer run", () => {
  it("passes contract, invoice, payment, follow-up, kickoff, approval, activation, and handoff", () => {
    const result = runDemoCustomer("test-demo-run");
    expect(result.onboarding.state).toBe("COMPLETED");
    expect(result.onboarding.progress).toBe(100);
    expect(result.invoice.status).toBe("PAID");
    expect(result.activationCertificate.status).toBe("ACTIVATED");
    expect(result.handoff.status).toBe("COMPLETED");
    expect(result.steps.map((step) => step.key)).toEqual(expect.arrayContaining(["agreement-signed", "invoice-created", "payment-succeeded", "follow-up-sent", "kickoff-completed", "approval-approved", "activation-completed", "handoff"]));
    expect(result.steps.find((step) => step.key === "follow-up-sent")?.elapsedHours).toBe(60);
    expect(result.steps.find((step) => step.key === "access-verified")?.elapsedHours).toBe(84);
    expect(result.communication.followUpPolicy.optOutEnforced).toBe(true);
  });

  it("replays the same result for the same idempotency key", () => {
    const first = runDemoCustomer("test-demo-idempotency");
    const replay = runDemoCustomer("test-demo-idempotency");
    expect(replay.runId).toBe(first.runId);
    expect(replay.invoice.id).toBe(first.invoice.id);
  });
});
