import { readdirSync, readFileSync } from "node:fs";
import path from "node:path";
import { PGlite } from "@electric-sql/pglite";
import { beforeAll, describe, expect, it } from "vitest";
import { createUnsubscribeToken, enqueueFollowUps, planFollowUps, processDueJobs, revokeConsent, verifyUnsubscribeToken, type MessageSender } from "@/lib/server/followups";
import { transitionOnboardingDb } from "@/lib/server/repositories/onboarding-db";
import type { Queryable } from "@/lib/server/sql";

let db: PGlite;
const q = () => db as unknown as Queryable;
const ids: Record<string, string> = {};
const SECRET = "test-secret-test-secret-test-secret!!";
const one = async (sql: string, params: unknown[] = []) => (await db.query<Record<string, string>>(sql, params)).rows[0];
const asUser = <T,>(userId: string, fn: (tx: Queryable) => Promise<T>) => db.transaction(async (tx) => {
  await tx.query("select set_config('request.jwt.claims', $1, true)", [JSON.stringify({ sub: userId })]);
  await tx.exec("set local role authenticated");
  return fn(tx as unknown as Queryable);
});
function recorder(failTimes = 0) {
  const sent: { channel: string; to: unknown; body: string; unsubscribeUrl: string }[] = []; let failures = failTimes;
  const sender: MessageSender = { async send(input) { if (failures-- > 0) throw new Error("provider down"); sent.push(input); return { providerMessageId: `prov_${sent.length}` }; } };
  return { sender, sent };
}
const run = (sender: MessageSender, now = new Date("2026-10-02T17:00:00Z")) => processDueJobs(q(), sender, { secret: SECRET, appUrl: "https://app.test", now });
const makeDue = (key: string) => db.query("update scheduled_jobs set run_at = now() - interval '1 minute' where idempotency_key = $1", [key]);

async function newRequirement(title: string, email: string) {
  const contact = await one("insert into customer_contacts (organization_id, customer_id, name, email, timezone) values ($1,$2,'C',$3,'America/Los_Angeles') returning id", [ids.org, ids.cust, email]);
  const req = await one("insert into requirements (organization_id, onboarding_id, title, description, owner_type, stage) values ($1,$2,$3,'Needed before campaign setup.','CUSTOMER','Access') returning id", [ids.org, ids.onb, title]);
  const jobs = planFollowUps({ requirementId: req.id, onboardingId: ids.onb, contactId: contact.id, startedAt: new Date(), timezone: "America/Los_Angeles", consentedChannels: [] });
  await enqueueFollowUps(q(), ids.org, jobs);
  return { contact: contact.id, req: req.id, key1: jobs[0].idempotencyKey, key3: jobs[2].idempotencyKey };
}

beforeAll(async () => {
  db = new PGlite();
  await db.exec(`create schema auth; create table auth.users (id uuid primary key default gen_random_uuid(), email text, raw_user_meta_data jsonb not null default '{}');
    create function auth.jwt() returns jsonb language sql stable as $$ select coalesce(nullif(current_setting('request.jwt.claims', true), ''), '{}')::jsonb $$;
    create function auth.uid() returns uuid language sql stable as $$ select nullif(auth.jwt() ->> 'sub', '')::uuid $$;
    create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
    grant usage on schema auth to anon, authenticated, service_role; grant usage on schema public to anon, authenticated, service_role;`);
  const dir = path.resolve("supabase/migrations");
  for (const f of readdirSync(dir).sort()) await db.exec(readFileSync(path.join(dir, f), "utf8"));
  for (const n of ["owner", "other"]) ids[n] = (await one("insert into auth.users (email) values ($1) returning id", [n])).id;
  ids.org = (await one("insert into organizations (name, slug) values ('A','org-a') returning id")).id;
  ids.otherOrg = (await one("insert into organizations (name, slug) values ('B','org-b') returning id")).id;
  await db.query("insert into memberships (organization_id, user_id, role, status) values ($1,$2,'OWNER','ACTIVE'), ($3,$4,'OWNER','ACTIVE')", [ids.org, ids.owner, ids.otherOrg, ids.other]);
  ids.cust = (await one("insert into customers (organization_id, name) values ($1,'Acme') returning id", [ids.org])).id;
  ids.onb = (await one("insert into onboarding_instances (organization_id, customer_id, title) values ($1,$2,'Acme onboarding') returning id", [ids.org, ids.cust])).id;
}, 90_000);

describe("database-backed onboarding transitions (as a signed-in user, RLS enforced)", () => {
  const cmd = (over = {}) => ({ organizationId: ids.org, onboardingId: ids.onb, to: "INVITED" as const, expectedVersion: 1, idempotencyKey: "t-1", actor: { type: "USER" as const, id: ids.owner }, ...over });
  it("commits state, event, outbox and audit atomically and bumps the version", async () => {
    const result = await asUser(ids.owner, (tx) => transitionOnboardingDb(tx, cmd()));
    expect(result).toMatchObject({ onboarding: { state: "INVITED", version: 2 }, replayed: false });
    expect(Number((await one("select count(*) as n from events where aggregate_id=$1", [ids.onb])).n)).toBe(1);
    expect(Number((await one("select count(*) as n from outbox_messages where status='PENDING'")).n)).toBe(1);
    expect(Number((await one("select count(*) as n from audit_logs where action='onboarding.state_changed'")).n)).toBe(1);
  });
  it("replays an identical command without side effects and rejects key reuse with a different command", async () => {
    const replay = await asUser(ids.owner, (tx) => transitionOnboardingDb(tx, cmd()));
    expect(replay.replayed).toBe(true);
    expect(Number((await one("select count(*) as n from events where aggregate_id=$1", [ids.onb])).n)).toBe(1);
    await expect(asUser(ids.owner, (tx) => transitionOnboardingDb(tx, cmd({ to: "CANCELLED" })))).rejects.toMatchObject({ code: "IDEMPOTENCY_CONFLICT" });
  });
  it("returns conflicts for stale versions and invalid transitions, and leaves nothing behind", async () => {
    await expect(asUser(ids.owner, (tx) => transitionOnboardingDb(tx, cmd({ idempotencyKey: "t-2", to: "IN_PROGRESS", expectedVersion: 1 })))).rejects.toMatchObject({ code: "CONFLICT" });
    await expect(asUser(ids.owner, (tx) => transitionOnboardingDb(tx, cmd({ idempotencyKey: "t-3", to: "COMPLETED", expectedVersion: 2 })))).rejects.toMatchObject({ code: "STATE_TRANSITION_INVALID" });
    expect((await one("select state, version from onboarding_instances where id=$1", [ids.onb]))).toMatchObject({ state: "INVITED", version: 2 });
  });
  it("treats another tenant's onboarding as not found", async () => {
    await expect(asUser(ids.other, (tx) => transitionOnboardingDb(tx, cmd({ organizationId: ids.otherOrg, idempotencyKey: "x-1" })))).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
});

describe("follow-up worker: timing, consent, opt-out, retries", () => {
  it("does nothing before the 24h mark, then sends exactly one email with an unsubscribe link", async () => {
    const t = await newRequirement("Google Ads access", "a@example.test");
    const { sender, sent } = recorder();
    expect(await run(sender)).toHaveLength(0);
    await makeDue(t.key1);
    expect((await run(sender))[0].outcome).toBe("SENT");
    expect(sent).toHaveLength(1);
    expect(sent[0].body).toContain("Google Ads access");
    const token = new URL(sent[0].unsubscribeUrl).searchParams.get("token") as string;
    expect(verifyUnsubscribeToken(token, SECRET)).toMatchObject({ contactId: t.contact, channel: "EMAIL" });
    expect(verifyUnsubscribeToken(token + "x", SECRET)).toBeNull();
    expect(await run(sender)).toHaveLength(0);
  });
  it("suppresses the reminder after the customer clicks unsubscribe", async () => {
    const t = await newRequirement("Brand assets", "b@example.test");
    await revokeConsent(q(), { contactId: t.contact, channel: "EMAIL", organizationId: ids.org }, "unsubscribe_link");
    await makeDue(t.key1);
    const { sender, sent } = recorder();
    expect((await run(sender))[0].outcome).toBe("SUPPRESSED_NO_CONSENT_OR_OPTED_OUT");
    expect(sent).toHaveLength(0);
    expect((await one("select status from messages where contact_id=$1", [t.contact])).status).toBe("SUPPRESSED");
  });
  it("skips reminders once the requirement is already done", async () => {
    const t = await newRequirement("Kickoff booking", "c@example.test");
    await db.query("update requirements set status='WAIVED' where id=$1", [t.req]);
    await makeDue(t.key1);
    const { sender, sent } = recorder();
    expect((await run(sender))[0].outcome).toBe("SKIPPED_REQUIREMENT_DONE");
    expect(sent).toHaveLength(0);
  });
  it("defers to the customer's morning instead of messaging during their quiet hours", async () => {
    const t = await newRequirement("Tracking access", "d@example.test");
    await makeDue(t.key1);
    const { sender, sent } = recorder();
    const result = await run(sender, new Date("2026-10-03T06:00:00Z")); // 23:00 in Los Angeles
    expect(result[0].outcome).toBe("RESCHEDULED_QUIET_HOURS");
    expect(sent).toHaveLength(0);
    expect((await one("select status, run_at > now() as later from scheduled_jobs where idempotency_key=$1", [t.key1]))).toMatchObject({ status: "PENDING" });
  });
  it("retries after a provider failure without ever double-sending", async () => {
    const t = await newRequirement("Analytics access", "e@example.test");
    await makeDue(t.key1);
    const { sender, sent } = recorder(1);
    expect((await run(sender))[0].outcome).toBe("RETRY_SCHEDULED");
    await makeDue(t.key1);
    expect((await run(sender))[0].outcome).toBe("SENT");
    expect(sent).toHaveLength(1);
    expect(Number((await one("select count(*) as n from messages where contact_id=$1 and status='SENT'", [t.contact])).n)).toBe(1);
  });
  it("escalates to an account manager at 72h when the customer never responds", async () => {
    const t = await newRequirement("Payment method", "f@example.test");
    await makeDue(t.key3);
    const { sender } = recorder();
    expect((await run(sender))[0].outcome).toBe("ESCALATED");
    expect((await one("select severity, title from exceptions where title like '%Payment method'")).severity).toBe("HIGH");
  });
});

describe("unsubscribe tokens", () => {
  it("are tamper-proof", () => {
    const token = createUnsubscribeToken({ contactId: "c", channel: "SMS", organizationId: "o" }, SECRET);
    expect(verifyUnsubscribeToken(token, SECRET)).toEqual({ contactId: "c", channel: "SMS", organizationId: "o" });
    expect(verifyUnsubscribeToken(token, "another-secret-another-secret-123456")).toBeNull();
  });
});
