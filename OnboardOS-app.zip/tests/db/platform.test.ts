import type { PGlite } from "@electric-sql/pglite";
import Stripe from "stripe";
import { beforeAll, describe, expect, it } from "vitest";
import { listMemberships, resolveMembership } from "@/lib/server/authentication";
import { verifyStripeWebhook } from "@/lib/server/payments";
import { transitionOnboardingDb } from "@/lib/server/repositories/onboarding-db";
import { createOnboardingDb, listOnboardingsDb, verifyRequirementDb } from "@/lib/server/repositories/platform-db";
import type { Queryable } from "@/lib/server/sql";
import { applyStripeEvent, type StripeEventLike } from "@/lib/server/stripe-webhook";
import { asQueryable, asUser, createTestDb, one } from "./helpers";

let db: PGlite; let q: Queryable;
const ids: Record<string, string> = {};
const user = async (name: string) => (await one(db, "insert into auth.users (email, raw_user_meta_data) values ($1, $2) returning id", [`${name}@example.test`, JSON.stringify({ display_name: name })])).id;

beforeAll(async () => {
  db = await createTestDb(); q = asQueryable(db);
  for (const n of ["ownerA", "multi", "suspended", "loner"]) ids[n] = await user(n);
  ids.orgA = (await one(db, "insert into organizations (name, slug) values ('Org A','org-a') returning id")).id;
  ids.orgB = (await one(db, "insert into organizations (name, slug) values ('Org B','org-b') returning id")).id;
  await db.query("insert into memberships (organization_id, user_id, role, status) values ($1,$2,'OWNER','ACTIVE'), ($1,$3,'OPERATOR','ACTIVE'), ($4,$3,'VIEWER','ACTIVE'), ($1,$5,'ADMIN','SUSPENDED')", [ids.orgA, ids.ownerA, ids.multi, ids.orgB, ids.suspended]);
  const tplA = (await one(db, "insert into onboarding_templates (organization_id, name) values ($1,'Paid Ads') returning id", [ids.orgA])).id;
  ids.tplVersionA = (await one(db, "insert into onboarding_template_versions (organization_id, template_id, version, definition, published_at) values ($1,$2,1,$3, now()) returning id", [ids.orgA, tplA, JSON.stringify({ requirements: [{ title: "Sign agreement", owner: "CUSTOMER", stage: "Commercial", clientVisible: true, dueInHours: 24 }, { title: "Google Ads access", description: "Admin access", owner: "CUSTOMER", stage: "Access", clientVisible: true }, { title: "Kickoff call", owner: "INTERNAL", stage: "Kickoff" }] })])).id;
  const tplB = (await one(db, "insert into onboarding_templates (organization_id, name) values ($1,'Other') returning id", [ids.orgB])).id;
  ids.tplVersionB = (await one(db, "insert into onboarding_template_versions (organization_id, template_id, version, definition, published_at) values ($1,$2,1,'{}', now()) returning id", [ids.orgB, tplB])).id;
}, 90_000);

describe("multi-user workspace resolution", () => {
  it("auto-selects the only workspace a user belongs to", async () => {
    expect(await resolveMembership(q, ids.ownerA, null)).toEqual({ organizationId: ids.orgA, role: "OWNER" });
  });
  it("never guesses for multi-workspace users: a workspace must be chosen", async () => {
    await expect(resolveMembership(q, ids.multi, null)).rejects.toMatchObject({ code: "ORGANIZATION_REQUIRED" });
    expect(await resolveMembership(q, ids.multi, ids.orgB)).toEqual({ organizationId: ids.orgB, role: "VIEWER" });
    expect(await resolveMembership(q, ids.multi, ids.orgA)).toEqual({ organizationId: ids.orgA, role: "OPERATOR" });
  });
  it("rejects workspaces the user does not belong to, suspended members, and users with no workspace", async () => {
    await expect(resolveMembership(q, ids.ownerA, ids.orgB)).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(resolveMembership(q, ids.suspended, null)).rejects.toMatchObject({ code: "NO_ORGANIZATION" });
    await expect(resolveMembership(q, ids.loner, null)).rejects.toMatchObject({ code: "NO_ORGANIZATION" });
  });
  it("signup: a new user creates a workspace, becomes OWNER, and already has a profile", async () => {
    expect((await one(db, "select display_name from profiles where id=$1", [ids.loner])).display_name).toBe("loner");
    const orgId = await asUser(db, ids.loner, async (tx) => (await tx.query("select public.create_organization('Fresh Co','fresh-co','Europe/London') as id")).rows[0].id as string);
    expect(await resolveMembership(q, ids.loner, null)).toEqual({ organizationId: orgId, role: "OWNER" });
    expect((await listMemberships(q, ids.loner))[0]).toMatchObject({ name: "Fresh Co", role: "OWNER" });
  });
});

describe("deal won → onboarding (database, RLS enforced)", () => {
  const input = (over = {}) => ({ organizationId: ids.orgA, actorId: ids.ownerA, idempotencyKey: "deal-1", customer: { name: "Acme Roofing", externalRef: "hubspot-deal-1" }, title: "Google Ads + SEO", valueCents: 800000, templateVersionId: ids.tplVersionA, contact: { name: "Pat", email: "pat@acme.test", timezone: "America/Chicago" }, ...over });
  it("creates the customer, onboarding, requirements from the pinned template, contact, event and outbox", async () => {
    const r = await asUser(db, ids.ownerA, (tx) => createOnboardingDb(tx, input()));
    ids.onb = r.onboardingId; ids.cust = r.customerId;
    expect(r).toMatchObject({ requirementCount: 3, replayed: false });
    expect(Number((await one(db, "select count(*) as n from outbox_messages where event_id in (select id from events where aggregate_id=$1)", [r.onboardingId])).n)).toBe(1);
    expect((await one(db, "select timezone from customer_contacts where customer_id=$1", [r.customerId])).timezone).toBe("America/Chicago");
  });
  it("is idempotent on retry, and de-duplicates the customer on a second deal with the same CRM id", async () => {
    const again = await asUser(db, ids.ownerA, (tx) => createOnboardingDb(tx, input()));
    expect(again).toMatchObject({ onboardingId: ids.onb, replayed: true });
    const second = await asUser(db, ids.ownerA, (tx) => createOnboardingDb(tx, input({ idempotencyKey: "deal-2", title: "Upsell" })));
    expect(second.customerId).toBe(ids.cust);
    expect(second.onboardingId).not.toBe(ids.onb);
    expect(Number((await one(db, "select count(*) as n from customers where organization_id=$1 and external_ref='hubspot-deal-1'", [ids.orgA])).n)).toBe(1);
  });
  it("cannot use another workspace's template", async () => {
    await expect(asUser(db, ids.ownerA, (tx) => createOnboardingDb(tx, input({ idempotencyKey: "deal-3", templateVersionId: ids.tplVersionB })))).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
  it("serves the admin list in the UI's shape, with real progress and next action", async () => {
    const list = await asUser(db, ids.ownerA, (tx) => listOnboardingsDb(tx, ids.orgA));
    const acme = list.find((o) => o.id === ids.onb);
    expect(acme).toMatchObject({ customer: "Acme Roofing", initials: "AR", value: "$8,000", progress: 0, state: "DRAFT", nextAction: "Sign agreement" });
    expect(acme?.requirements).toHaveLength(3);
    expect(acme?.requirements[0]).toMatchObject({ owner: "Customer", clientVisible: true, verified: false });
  });
  it("hides it entirely from another workspace", async () => {
    expect(await asUser(db, ids.multi, (tx) => listOnboardingsDb(tx, ids.orgB))).toHaveLength(0);
  });
  it("verifies evidence independently, moves progress, and refuses self-verification", async () => {
    const req = (await one(db, "select id from requirements where onboarding_id=$1 and title='Sign agreement'", [ids.onb])).id;
    const base = { organizationId: ids.orgA, requirementId: req, evidenceType: "SIGNATURE", source: "docusign", idempotencyKey: "v-1" };
    await expect(verifyRequirementDb(q, { ...base, producer: "agent:chase", verifier: "agent:chase" })).rejects.toMatchObject({ code: "VERIFICATION_REJECTED" });
    expect((await verifyRequirementDb(q, { ...base, producer: "provider:docusign", verifier: "user:ops" })).replayed).toBe(false);
    expect((await verifyRequirementDb(q, { ...base, producer: "provider:docusign", verifier: "user:ops" })).replayed).toBe(true);
    const acme = (await asUser(db, ids.ownerA, (tx) => listOnboardingsDb(tx, ids.orgA))).find((o) => o.id === ids.onb);
    expect(acme).toMatchObject({ progress: 33, nextAction: "Google Ads access" });
  });
});

describe("payments: Stripe events applied to invoices", () => {
  const event = (id: string, over: Record<string, unknown> = {}, meta: Record<string, string> = {}): StripeEventLike => ({ id, type: "checkout.session.completed", data: { object: { id: `cs_${id}`, payment_status: "paid", payment_intent: `pi_${id}`, amount_total: 50000, metadata: { invoiceId: ids.invoice, organizationId: ids.orgA, ...meta }, ...over } } });
  beforeAll(async () => {
    ids.invoice = (await one(db, "insert into invoices (organization_id, customer_id, number, status, subtotal_cents, total_cents) values ($1,$2,'INV-PAY-1','SENT',50000,50000) returning id", [ids.orgA, ids.cust])).id;
  });
  it("applies a paid checkout to the invoice exactly once, even if Stripe redelivers or re-sends under a new event id", async () => {
    expect(await applyStripeEvent(q, event("evt_1"))).toMatchObject({ status: "APPLIED" });
    expect((await one(db, "select status, amount_paid_cents from invoices where id=$1", [ids.invoice]))).toMatchObject({ status: "PAID", amount_paid_cents: 50000 });
    expect(await applyStripeEvent(q, event("evt_1"))).toMatchObject({ status: "DUPLICATE" });
    expect(await applyStripeEvent(q, event("evt_1b", { payment_intent: "pi_evt_1" }))).toMatchObject({ status: "DUPLICATE" });
    expect(Number((await one(db, "select count(*) as n from payments where invoice_id=$1", [ids.invoice])).n)).toBe(1);
  });
  it("rejects overpayment, missing metadata and ignores unrelated events, without ever throwing", async () => {
    const small = (await one(db, "insert into invoices (organization_id, customer_id, number, status, subtotal_cents, total_cents) values ($1,$2,'INV-PAY-2','SENT',10000,10000) returning id", [ids.orgA, ids.cust])).id;
    expect(await applyStripeEvent(q, event("evt_over", { amount_total: 20000 }, { invoiceId: small }))).toMatchObject({ status: "REJECTED" });
    expect((await one(db, "select status, amount_paid_cents from invoices where id=$1", [small]))).toMatchObject({ status: "SENT", amount_paid_cents: 0 });
    expect(await applyStripeEvent(q, { id: "evt_nometa", type: "checkout.session.completed", data: { object: { payment_status: "paid", amount_total: 100, metadata: {} } } })).toMatchObject({ status: "REJECTED" });
    expect(await applyStripeEvent(q, { id: "evt_other", type: "customer.created", data: { object: {} } })).toMatchObject({ status: "IGNORED" });
  });
  it("refuses to credit a payment to an invoice from a different workspace", async () => {
    const foreign = (await one(db, "insert into customers (organization_id, name) values ($1,'B cust') returning id", [ids.orgB])).id;
    const inv = (await one(db, "insert into invoices (organization_id, customer_id, number, status, subtotal_cents, total_cents) values ($1,$2,'INV-B-1','SENT',5000,5000) returning id", [ids.orgB, foreign])).id;
    expect(await applyStripeEvent(q, event("evt_cross", { amount_total: 5000 }, { invoiceId: inv }))).toMatchObject({ status: "REJECTED" });
    expect((await one(db, "select amount_paid_cents from invoices where id=$1", [inv])).amount_paid_cents).toBe(0);
  });
  it("retries a delivery that failed transiently instead of dropping the payment", async () => {
    const inv = (await one(db, "insert into invoices (organization_id, customer_id, number, status, subtotal_cents, total_cents) values ($1,$2,'INV-PAY-3','SENT',7000,7000) returning id", [ids.orgA, ids.cust])).id;
    let failed = false;
    const flaky: Queryable = { query: async (sql, params) => { if (!failed && sql.startsWith("insert into payments")) { failed = true; throw new Error("connection reset"); } return q.query(sql, params); } };
    const e = event("evt_flaky", { amount_total: 7000 }, { invoiceId: inv });
    await expect(applyStripeEvent(flaky, e)).rejects.toThrow("connection reset");
    expect(await applyStripeEvent(flaky, e)).toMatchObject({ status: "APPLIED" });
    expect((await one(db, "select status from invoices where id=$1", [inv])).status).toBe("PAID");
  });
  it("verifies real Stripe signatures and rejects tampering", () => {
    process.env.STRIPE_WEBHOOK_SECRET = "whsec_test_secret";
    const payload = JSON.stringify({ id: "evt_sig", object: "event", type: "checkout.session.completed", data: { object: {} } });
    const header = Stripe.webhooks.generateTestHeaderString({ payload, secret: "whsec_test_secret" });
    expect(verifyStripeWebhook(payload, header).id).toBe("evt_sig");
    expect(() => verifyStripeWebhook(payload.replace("evt_sig", "evt_evil"), header)).toThrow();
    expect(() => verifyStripeWebhook(payload, header.replace(/v1=\w+/, "v1=deadbeef"))).toThrow();
  });
});

describe("concurrent users", () => {
  const cmd = (onboardingId: string, key: string) => ({ organizationId: ids.orgA, onboardingId, to: "INVITED" as const, expectedVersion: 1, idempotencyKey: key, actor: { type: "USER" as const, id: ids.ownerA } });
  const fresh = async (title: string) => (await one(db, "insert into onboarding_instances (organization_id, customer_id, title) values ($1,$2,$3) returning id", [ids.orgA, ids.cust, title])).id;
  it("when six users race to change the same onboarding, exactly one wins and five get a clean conflict", async () => {
    const id = await fresh("race");
    const results = await Promise.allSettled([1, 2, 3, 4, 5, 6].map((n) => asUser(db, ids.ownerA, (tx) => transitionOnboardingDb(tx, cmd(id, `race-${n}`)))));
    expect(results.filter((r) => r.status === "fulfilled")).toHaveLength(1);
    const losers = results.filter((r): r is PromiseRejectedResult => r.status === "rejected");
    expect(losers).toHaveLength(5);
    losers.forEach((l) => expect(l.reason).toMatchObject({ code: "CONFLICT" }));
    expect(Number((await one(db, "select count(*) as n from events where aggregate_id=$1", [id])).n)).toBe(1);
  });
  it("when the same request is sent six times at once (double-click, retry storm), it is applied once and all callers get the same answer", async () => {
    const id = await fresh("storm");
    const results = await Promise.all([1, 2, 3, 4, 5, 6].map(() => asUser(db, ids.ownerA, (tx) => transitionOnboardingDb(tx, cmd(id, "storm-key")))));
    expect(results.filter((r) => !r.replayed)).toHaveLength(1);
    expect(new Set(results.map((r) => r.eventId)).size).toBe(1);
    expect(Number((await one(db, "select count(*) as n from events where aggregate_id=$1", [id])).n)).toBe(1);
  });
  it("when the same payment event arrives six times at once, the invoice is credited once", async () => {
    const inv = (await one(db, "insert into invoices (organization_id, customer_id, number, status, subtotal_cents, total_cents) values ($1,$2,'INV-RACE','SENT',9000,9000) returning id", [ids.orgA, ids.cust])).id;
    const e: StripeEventLike = { id: "evt_race", type: "checkout.session.completed", data: { object: { id: "cs_race", payment_status: "paid", payment_intent: "pi_race", amount_total: 9000, metadata: { invoiceId: inv, organizationId: ids.orgA } } } };
    const outcomes = await Promise.all([1, 2, 3, 4, 5, 6].map(() => applyStripeEvent(q, e)));
    expect(outcomes.filter((o) => o.status === "APPLIED")).toHaveLength(1);
    expect((await one(db, "select amount_paid_cents, status from invoices where id=$1", [inv]))).toMatchObject({ amount_paid_cents: 9000, status: "PAID" });
  });
});
