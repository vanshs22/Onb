import { readdirSync, readFileSync } from "node:fs";
import path from "node:path";
import { PGlite } from "@electric-sql/pglite";
import { beforeAll, describe, expect, it } from "vitest";

let db: PGlite;
const ids: Record<string, string> = {};

async function one(sql: string, params: unknown[] = []) {
  const result = await db.query<Record<string, string>>(sql, params);
  return result.rows[0];
}
async function asUser<T>(userId: string, fn: (tx: PGlite) => Promise<T>): Promise<T> {
  return db.transaction(async (tx) => {
    await tx.query("select set_config('request.jwt.claims', $1, true)", [JSON.stringify({ sub: userId, role: "authenticated" })]);
    await tx.exec("set local role authenticated");
    return fn(tx as unknown as PGlite);
  });
}

beforeAll(async () => {
  db = new PGlite();
  await db.exec(`
    create schema auth;
    create table auth.users (id uuid primary key default gen_random_uuid(), email text, raw_user_meta_data jsonb not null default '{}');
    create function auth.jwt() returns jsonb language sql stable as $$ select coalesce(nullif(current_setting('request.jwt.claims', true), ''), '{}')::jsonb $$;
    create function auth.uid() returns uuid language sql stable as $$ select nullif(auth.jwt() ->> 'sub', '')::uuid $$;
    create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
    grant usage on schema auth to anon, authenticated, service_role;
    grant usage on schema public to anon, authenticated, service_role;
  `);
  const dir = path.resolve("supabase/migrations");
  for (const file of readdirSync(dir).sort()) await db.exec(readFileSync(path.join(dir, file), "utf8"));

  for (const name of ["ownerA", "viewerA", "ownerB", "portal"]) ids[name] = (await one("insert into auth.users (email) values ($1) returning id", [`${name}@example.test`])).id;
  for (const [key, slug] of [["orgA", "tenant-a"], ["orgB", "tenant-b"]]) ids[key] = (await one("insert into organizations (name, slug) values ($1, $2) returning id", [slug, slug])).id;
  await db.query("insert into memberships (organization_id, user_id, role, status) values ($1,$2,'OWNER','ACTIVE'), ($1,$3,'VIEWER','ACTIVE'), ($4,$5,'OWNER','ACTIVE')", [ids.orgA, ids.ownerA, ids.viewerA, ids.orgB, ids.ownerB]);
  for (const [key, org] of [["custA", ids.orgA], ["custB", ids.orgB]]) ids[key] = (await one("insert into customers (organization_id, name) values ($1,'Customer') returning id", [org])).id;
  ids.onbA = (await one("insert into onboarding_instances (organization_id, customer_id, title) values ($1,$2,'Acme') returning id", [ids.orgA, ids.custA])).id;
  ids.onbB = (await one("insert into onboarding_instances (organization_id, customer_id, title) values ($1,$2,'Other') returning id", [ids.orgB, ids.custB])).id;
}, 90_000);

describe("tenant isolation (RLS)", () => {
  it("tenant A can only read its own rows", async () => {
    const rows = await asUser(ids.ownerA, (tx) => tx.query<{ id: string }>("select id from onboarding_instances"));
    expect(rows.rows.map((r) => r.id)).toEqual([ids.onbA]);
  });
  it("tenant A cannot insert, update or delete tenant B data", async () => {
    await expect(asUser(ids.ownerA, (tx) => tx.query("insert into customers (organization_id, name) values ($1,'x')", [ids.orgB]))).rejects.toThrow();
    const updated = await asUser(ids.ownerA, (tx) => tx.query("update customers set name='hacked' where id=$1 returning id", [ids.custB]));
    expect(updated.rows).toHaveLength(0);
    const deleted = await asUser(ids.ownerA, (tx) => tx.query("delete from customers where id=$1 returning id", [ids.custB]));
    expect(deleted.rows).toHaveLength(0);
  });
  it("blocks cross-tenant references even with a valid own organization_id", async () => {
    await expect(db.query("insert into onboarding_instances (organization_id, customer_id, title) values ($1,$2,'leak')", [ids.orgA, ids.custB])).rejects.toThrow(/foreign key/i);
  });
  it("viewers are read-only", async () => {
    const read = await asUser(ids.viewerA, (tx) => tx.query("select id from customers"));
    expect(read.rows).toHaveLength(1);
    await expect(asUser(ids.viewerA, (tx) => tx.query("insert into customers (organization_id, name) values ($1,'x')", [ids.orgA]))).rejects.toThrow();
  });
  it("events and audit logs are append-only; payments and certificates are service-only", async () => {
    await expect(asUser(ids.ownerA, (tx) => tx.query("update audit_logs set action='x'"))).rejects.toThrow();
    await expect(asUser(ids.ownerA, (tx) => tx.query("insert into activation_certificates (organization_id, onboarding_id, criteria_results) values ($1,$2,'[{\"satisfied\":true}]')", [ids.orgA, ids.onbA]))).rejects.toThrow();
  });
  it("signup RPC creates an organization with the caller as OWNER", async () => {
    const orgId = await asUser(ids.ownerB, async (tx) => (await tx.query<{ create_organization: string }>("select public.create_organization('New Co','new-co')")).rows[0].create_organization);
    const role = await one("select role from memberships where organization_id=$1 and user_id=$2", [orgId, ids.ownerB]);
    expect(role.role).toBe("OWNER");
  });
});

describe("verified evidence and activation proof", () => {
  it("a requirement cannot be SATISFIED without an independent passed verification", async () => {
    const req = await one("insert into requirements (organization_id, onboarding_id, title, owner_type, stage) values ($1,$2,'Google Ads access','CUSTOMER','Access') returning id", [ids.orgA, ids.onbA]);
    await expect(db.query("update requirements set status='SATISFIED' where id=$1", [req.id])).rejects.toThrow(/REQUIREMENT_NOT_VERIFIED/);
    const ev = await one("insert into evidence (organization_id, requirement_id, type, source, producer) values ($1,$2,'OAUTH','google','agent:chase') returning id", [ids.orgA, req.id]);
    await expect(db.query("insert into verifications (organization_id, requirement_id, evidence_id, status, verifier) values ($1,$2,$3,'PASSED','agent:chase')", [ids.orgA, req.id, ev.id])).rejects.toThrow(/SELF_VERIFICATION_FORBIDDEN/);
    await db.query("insert into verifications (organization_id, requirement_id, evidence_id, status, verifier) values ($1,$2,$3,'PASSED','provider:google-ads-api')", [ids.orgA, req.id, ev.id]);
    await db.query("update requirements set status='SATISFIED' where id=$1", [req.id]);
    ids.reqA = req.id;
  });
  it("rejects dependency cycles", async () => {
    const r2 = await one("insert into requirements (organization_id, onboarding_id, title, owner_type, stage) values ($1,$2,'Campaign setup','INTERNAL','Setup') returning id", [ids.orgA, ids.onbA]);
    await db.query("insert into requirement_dependencies (organization_id, requirement_id, depends_on_id) values ($1,$2,$3)", [ids.orgA, r2.id, ids.reqA]);
    await expect(db.query("insert into requirement_dependencies (organization_id, requirement_id, depends_on_id) values ($1,$2,$3)", [ids.orgA, ids.reqA, r2.id])).rejects.toThrow(/DEPENDENCY_CYCLE/);
    await db.query("update requirements set status='WAIVED' where id=$1", [r2.id]);
  });
  it("enforces the state machine and refuses ACTIVATED without proof", async () => {
    await expect(db.query("update onboarding_instances set state='COMPLETED' where id=$1", [ids.onbA])).rejects.toThrow(/STATE_TRANSITION_INVALID/);
    const walk = ["INVITED", "IN_PROGRESS", "READY_FOR_KICKOFF", "IN_KICKOFF", "IN_IMPLEMENTATION", "AWAITING_APPROVAL", "READY_FOR_ACTIVATION"];
    for (const state of walk) await db.query("update onboarding_instances set state=$2 where id=$1", [ids.onbA, state]);
    await expect(db.query("update onboarding_instances set state='ACTIVATED' where id=$1", [ids.onbA])).rejects.toThrow(/ACTIVATION_PROOF_REQUIRED/);
    await expect(db.query("insert into activation_certificates (organization_id, onboarding_id, criteria_results) values ($1,$2,'[{\"id\":\"live\",\"satisfied\":false}]')", [ids.orgA, ids.onbA])).rejects.toThrow(/CERTIFICATE_CRITERIA_UNSATISFIED/);
    await db.query("insert into activation_certificates (organization_id, onboarding_id, criteria_results) values ($1,$2,'[{\"id\":\"live\",\"satisfied\":true}]')", [ids.orgA, ids.onbA]);
    await db.query("update onboarding_instances set state='ACTIVATED' where id=$1", [ids.onbA]);
    const row = await one("select state, version, activated_at is not null as stamped from onboarding_instances where id=$1", [ids.onbA]);
    expect(row.state).toBe("ACTIVATED");
    expect(Number(row.version)).toBeGreaterThan(8);
    expect(row.stamped).toBe(true);
  });
  it("published template versions are immutable", async () => {
    const tpl = await one("insert into onboarding_templates (organization_id, name) values ($1,'T') returning id", [ids.orgA]);
    const ver = await one("insert into onboarding_template_versions (organization_id, template_id, version, definition, published_at) values ($1,$2,1,'{}', now()) returning id", [ids.orgA, tpl.id]);
    await expect(db.query("update onboarding_template_versions set definition='{\"x\":1}' where id=$1", [ver.id])).rejects.toThrow(/PUBLISHED_VERSION_IMMUTABLE/);
  });
});

describe("consent, opt-out and durable follow-ups", () => {
  it("allows email by default, requires consent for SMS, and blocks everything after opt-out", async () => {
    ids.contact = (await one("insert into customer_contacts (organization_id, customer_id, name, email) values ($1,$2,'Pat','pat@example.test') returning id", [ids.orgA, ids.custA])).id;
    const send = (channel: string, key: string) => db.query("insert into messages (organization_id, contact_id, direction, channel, body, idempotency_key) values ($1,$2,'OUTBOUND',$3,'hi',$4)", [ids.orgA, ids.contact, channel, key]);
    await send("EMAIL", "m1");
    await expect(send("SMS", "m2")).rejects.toThrow(/CONSENT_REQUIRED_OR_OPTED_OUT/);
    await db.query("insert into channel_consents (organization_id, contact_id, channel, status, source) values ($1,$2,'SMS','GRANTED','form')", [ids.orgA, ids.contact]);
    await send("SMS", "m3");
    await db.query("update channel_consents set status='REVOKED', revoked_at=now() where contact_id=$1 and channel='SMS'", [ids.contact]);
    await expect(send("SMS", "m4")).rejects.toThrow(/CONSENT_REQUIRED_OR_OPTED_OUT/);
    await db.query("insert into channel_consents (organization_id, contact_id, channel, status, source) values ($1,$2,'EMAIL','REVOKED','unsubscribe_link')", [ids.orgA, ids.contact]);
    await expect(send("EMAIL", "m5")).rejects.toThrow(/CONSENT_REQUIRED_OR_OPTED_OUT/);
  });
  it("message idempotency keys prevent duplicate sends on retry", async () => {
    await expect(db.query("insert into messages (organization_id, contact_id, direction, channel, status, body, idempotency_key) values ($1,$2,'OUTBOUND','IN_APP','SENT','dup','dup-key')", [ids.orgA, ids.contact])).resolves.toBeDefined();
    await expect(db.query("insert into messages (organization_id, contact_id, direction, channel, status, body, idempotency_key) values ($1,$2,'OUTBOUND','IN_APP','SENT','dup','dup-key')", [ids.orgA, ids.contact])).rejects.toThrow(/duplicate/i);
  });
  it("scheduler claims only due jobs, retries with backoff, and dead-letters after max attempts", async () => {
    const job = (key: string, offset: string) => db.query(`insert into scheduled_jobs (organization_id, kind, run_at, idempotency_key, max_attempts) values ($1,'reminder', now() + interval '${offset}', $2, 2)`, [ids.orgA, key]);
    await job("due", "-1 minute");
    await job("future", "24 hours");
    await expect(job("due", "-1 minute")).rejects.toThrow(/duplicate/i);
    const claimed = (await db.query<{ id: string; idempotency_key: string; attempts: number }>("select * from app.claim_due_jobs(10)")).rows;
    expect(claimed.map((j) => j.idempotency_key)).toEqual(["due"]);
    expect((await db.query("select * from app.claim_due_jobs(10)")).rows).toHaveLength(0);
    await db.query("select app.fail_job($1, 'provider timeout')", [claimed[0].id]);
    const retry = await one("select status, run_at > now() as delayed from scheduled_jobs where id=$1", [claimed[0].id]);
    expect(retry).toMatchObject({ status: "PENDING", delayed: true });
    await db.query("update scheduled_jobs set run_at = now() where id=$1", [claimed[0].id]);
    const again = (await db.query<{ id: string }>("select * from app.claim_due_jobs(10)")).rows;
    await db.query("select app.fail_job($1, 'provider timeout')", [again[0].id]);
    expect((await one("select status from scheduled_jobs where id=$1", [again[0].id])).status).toBe("FAILED");
  });
});

describe("invoices and payments", () => {
  it("applies payments atomically, is idempotent per provider payment id, and blocks overpayment", async () => {
    const inv = await one("insert into invoices (organization_id, customer_id, number, status, subtotal_cents, tax_cents, total_cents) values ($1,$2,'INV-1','SENT',10000,800,10800) returning id", [ids.orgA, ids.custA]);
    const pay = (amount: number, pid: string) => db.query("insert into payments (organization_id, invoice_id, amount_cents, provider, provider_payment_id) values ($1,$2,$3,'stripe',$4)", [ids.orgA, inv.id, amount, pid]);
    await pay(5000, "pi_1");
    expect((await one("select status, amount_paid_cents from invoices where id=$1", [inv.id]))).toMatchObject({ status: "PARTIALLY_PAID", amount_paid_cents: 5000 });
    await expect(pay(5000, "pi_1")).rejects.toThrow(/duplicate/i);
    await expect(pay(9999, "pi_2")).rejects.toThrow();
    await pay(5800, "pi_3");
    expect((await one("select status, paid_at is not null as stamped from invoices where id=$1", [inv.id]))).toMatchObject({ status: "PAID", stamped: true });
  });
  it("rejects invoices whose totals do not add up and payments on draft invoices", async () => {
    await expect(db.query("insert into invoices (organization_id, customer_id, number, subtotal_cents, tax_cents, total_cents) values ($1,$2,'INV-2',100,10,999)", [ids.orgA, ids.custA])).rejects.toThrow();
    const draft = await one("insert into invoices (organization_id, customer_id, number, subtotal_cents, total_cents) values ($1,$2,'INV-3',100,100) returning id", [ids.orgA, ids.custA]);
    await expect(db.query("insert into payments (organization_id, invoice_id, amount_cents, provider, provider_payment_id) values ($1,$2,100,'stripe','pi_draft')", [ids.orgA, draft.id])).rejects.toThrow(/INVOICE_NOT_PAYABLE/);
  });
});

describe("customer portal access", () => {
  it("portal contacts see only their own onboarding and client-visible requirements, and can opt out", async () => {
    const contact = await one("insert into customer_contacts (organization_id, customer_id, name, email) values ($1,$2,'Portal User','portal@example.test') returning id", [ids.orgA, ids.custA]);
    await db.query("insert into customer_contact_identities (organization_id, contact_id, auth_user_id, verified_at) values ($1,$2,$3, now())", [ids.orgA, contact.id, ids.portal]);
    await db.query("insert into onboarding_contacts (organization_id, onboarding_id, contact_id) values ($1,$2,$3)", [ids.orgA, ids.onbA, contact.id]);
    await db.query("insert into requirements (organization_id, onboarding_id, title, owner_type, stage, client_visible) values ($1,$2,'Visible','CUSTOMER','Intake', true), ($1,$2,'Internal note','INTERNAL','QA', false)", [ids.orgA, ids.onbA]);
    const onboardings = await asUser(ids.portal, (tx) => tx.query<{ id: string }>("select id from onboarding_instances"));
    expect(onboardings.rows.map((r) => r.id)).toEqual([ids.onbA]);
    const reqs = await asUser(ids.portal, (tx) => tx.query<{ title: string }>("select title from requirements"));
    expect(reqs.rows.map((r) => r.title)).toEqual(["Visible"]);
    expect((await asUser(ids.portal, (tx) => tx.query("select id from customers"))).rows).toHaveLength(0);
    await asUser(ids.portal, (tx) => tx.query("select public.set_channel_consent($1,'EMAIL','REVOKED')", [contact.id]));
    expect((await one("select app.can_contact($1,'EMAIL') as ok", [contact.id])).ok).toBe(false);
    await expect(asUser(ids.portal, (tx) => tx.query("select public.set_channel_consent($1,'EMAIL','REVOKED')", [ids.contact]))).rejects.toThrow(/FORBIDDEN/);
  });
});
