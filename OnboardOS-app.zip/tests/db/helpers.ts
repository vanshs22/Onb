import { readdirSync, readFileSync } from "node:fs";
import path from "node:path";
import { PGlite } from "@electric-sql/pglite";
import type { Queryable } from "@/lib/server/sql";

/** A real Postgres (PGlite) with Supabase-style auth stubs and every migration applied. */
export async function createTestDb() {
  const db = new PGlite();
  await db.exec(`create schema auth;
    create table auth.users (id uuid primary key default gen_random_uuid(), email text, raw_user_meta_data jsonb not null default '{}');
    create function auth.jwt() returns jsonb language sql stable as $$ select coalesce(nullif(current_setting('request.jwt.claims', true), ''), '{}')::jsonb $$;
    create function auth.uid() returns uuid language sql stable as $$ select nullif(auth.jwt() ->> 'sub', '')::uuid $$;
    create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
    grant usage on schema auth to anon, authenticated, service_role; grant usage on schema public to anon, authenticated, service_role;`);
  const dir = path.resolve("supabase/migrations");
  for (const file of readdirSync(dir).sort()) await db.exec(readFileSync(path.join(dir, file), "utf8"));
  return db;
}
export const asQueryable = (db: PGlite) => db as unknown as Queryable;
export const one = async (db: PGlite, sql: string, params: unknown[] = []) => (await db.query<Record<string, string>>(sql, params)).rows[0];
export const asUser = <T,>(db: PGlite, userId: string, fn: (tx: Queryable) => Promise<T>) => db.transaction(async (tx) => {
  await tx.query("select set_config('request.jwt.claims', $1, true)", [JSON.stringify({ sub: userId, role: "authenticated" })]);
  await tx.exec("set local role authenticated");
  return fn(tx as unknown as Queryable);
});
