import { createHmac } from "node:crypto";
import { describe, expect, it } from "vitest";
import { verifyWebhookSignature } from "@/lib/server/webhooks";
import { permissionsFor } from "@/lib/server/authorization";

describe("security contracts", () => {
  it("verifies webhook signatures with timing-safe comparison", () => {
    const body = JSON.stringify({ id: "evt_test" });
    const signature = createHmac("sha256", "demo-webhook-secret").update(body).digest("hex");
    expect(verifyWebhookSignature("test-provider", body, signature)).toBe(true);
    expect(verifyWebhookSignature("test-provider", body, "bad")).toBe(false);
  });

  it("does not grant viewer write permissions", () => {
    const permissions = permissionsFor("VIEWER");
    expect(permissions).toContain("onboarding.read");
    expect(permissions).not.toContain("onboarding.write");
    expect(permissions).not.toContain("evidence.verify");
  });
});
