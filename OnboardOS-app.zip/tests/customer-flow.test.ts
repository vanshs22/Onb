import { describe, expect, it } from "vitest";
import { activationReadiness } from "@/lib/server/operations";
import { onboardingTwin, orchestrate } from "@/lib/server/orchestrator";

describe("demo customer journey", () => {
  it("shows Acme's real next action and does not claim activation prematurely", () => {
    const twin = onboardingTwin("onb_acme_01");
    expect(twin?.nextAction.title).toBe("Google Ads access");
    expect(activationReadiness("onb_acme_01")?.ready).toBe(false);
    expect(activationReadiness("onb_acme_01")?.missingCriteria.length).toBeGreaterThan(0);
  });

  it("plans the controlled agent loop without performing an unsafe side effect", () => {
    const result = orchestrate("onb_acme_01", "demo-customer");
    expect(result?.execution).toMatchObject({ status: "PLANNED", sideEffect: "none", approvalRequired: true });
    expect(result?.verification.independent).toBe(true);
    expect(result?.handoff.required).toBe(false);
  });
});
