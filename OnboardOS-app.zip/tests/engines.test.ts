import { describe, expect, it } from "vitest";
import { isQuietHour, nextAllowedTime, parseOptKeyword, planFollowUps } from "@/lib/server/followups";
import { extractIntake, validateForm, type FormSchema } from "@/lib/server/forms";
import { computeInvoice, InvoiceError, invoiceNumber, planDunning } from "@/lib/server/invoices";

describe("invoice engine", () => {
  it("computes discounts and tax in integer cents", () => {
    const r = computeInvoice([{ description: "Ads setup", quantity: 1, unitPriceCents: 100000, taxRateBps: 825 }, { description: "SEO audit", quantity: 1, unitPriceCents: 100000, taxRateBps: 825 }], { type: "PERCENT_BPS", value: 1000 });
    expect(r).toMatchObject({ subtotalCents: 200000, discountCents: 20000, taxCents: 14850, totalCents: 194850 });
  });
  it("never drifts: totals always reconcile, even with awkward splits", () => {
    for (let cents = 1; cents < 200; cents += 7) {
      const r = computeInvoice([{ description: "a", quantity: 1, unitPriceCents: 333 }, { description: "b", quantity: 2.5, unitPriceCents: 101 }, { description: "c", quantity: 1, unitPriceCents: 7 }], { type: "FIXED_CENTS", value: cents });
      expect(r.items.reduce((s, i) => s + i.discountCents, 0)).toBe(cents);
      expect(r.totalCents).toBe(r.subtotalCents - r.discountCents + r.taxCents);
    }
  });
  it("rejects invalid input and formats numbers", () => {
    expect(() => computeInvoice([{ description: "x", quantity: 1, unitPriceCents: 10.5 }])).toThrow(InvoiceError);
    expect(() => computeInvoice([{ description: "x", quantity: 1, unitPriceCents: 100 }], { type: "FIXED_CENTS", value: 500 })).toThrow(/exceed/);
    expect(invoiceNumber(2026, 42)).toBe("INV-2026-000042");
  });
  it("plans dunning from before the due date through escalation, using SMS only with consent", () => {
    const due = new Date("2026-10-10T00:00:00Z");
    expect(planDunning(due).map((s) => s.step)).toEqual(["UPCOMING", "DUE", "OVERDUE_1", "OVERDUE_2", "ESCALATE"]);
    expect(planDunning(due)[3].channel).toBe("EMAIL");
    expect(planDunning(due, true)[3].channel).toBe("SMS");
  });
});

describe("form engine", () => {
  const schema: FormSchema = { fields: [
    { id: "email", type: "email", label: "Work email", required: true, mapsToRequirement: "contact" },
    { id: "uses_crm", type: "select", label: "Do you use a CRM?", options: ["yes", "no"], required: true },
    { id: "crm", type: "select", label: "Which CRM?", options: ["HubSpot", "Salesforce"], required: true, visibleIf: { field: "uses_crm", op: "eq", value: "yes" } },
    { id: "budget", type: "number", label: "Monthly budget", min: 500 },
  ] };
  it("only requires fields that are visible", () => {
    expect(validateForm(schema, { email: "a@b.co", uses_crm: "no" }).valid).toBe(true);
    const r = validateForm(schema, { email: "a@b.co", uses_crm: "yes" });
    expect(r.errors).toEqual([expect.objectContaining({ field: "crm", code: "REQUIRED" })]);
  });
  it("strips hidden answers, rejects unknown fields and bad values, and maps requirements", () => {
    const r = validateForm(schema, { email: "nope", uses_crm: "no", crm: "HubSpot", budget: 100, hacker: "x" });
    expect(r.errors.map((e) => e.code).sort()).toEqual(["INVALID_EMAIL", "OUT_OF_RANGE", "UNKNOWN_FIELD"]);
    const ok = validateForm(schema, { email: "a@b.co", uses_crm: "no", crm: "HubSpot" });
    expect(ok.answers).not.toHaveProperty("crm");
    expect(ok.satisfiedRequirements).toEqual(["contact"]);
  });
  it("turns free text into structured intake and implied requirements", () => {
    const r = extractIntake("We want more roofing leads in California and already use HubSpot.");
    expect(r).toMatchObject({ goal: "Lead generation", industry: "Roofing", market: "California", crm: "HubSpot" });
    expect(r.requirements).toEqual(expect.arrayContaining(["Google Ads access", "Landing page", "Call tracking", "HubSpot sync"]));
  });
});

describe("timing and opt-out rules", () => {
  it("respects the customer's timezone, not the server's", () => {
    expect(isQuietHour(new Date("2026-10-02T04:00:00Z"), "America/Los_Angeles")).toBe(true);
    expect(isQuietHour(new Date("2026-10-02T16:00:00Z"), "America/Los_Angeles")).toBe(false);
    expect(nextAllowedTime(new Date("2026-10-02T05:00:00Z"), "America/Los_Angeles").toISOString()).toBe("2026-10-02T15:00:00.000Z");
    expect(isQuietHour(new Date("2026-10-02T16:00:00Z"), "Asia/Tokyo")).toBe(true);
  });
  it("plans 24/48/72h follow-ups, falling back to email when SMS was never consented", () => {
    const base = { requirementId: "r", onboardingId: "o", contactId: "c", startedAt: new Date("2026-10-01T17:00:00Z"), timezone: "America/Los_Angeles" };
    expect(planFollowUps({ ...base, consentedChannels: [] }).map((j) => j.payload.channel)).toEqual(["EMAIL", "EMAIL", "INTERNAL"]);
    expect(planFollowUps({ ...base, consentedChannels: ["SMS"] })[1].payload.channel).toBe("SMS");
  });
  it("recognises carrier STOP/START keywords only as whole messages", () => {
    expect(parseOptKeyword(" stop ")).toBe("OPT_OUT");
    expect(parseOptKeyword("UNSUBSCRIBE")).toBe("OPT_OUT");
    expect(parseOptKeyword("start")).toBe("OPT_IN");
    expect(parseOptKeyword("please stop texting me")).toBeNull();
  });
});
