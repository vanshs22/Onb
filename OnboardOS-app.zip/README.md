# OnboardOS

OnboardOS is the AI execution layer between a signed deal and customer activation. This repository contains a runnable Next.js command-center product foundation grounded in the supplied production blueprint and is being implemented in batches of three production capabilities.

## Implemented batch 01

- Internal Command Center with Overview, Exception Inbox, Onboardings, Requirements, Workflows, Templates, Integrations, Analytics, Knowledge, Messages, Team, and Settings surfaces.
- Customer Onboarding Workspace view with next-action-first UX.
- Canonical onboarding state machine with controlled transitions.
- Canonical event catalog and versioned event envelope helpers.
- Production-oriented Prisma schema with UUID identifiers, organization tenancy, versioned templates, requirements, evidence, verification, exceptions, events, outbox messages, idempotency keys, audit records, contacts, and channel consent.
- Supabase/PostgreSQL RLS policy contract with `USING` and `WITH CHECK` tenant isolation.
- Concurrency-safe transition service with expected-version checks, idempotency-key replay, structured conflict errors, event creation, and outbox records.
- API route spine under `/api/v1` for health, onboarding listing/creation, state transitions, and event catalog.
- Demo data representing a marketing-agency workflow, including blockers, verified evidence, exceptions, health, and activation readiness.
- Responsive, accessible visual system for desktop operations and mobile customer onboarding.

## Run locally

```bash
npm install
npm run dev
```

Open `http://localhost:3000`. The app is intentionally usable without external credentials so the product workflow can be reviewed immediately.

## Production hardening still required before deployment

The product is being built incrementally. The Prisma model and RLS contract are now present, but the demo adapter still needs to be connected to a live PostgreSQL transaction before deployment. Remaining infrastructure includes authenticated org membership, Redis/BullMQ, object storage, provider OAuth/webhooks, durable outbox workers, audit persistence, and a real model-provider gateway. The API contract intentionally exposes its persistence boundary rather than pretending demo data is a live production database.

## Canonical product rules

- `organization_id` is the tenant boundary.
- UUIDs are used for identifiers in production persistence contracts.
- All onboarding state changes go through the transition service.
- Mutating transition requests require `Idempotency-Key` and an expected version.
- `ACTIVATED` is an outcome; `INVITED`/`IN_PROGRESS` are workflow states.
- `payment.succeeded` is the canonical payment event.
- Customer views receive safe projections, not internal workflow records.

## Implemented batch 02

- Server-side actor context and RBAC permission contract for workspace, onboarding, requirements, evidence verification, workflow execution, integrations, and audit access.
- `/api/v1/auth/me` safe session projection and permission list.
- Requirement listing and independent evidence verification endpoint with idempotency and canonical `evidence.verified` events.
- Outbox health and replay endpoints with permission checks, attempt tracking, and replay metadata.

The in-memory adapter remains deliberately isolated behind server services so it can be replaced by Prisma transactions and a durable worker without changing the API contracts.

## Implemented batch 03

- Customer-safe workspace projection that exposes only client-visible requirements and next actions.
- Versioned forms and submissions persistence contracts with idempotent submission API.
- Document metadata and quarantine contract with MIME/size validation, object-key isolation, scan-required status, and evidence event emission.
- Expanded Prisma schema for forms, form versions, submissions, and quarantined documents.

## Blueprint items 09–50 implementation layer

The shared contract and engine layer for blueprint items 09–50 is now present:

- launch versus activation semantics, activation criteria, readiness, and handoff contracts
- promise graph, scope comparison, dependency representation, and change-order recommendation
- canonical workflow node types, tool registry, agent roster, autonomy ceilings, and independent verification metadata
- connector capability registry for CRM, payments, e-signature, calendar, messaging, and storage
- channel consent decisioning, quiet-hours checks, chase eligibility, SLA evaluation, and escalation plans
- explainable health calculation and revenue/activation signals
- webhook authentication, persistence-shaped delivery records, duplicate detection, and replay-safe response behavior
- operations catalog endpoint exposing the canonical registries

New execution endpoints include `/api/v1/catalog/operations`, onboarding health/activation/graph/scope/handoff routes, communication decisioning, SLA evaluation, and provider webhooks. Provider adapters still require real credentials and production implementations; the contracts are intentionally stable so those adapters can be added without changing agent behavior.

## Blueprint items 09–50 executable coverage

All 42 blueprint entries in the 09–50 range now have an explicit catalog entry and executable runtime path through:

- `GET /api/v1/features`
- `GET /api/v1/features/:id`
- `POST /api/v1/features/:id/run`

The runtime returns deterministic results for the demo environment. Provider-dependent entries are marked `CONTRACT_WITH_ADAPTER` and return adapter-ready results; live provider calls still require credentials and adapter implementations.

## Blueprint items 50–127 coverage

The remaining blueprint range is cataloged in `BLUEPRINT_50_127` and exposed at:

```text
GET /api/v1/features/50-127
GET /api/v1/features/:id
POST /api/v1/features/:id/run
```

Each numbered item has a named entry, endpoint, runtime mode, tenant-scoped execution metadata, audit metadata, and replay metadata. `CONTRACT_WITH_ADAPTER` entries intentionally mark work that requires a live external provider or deployment service; the core runtime does not fabricate provider success.

## Latest hardening pass

- Competitor research and positioning analysis lives in `docs/COMPETITIVE-RESEARCH.md`.
- JWT/HMAC authentication primitives are available through `lib/server/authentication.ts`; production requires `AUTH_SECRET` and verified organization claims.
- Critical mutation routes enforce authentication, roles, idempotency, and structured errors.
- Webhook signatures use HMAC with timing-safe comparison and provider-event deduplication.
- Stripe Checkout and webhook adapters are available under `/api/v1/payments/*`; demo mode never claims a real charge.
- PostgreSQL connectivity is checked by `/api/v1/health`; production readiness reports false until database and queue dependencies are configured.
- The visual system uses the OnboardOS brand palette: ink/navy, acid lime, electric violet, and coral rather than generic SaaS blue/green.
- `npm test` runs the domain, security, feature coverage, and demo customer journey tests.
- `npm audit --audit-level=high` is clean.

## Native OnboardOS capability layer

Clients can now use built-in OnboardOS capabilities through `lib/native-capabilities.ts` and:

```text
GET  /api/v1/native/capabilities
GET  /api/v1/native/:id
POST /api/v1/native/:id
```

Native capabilities include the customer workspace, forms, workflow builder, delivery board, requirements, evidence, verification, approvals, documents, communication, health, analytics, commercial UX, scheduling UX, concierge, activation proof, CRM compiler, and MCP governance. External products remain optional fallbacks routed through the integration catalog.

## Full demo customer run

Run the entire flow with:

```bash
curl -X POST http://localhost:3000/api/v1/demo/run \
  -H 'Idempotency-Key: demo-customer-1'
```

The admin top bar also includes **Run demo**. The demo runner executes 21 simulated steps from CRM deal won through invoice/payment, intake, evidence, access, contextual follow-up, kickoff, implementation, approval, activation certificate, and completed handoff. It is disabled in production unless `ONBOARDOS_DEMO_MODE=true`.
