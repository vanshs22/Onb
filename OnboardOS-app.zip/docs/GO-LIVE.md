# OnboardOS go-live contract

## Included in this repository

- Standalone Next.js production build via `Dockerfile`.
- Local Postgres 16 and Redis 7 orchestration via `docker-compose.yml`.
- Supabase migration: `supabase/migrations/20261002000000_onboardos_core.sql` (apply with `supabase db push`).
- Production configuration template at `.env.production.example`.
- Fail-closed production configuration validation with `npm run production-check`.
- CI workflow running tests, typecheck, lint, build, and dependency audit.
- Native OnboardOS capability layer with optional external providers.
- Stripe Checkout/webhook adapter with no card-data storage.
- JWT/RBAC authentication primitives and HMAC webhook validation.
- Demo-only end-to-end customer runner isolated from production mode.

## Required before enabling real customers

1. Provision managed PostgreSQL and Redis.
2. Apply the SQL migration using a controlled migration job.
3. Configure a real `AUTH_SECRET` and production identity provider/session issuer.
4. Configure storage, signed URLs, malware scanning, and retention policies.
5. Configure Stripe test mode first, then verify live-mode webhooks and reconciliation.
6. Configure OAuth credentials for CRM, calendar, Gmail, and e-sign providers.
7. Configure an email/SMS/WhatsApp provider and verify consent/opt-out behavior.
8. Run two-tenant RLS tests against the provisioned database.
9. Run browser E2E tests against staging with provider sandboxes.
10. Configure logs, traces, metrics, alerts, backups, restore drills, and incident ownership.
11. Disable demo mode and run `npm run production-check` in the release environment.

The application intentionally does not claim production readiness when database, queue, authentication, or provider credentials are absent.
