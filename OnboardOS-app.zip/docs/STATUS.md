# Honest status (October 2026)

**Verified by automated tests (no external credentials):** Supabase migration on real Postgres (RLS, two-tenant isolation, activation proof, independent verification, opt-out, payments, scheduler); Supabase JWT verification and database-resolved workspace/role; multi-workspace selection; signup → workspace → dashboard in a real browser; onboarding creation from template; invoice totals and save/send/pay-link; Stripe webhook signature + idempotent payment application; forms with conditional logic; follow-up worker; unsubscribe links; role enforcement; cross-tenant isolation; concurrent-request outcomes.

**Connected to the database in the UI:** Onboardings (list, create), Invoices, Forms (validation).
**Still sample data in the UI:** Overview KPIs, Exceptions, Clients, Requirements, Workflows, Templates, Analytics, Knowledge, Messages, Team, Settings, Customer workspace preview. Signed-in workspaces see a "Sample data" banner on these.

**Not verified (needs real accounts):** Stripe live/test API, Resend, Twilio, HubSpot/Google/Calendly/DocuSign OAuth, real Supabase project, real multi-connection Postgres concurrency, load, security review, backup/restore.
**Not built:** customer-portal sign-in UI (database policies exist), workspace switcher UI, team invitations UI, AI agent runtime calling a model, document scanning/storage.
