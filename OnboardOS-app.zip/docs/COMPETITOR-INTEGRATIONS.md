# Competitor and provider integration strategy

OnboardOS should integrate with competitors only through authorized APIs, OAuth, webhooks, MCP, or customer-owned automation bridges. It must not scrape competitor interfaces or copy their proprietary implementation.

## Provider availability and adapter strategy

- **Dubsado:** use its documented integrations/Zapier and webhook-style bridge for forms, contracts, payments, scheduling, and workflow triggers. [Dubsado integrations](https://www.dubsado.com/integrations), [Dubsado Zapier triggers/actions](https://help.dubsado.com/en/articles/15920601-dubsado-triggers-and-actions-in-zapier).
- **Bonsai:** use its API or authorized automation bridge for CRM, clients, projects, contracts, invoices, and payments. [Bonsai API](https://help.hellobonsai.com/en/articles/1865175-bonsai-api), [Bonsai integrations](https://help.hellobonsai.com/en/collections/96956-integrations).
- **Jotform:** use its REST API and webhooks to import forms/submissions/files/payments and map questions into OnboardOS requirements. [Jotform API](https://www.jotform.com/apidocs-v1/), [Jotform developer integrations](https://www.jotform.com/developers/integrations/).
- **Rocketlane:** use the REST API and HTTPS webhooks to synchronize projects, tasks, dependencies, health, and delivery events. [Rocketlane API](https://developer.rocketlane.com/docs/overview), [Rocketlane webhooks](https://developer.rocketlane.com/docs/webhooks-overview).
- **OnRamp:** use its REST API and available event/webhook mechanisms for projects, playbooks, tasks, and risk signals. [OnRamp API reference](https://api.onramp.us/docs).
- **GUIDEcx:** use the Open API, Analytics API, and authorized MCP route for project data, health, analytics, and controlled AI actions. [GUIDEcx Open API](https://help.guidecx.com/en/articles/15182340-guidecx-open-api-3-0), [GUIDEcx MCP](https://help.guidecx.com/en/articles/16823408-build-a-local-mcp-server-for-your-guidecx-workspace).

Content was rephrased for compliance with licensing restrictions.

## Runtime behavior

The integration catalog is implemented in `lib/integration-catalog.ts` and exposes:

```text
GET  /api/v1/integrations/catalog
POST /api/v1/integrations
POST /api/v1/integrations/:provider/connect
```

Routing behavior:

1. OnboardOS native execution is the default.
2. A customer can select an authorized external provider.
3. A connected provider wins only for the requested capability.
4. If that provider is unavailable, OnboardOS falls back to its native capability where safe.
5. OnboardOS remains the source of truth for requirements, evidence, verification, health, exceptions, and activation.
6. External provider events are normalized into canonical OnboardOS events.

This allows customers to keep Dubsado, Bonsai, Jotform, Rocketlane, OnRamp, or GUIDEcx while still using OnboardOS as the intelligence and activation layer.
