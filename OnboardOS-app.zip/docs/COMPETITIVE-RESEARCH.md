# OnboardOS competitive research

Research date: October 2, 2026.

## Market observations

- **Dubsado** combines branded client portals with forms, contracts, scheduling, invoicing, payments, and workflow automation. Its public feature and help documentation emphasize a repeatable client process and a portal that surfaces contracts and payment status: [Dubsado feature overview](https://www.dubsado.com/feature-overview), [Dubsado portals](https://www.dubsado.com/access-client-portals).
- **Bonsai** links CRM close data to projects, contracts, invoicing, and a branded client portal. Its strength is business administration across the client relationship, project delivery, and finance: [Bonsai CRM](https://www.hellobonsai.com/crm), [Bonsai client portal](https://www.hellobonsai.com/client-portal).
- **Jotform** is extending form/workflow infrastructure with AI agents, multichannel assistance, signatures, and payment flows. Its strength is configurable intake and conversational form completion: [Jotform AI Agents](https://www.jotform.com/ai/agents/announcing-jotform-ai-agents/), [Jotform AI payment flows](https://www.jotform.com/help/how-to-collect-payments-via-ai-agents/).
- **Rocketlane** is positioning an agentic PSA around documentation, risk detection, governance, and work execution inside professional-services delivery. This is the strongest direct pressure on the execution thesis: [Rocketlane agentic PSA](https://www.rocketlane.com/blogs/introducing-nitro-agentic-ai-for-psa), [Rocketlane work execution](https://www.rocketlane.com/blogs/agentic-ai-for-professional-services).
- **OnRamp** emphasizes adaptive workflows, personalized customer experiences, proactive intervention, structured data, and AI-generated playbooks: [OnRamp](https://onramp.us/).
- **GUIDEcx** combines customer workspaces, health/mitigation plans, integrations, APIs, and an MCP path for AI access to onboarding data: [GUIDEcx AI onboarding](https://www.guidecx.com/products/features/ai-customer-onboarding/), [GUIDEcx Open API](https://help.guidecx.com/en/articles/15182340-guidecx-open-api-3-0), [GUIDEcx MCP](https://help.guidecx.com/en/articles/16823408-build-a-local-mcp-server-for-your-guidecx-workspace).

Content was rephrased for compliance with licensing restrictions.

## Product decision

OnboardOS should not compete on having another portal, form builder, payment page, or task list. Those are table stakes. The moat is the controlled chain:

`Promise → Scope → Requirement → Evidence → Verification → Dependency → Execution → Approval → Activation`

The product must beat category tools on five measurable outcomes:

1. **Activation proof:** “done” means independently verified first value, not a green checklist.
2. **Commercial protection:** promises and customer requests are compared against scope before delivery absorbs the work.
3. **Recovery:** failed or uncertain provider actions are reconciled before retrying, preventing duplicate payments, bookings, or messages.
4. **Proactive operations:** the system recommends and, within policy, executes the next safe action before a human searches for the problem.
5. **Trust:** every agent/tool/provider action is tenant-scoped, approval-aware, idempotent, attributable, and replayable.

## Implementation implications

- Keep the Operations Center focused on exceptions, impact, revenue exposure, SLA, and recommended actions.
- Keep the customer workspace focused on one next action and a clear activation path.
- Keep the AI layer behind a capability/tool gateway with independent verification.
- Build provider adapters, not replacement payment, e-signature, CRM, or calendar products.
- Treat the onboarding twin as the operational source of truth while syncing selected state back to CRM.
