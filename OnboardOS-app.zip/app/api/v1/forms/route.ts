import { NextResponse } from "next/server";
import { db } from "@/lib/server/db";
import { guard } from "@/lib/server/http";

export async function GET(request: Request) {
  const auth = await guard(request, "onboarding.read");
  if ("response" in auth) return auth.response;
  if (!db) return NextResponse.json({ data: [], meta: { persisted: false, demo: true } });
  const result = await db.query("select f.id, f.name, max(v.version) as latest_version, max(v.published_at) as published_at from forms f left join form_versions v on v.form_id=f.id and v.organization_id=f.organization_id where f.organization_id=$1 group by f.id, f.name order by f.name", [auth.actor.organizationId]);
  return NextResponse.json({ data: result.rows, meta: { persisted: true } });
}
