import { NextResponse } from "next/server";
import { db } from "@/lib/server/db";
import { fail, guard } from "@/lib/server/http";
import { validateForm, type FormSchema } from "@/lib/server/forms";
import { runtimeConfig } from "@/lib/server/config";
import { withTenantTransaction } from "@/lib/server/sql";

export async function POST(request: Request) {
  const auth = await guard(request, "requirement.write");
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => null)) as { onboardingId?: string; formVersionId?: string; contactId?: string; schema?: FormSchema; answers?: Record<string, unknown> } | null;
  if (!body?.onboardingId || !body.formVersionId || !body.schema || !body.answers) return fail("VALIDATION_ERROR", "onboardingId, formVersionId, schema and answers are required.", 422);
  const validation = validateForm(body.schema, body.answers);
  if (!validation.valid) return NextResponse.json({ data: validation }, { status: 422 });
  if (!db) { if (runtimeConfig().isProduction) return fail("SERVICE_UNAVAILABLE", "Database is not configured.", 503); return NextResponse.json({ data: { answers: validation.answers, status: "SUBMITTED", persisted: false }, meta: { demo: true } }, { status: 201 }); }
  const submission = await withTenantTransaction(db, auth.actor.actorId, async (tx) => (await tx.query("insert into form_submissions (organization_id, onboarding_id, form_version_id, contact_id, answers) values ($1,$2,$3,$4,$5::jsonb) returning id, status, created_at", [auth.actor.organizationId, body.onboardingId, body.formVersionId, body.contactId ?? null, JSON.stringify(validation.answers)])).rows[0]);
  return NextResponse.json({ data: { submission, validation }, meta: { persisted: true } }, { status: 201 });
}
