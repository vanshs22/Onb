import { NextResponse } from "next/server";
import { fail, guard } from "@/lib/server/http";
import { validateForm, type FormSchema } from "@/lib/server/forms";

export async function POST(request: Request) {
  const auth = await guard(request, "onboarding.read");
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => null)) as { schema?: FormSchema; answers?: Record<string, unknown> } | null;
  if (!body?.schema?.fields || !body.answers) return fail("VALIDATION_ERROR", "schema and answers are required.", 422);
  const result = validateForm(body.schema, body.answers);
  return NextResponse.json({ data: result }, { status: result.valid ? 200 : 422 });
}
