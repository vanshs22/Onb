import { NextResponse } from "next/server";
import { communicationDecision } from "@/lib/server/operations";
import type { Channel } from "@/lib/product-contracts";

export async function POST(request: Request) {
  const body = await request.json().catch(() => null) as { channel?: Channel; consentGranted?: boolean; localHour?: number } | null;
  if (!body?.channel || typeof body.consentGranted !== "boolean") return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "channel and consentGranted are required.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 422 });
  return NextResponse.json({ data: communicationDecision(body.channel, body.consentGranted, body.localHour) });
}
