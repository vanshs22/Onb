import { NextResponse } from "next/server";
import { BLUEPRINT_50_127 } from "@/lib/feature-catalog";

export async function GET() {
  return NextResponse.json({ data: BLUEPRINT_50_127, meta: { range: "50-127", count: BLUEPRINT_50_127.length } });
}
