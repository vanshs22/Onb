import { NextResponse } from "next/server";
import { ALL_BLUEPRINT_FEATURES } from "@/lib/feature-catalog";

export async function GET() {
  return NextResponse.json({ data: ALL_BLUEPRINT_FEATURES, meta: { range: "09-127", count: ALL_BLUEPRINT_FEATURES.length, requestedRemainingRange: "50-127" } });
}
