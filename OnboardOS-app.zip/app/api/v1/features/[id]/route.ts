import { NextResponse } from "next/server";
import { featureStatus } from "@/lib/server/feature-runtime";

export async function GET(_: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const feature = featureStatus(Number(id));
  if (!feature) return NextResponse.json({ error: { code: "NOT_FOUND", message: "Blueprint feature is outside the 09–50 range.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 404 });
  return NextResponse.json({ data: feature });
}
