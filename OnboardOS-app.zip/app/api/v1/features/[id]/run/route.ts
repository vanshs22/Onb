import { NextResponse } from "next/server";
import { runFeature } from "@/lib/server/feature-runtime";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const featureId = Number(id);
  const input = await request.json().catch(() => ({})) as Record<string, unknown>;
  const result = runFeature(featureId, input);
  if (!result) return NextResponse.json({ error: { code: "NOT_FOUND", message: "Blueprint feature is outside the 09–50 range.", details: { featureId }, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 404 });
  return NextResponse.json({ data: result, meta: { provider_execution: result.feature?.mode === "CONTRACT_WITH_ADAPTER" ? "adapter_required" : "runtime" } });
}
