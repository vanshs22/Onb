import { NextResponse } from "next/server";
import { EVENT_CATALOG } from "@/lib/domain";

export async function GET() {
  return NextResponse.json({
    data: EVENT_CATALOG.map((event_type) => ({ event_type, event_version: 1 })),
    meta: { count: EVENT_CATALOG.length, canonical: true },
  });
}
