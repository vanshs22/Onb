import { NextResponse } from "next/server";
import { escalationPlan } from "@/lib/server/operations";

export async function POST(request: Request) {
  const body = await request.json().catch(() => null) as { policyId?: string; elapsedHours?: number } | null;
  if (!body?.policyId || typeof body.elapsedHours !== "number") return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "policyId and elapsedHours are required.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 422 });
  return NextResponse.json({ data: escalationPlan(body.policyId, body.elapsedHours) });
}
