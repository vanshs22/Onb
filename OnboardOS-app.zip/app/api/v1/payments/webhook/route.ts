import { NextResponse } from "next/server";
import { db } from "@/lib/server/db";
import { fail } from "@/lib/server/http";
import { PaymentConfigurationError, verifyStripeWebhook } from "@/lib/server/payments";
import type { Queryable } from "@/lib/server/sql";
import { applyStripeEvent, type StripeEventLike } from "@/lib/server/stripe-webhook";

export async function POST(request: Request) {
  const rawBody = await request.text();
  const signature = request.headers.get("stripe-signature");
  if (!signature) return fail("VALIDATION_ERROR", "stripe-signature is required.", 422);
  let event;
  try { event = verifyStripeWebhook(rawBody, signature); }
  catch (error) { return error instanceof PaymentConfigurationError ? fail("SERVICE_UNAVAILABLE", error.message, 503) : fail("FORBIDDEN", "Webhook signature verification failed.", 401); }
  if (!db) return NextResponse.json({ received: true, event_id: event.id, persisted: false });
  const outcome = await applyStripeEvent(db as unknown as Queryable, event as unknown as StripeEventLike);
  return NextResponse.json({ received: true, event_id: event.id, outcome });
}
