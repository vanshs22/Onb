import { NextResponse } from "next/server";
import { runtimeConfig } from "@/lib/server/config";
import { db } from "@/lib/server/db";
import { fail, guard } from "@/lib/server/http";
import { createCheckout, PaymentConfigurationError } from "@/lib/server/payments";
import { withTenantTransaction } from "@/lib/server/sql";

/** The amount is always read from the invoice in the database, never from the request. */
export async function POST(request: Request) {
  const auth = await guard(request, "onboarding.write");
  if ("response" in auth) return auth.response;
  const key = request.headers.get("idempotency-key");
  const body = (await request.json().catch(() => null)) as { invoiceId?: string; customerEmail?: string; amountCents?: number } | null;
  if (!key || !body?.invoiceId) return fail("VALIDATION_ERROR", "invoiceId and Idempotency-Key are required.", 422);
  let amountCents = 0; let currency = "USD"; let description = "Invoice";
  if (db) {
    const invoice = await withTenantTransaction(db, auth.actor.actorId, async (tx) => (await tx.query("select number, status, currency, total_cents - amount_paid_cents as due from invoices where id=$1 and organization_id=$2", [body.invoiceId, auth.actor.organizationId])).rows[0]);
    if (!invoice) return fail("NOT_FOUND", "Invoice was not found.", 404);
    if (!["SENT", "PARTIALLY_PAID", "OVERDUE"].includes(String(invoice.status))) return fail("INVOICE_NOT_PAYABLE", `A ${String(invoice.status).toLowerCase()} invoice cannot be paid. Send it first.`, 409);
    amountCents = Number(invoice.due); currency = String(invoice.currency).trim(); description = `Invoice ${invoice.number}`;
  } else {
    if (runtimeConfig().isProduction) return fail("SERVICE_UNAVAILABLE", "Database is not configured.", 503);
    amountCents = body.amountCents ?? 0; description = "Demo invoice";
  }
  try {
    const checkout = await createCheckout({ invoiceId: body.invoiceId, organizationId: auth.actor.organizationId, amountCents, currency, customerEmail: body.customerEmail, description, idempotencyKey: key });
    return NextResponse.json({ data: checkout, meta: { organization_id: auth.actor.organizationId } }, { status: 201 });
  } catch (error) {
    if (error instanceof PaymentConfigurationError) return fail("SERVICE_UNAVAILABLE", error.message, 503);
    return fail("EXTERNAL_PROVIDER_ERROR", "The payment provider rejected the request.", 502);
  }
}
