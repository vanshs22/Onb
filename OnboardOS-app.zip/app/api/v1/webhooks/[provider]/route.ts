import { NextResponse } from "next/server";
import { receiveWebhook } from "@/lib/server/webhooks";

export async function POST(request: Request, context: { params: Promise<{ provider: string }> }) {
  const { provider } = await context.params;
  const requestId = crypto.randomUUID();
  const providerEventId = request.headers.get("x-provider-event-id");
  const signature = request.headers.get("x-provider-signature") ?? "";
  const rawBody = await request.text();
  let payload: unknown;
  try { payload = JSON.parse(rawBody); } catch { return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "Webhook body must be valid JSON.", details: {}, request_id: requestId, retryable: false, field_errors: [] } }, { status: 422 }); }
  if (!providerEventId) return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "Provider event ID is required.", details: {}, request_id: requestId, retryable: false, field_errors: [] } }, { status: 422 });
  const delivery = receiveWebhook({ provider, providerEventId, signature, rawBody, payload });
  if (!delivery.signatureValid) return NextResponse.json({ error: { code: "FORBIDDEN", message: "Webhook signature verification failed.", details: { deliveryId: delivery.id }, request_id: requestId, retryable: false, field_errors: [] } }, { status: 401 });
  return NextResponse.json({ data: delivery }, { status: delivery.status === "DUPLICATE" ? 200 : 202 });
}
