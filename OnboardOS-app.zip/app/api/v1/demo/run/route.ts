import { NextResponse } from "next/server";
import { runDemoCustomer } from "@/lib/server/demo-run";

export async function POST(request: Request) {
  if (process.env.NODE_ENV === "production" && process.env.ONBOARDOS_DEMO_MODE !== "true") return NextResponse.json({ error: { code: "FORBIDDEN", message: "Demo runs are disabled in production.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 403 });
  const key = request.headers.get("idempotency-key") ?? "demo-customer-default";
  const result = runDemoCustomer(key);
  return NextResponse.json({ data: result, meta: { demo: true, idempotent: true, request_id: crypto.randomUUID() } }, { status: 201 });
}
