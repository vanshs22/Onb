import { NextResponse } from "next/server";
import { onboardings } from "@/lib/demo-data";
import { db } from "@/lib/server/db";
import { guard } from "@/lib/server/http";
import { withTenantTransaction } from "@/lib/server/sql";

export async function GET(request: Request) {
  const auth = await guard(request, "onboarding.read");
  if ("response" in auth) return auth.response;
  if (!db) return NextResponse.json({ data: onboardings.map((o) => ({ id: o.id, name: o.customer })), meta: { persisted: false, demo: true } });
  const rows = await withTenantTransaction(db, auth.actor.actorId, async (tx) => (await tx.query("select id, name from customers where organization_id=$1 order by name limit 500", [auth.actor.organizationId])).rows);
  return NextResponse.json({ data: rows, meta: { persisted: true } });
}
