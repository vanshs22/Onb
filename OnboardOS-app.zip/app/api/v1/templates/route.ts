import { NextResponse } from "next/server";
import { db } from "@/lib/server/db";
import { guard } from "@/lib/server/http";
import { withTenantTransaction } from "@/lib/server/sql";

export async function GET(request: Request) {
  const auth = await guard(request, "onboarding.read");
  if ("response" in auth) return auth.response;
  if (!db) return NextResponse.json({ data: [], meta: { persisted: false, demo: true } });
  const rows = await withTenantTransaction(db, auth.actor.actorId, async (tx) => (await tx.query("select v.id, t.name, v.version from onboarding_template_versions v join onboarding_templates t on t.id = v.template_id and t.organization_id = v.organization_id where v.organization_id=$1 and v.published_at is not null order by t.name, v.version desc", [auth.actor.organizationId])).rows);
  return NextResponse.json({ data: rows, meta: { persisted: true } });
}
