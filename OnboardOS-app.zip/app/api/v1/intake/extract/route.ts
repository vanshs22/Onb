import { NextResponse } from "next/server";
import { fail, guard } from "@/lib/server/http";
import { extractIntake } from "@/lib/server/forms";

export async function POST(request: Request) {
  const auth = await guard(request, "onboarding.read");
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => null)) as { text?: string } | null;
  if (!body?.text || body.text.length > 5000) return fail("VALIDATION_ERROR", "text (max 5000 chars) is required.", 422);
  return NextResponse.json({ data: extractIntake(body.text) });
}
