import { NextResponse } from "next/server";
import { identify, listMemberships } from "@/lib/server/authentication";
import { db } from "@/lib/server/db";
import { fail, toAuthResponse } from "@/lib/server/http";
import { withTenantTransaction } from "@/lib/server/sql";

export async function GET(request: Request) {
  try {
    const identity = await identify(request);
    if (identity.demo || !db) return NextResponse.json({ data: [{ organizationId: "demo-organization", name: "Acme Media Group", slug: "acme-media", role: "ADMIN" }], meta: { demo: true } });
    return NextResponse.json({ data: await listMemberships(db as never, identity.userId) });
  } catch (error) { const response = toAuthResponse(error); if (response) return response; throw error; }
}

/** First-run signup step: creates the workspace and makes the caller its OWNER (via the create_organization RPC). */
export async function POST(request: Request) {
  try {
    const identity = await identify(request);
    const body = (await request.json().catch(() => null)) as { name?: string; timezone?: string } | null;
    const name = body?.name?.trim();
    if (!name || name.length > 200) return fail("VALIDATION_ERROR", "A workspace name (max 200 characters) is required.", 422);
    if (identity.demo || !db) return NextResponse.json({ data: { organizationId: "demo-organization" }, meta: { demo: true } }, { status: 201 });
    const slug = `${name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 48) || "workspace"}-${crypto.randomUUID().slice(0, 4)}`;
    const id = await withTenantTransaction(db, identity.userId, async (tx) => (await tx.query("select public.create_organization($1,$2,$3) as id", [name, slug, body?.timezone ?? "UTC"])).rows[0].id as string);
    return NextResponse.json({ data: { organizationId: id, slug } }, { status: 201 });
  } catch (error) { const response = toAuthResponse(error); if (response) return response; throw error; }
}
