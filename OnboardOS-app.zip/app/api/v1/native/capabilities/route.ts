import { NextResponse } from "next/server";
import { NATIVE_CAPABILITIES } from "@/lib/native-capabilities";

export async function GET() {
  return NextResponse.json({ data: NATIVE_CAPABILITIES, meta: { nativeCount: NATIVE_CAPABILITIES.length, externalProvidersOptional: true, sourceOfTruth: "ONBOARDOS" } });
}
