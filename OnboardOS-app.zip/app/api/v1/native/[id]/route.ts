import { NextResponse } from "next/server";
import { nativeCapability, runNativeCapability } from "@/lib/server/native-engine";

export async function GET(_: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const capability = nativeCapability(id);
  if (!capability) return NextResponse.json({ error: { code: "NOT_FOUND", message: "Native capability was not found.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 404 });
  return NextResponse.json({ data: capability });
}

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const input = await request.json().catch(() => ({})) as Record<string, unknown>;
  const result = runNativeCapability(id, input);
  if (!result) return NextResponse.json({ error: { code: "NOT_FOUND", message: "Native capability was not found.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 404 });
  return NextResponse.json({ data: result });
}
