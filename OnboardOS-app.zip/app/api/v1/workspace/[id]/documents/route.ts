import { NextResponse } from "next/server";
import { demoOperatorContext } from "@/lib/server/authorization";
import { quarantineDocument } from "@/lib/server/workspace";

const allowedMimeTypes = new Set(["application/pdf", "image/png", "image/jpeg", "text/plain"]);
const maxBytes = 25 * 1024 * 1024;

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const body = await request.json().catch(() => null) as { name?: string; mimeType?: string; sizeBytes?: number } | null;
  const key = request.headers.get("idempotency-key");
  if (!key || !body?.name || !body.mimeType || typeof body.sizeBytes !== "number") return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "name, mimeType, sizeBytes, and Idempotency-Key are required.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 422 });
  if (!allowedMimeTypes.has(body.mimeType) || body.sizeBytes < 1 || body.sizeBytes > maxBytes) return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "File type or size is not allowed.", details: { allowedMimeTypes: [...allowedMimeTypes], maxBytes }, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 422 });
  try {
    const actor = demoOperatorContext();
    return NextResponse.json({ data: quarantineDocument({ organizationId: actor.organizationId, onboardingId: id, name: body.name, mimeType: body.mimeType, sizeBytes: body.sizeBytes, actorId: "demo-customer-contact", idempotencyKey: key }), meta: { request_id: crypto.randomUUID(), status: "QUARANTINED", scan_required: true } }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message === "NOT_FOUND") return NextResponse.json({ error: { code: "NOT_FOUND", message: "Onboarding was not found.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 404 });
    throw error;
  }
}
