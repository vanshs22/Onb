import { NextResponse } from "next/server";
import { customerWorkspaceProjection } from "@/lib/server/workspace";

export async function GET(_: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const projection = customerWorkspaceProjection(id);
  if (!projection) return NextResponse.json({ error: { code: "NOT_FOUND", message: "Customer workspace was not found.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 404 });
  return NextResponse.json({ data: projection, meta: { projection: "customer_safe", request_id: crypto.randomUUID() } });
}
