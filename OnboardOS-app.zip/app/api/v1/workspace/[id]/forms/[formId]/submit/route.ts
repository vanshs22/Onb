import { NextResponse } from "next/server";
import { submitForm } from "@/lib/server/workspace";
import { demoOperatorContext } from "@/lib/server/authorization";

export async function POST(request: Request, context: { params: Promise<{ id: string; formId: string }> }) {
  const { id, formId } = await context.params;
  const body = await request.json().catch(() => null) as { answers?: Record<string, unknown> } | null;
  const key = request.headers.get("idempotency-key");
  if (!key || !body?.answers || typeof body.answers !== "object" || Array.isArray(body.answers)) return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "answers and Idempotency-Key are required.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 422 });
  try {
    const actor = demoOperatorContext();
    return NextResponse.json({ data: submitForm({ organizationId: actor.organizationId, onboardingId: id, formId, answers: body.answers, idempotencyKey: key, actorId: "demo-customer-contact" }), meta: { request_id: crypto.randomUUID(), persisted: true } }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message === "NOT_FOUND") return NextResponse.json({ error: { code: "NOT_FOUND", message: "Onboarding was not found.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 404 });
    throw error;
  }
}
