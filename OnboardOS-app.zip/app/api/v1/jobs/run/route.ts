import { timingSafeEqual } from "node:crypto";
import { NextResponse } from "next/server";
import { db } from "@/lib/server/db";
import { fail } from "@/lib/server/http";
import { processDueJobs } from "@/lib/server/followups";
import { createSender } from "@/lib/server/senders";
import type { Queryable } from "@/lib/server/sql";

/** Called by Supabase pg_cron / Vercel cron every minute. Protected by CRON_SECRET. */
export async function POST(request: Request) {
  const secret = process.env.CRON_SECRET;
  const supplied = (request.headers.get("authorization") ?? "").replace(/^Bearer /, "");
  if (!secret || supplied.length !== secret.length || !timingSafeEqual(Buffer.from(supplied), Buffer.from(secret))) return fail("FORBIDDEN", "Invalid cron credentials.", 403);
  if (!db) return fail("SERVICE_UNAVAILABLE", "Database is not configured.", 503);
  const results = await processDueJobs(db as unknown as Queryable, createSender(), { secret: process.env.AUTH_SECRET ?? secret, appUrl: process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000" });
  return NextResponse.json({ data: { processed: results.length, results } });
}
