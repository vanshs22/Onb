import { NextResponse } from "next/server";
import { fail, guard } from "@/lib/server/http";
import { computeInvoice, InvoiceError, type Discount, type LineInput } from "@/lib/server/invoices";

export async function POST(request: Request) {
  const auth = await guard(request, "onboarding.read");
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => null)) as { lines?: LineInput[]; discount?: Discount } | null;
  if (!body?.lines) return fail("VALIDATION_ERROR", "lines are required.", 422);
  try { return NextResponse.json({ data: computeInvoice(body.lines, body.discount) }); }
  catch (error) { if (error instanceof InvoiceError) return fail("VALIDATION_ERROR", error.message, 422); throw error; }
}
