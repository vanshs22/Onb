import { NextResponse } from "next/server";
import { db } from "@/lib/server/db";
import { computeInvoice, InvoiceError, invoiceNumber, type Discount, type LineInput } from "@/lib/server/invoices";
import { fail, guard } from "@/lib/server/http";
import { runtimeConfig } from "@/lib/server/config";
import { withTenantTransaction } from "@/lib/server/sql";

export async function POST(request: Request) {
  const auth = await guard(request, "onboarding.write");
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => null)) as { customerId?: string; onboardingId?: string; number?: string; lines?: LineInput[]; discount?: Discount; dueAt?: string } | null;
  if (!body?.customerId || !body.lines?.length) return fail("VALIDATION_ERROR", "customerId and lines are required.", 422);
  let totals;
  try { totals = computeInvoice(body.lines, body.discount); } catch (error) { if (error instanceof InvoiceError) return fail("VALIDATION_ERROR", error.message, 422); throw error; }
  if (!db) { if (runtimeConfig().isProduction) return fail("SERVICE_UNAVAILABLE", "Database is not configured.", 503); return NextResponse.json({ data: { ...totals, status: "DRAFT", persisted: false }, meta: { demo: true } }, { status: 201 }); }
  const result = await withTenantTransaction(db, auth.actor.actorId, async (tx) => {
    const number = body.number ?? invoiceNumber(new Date().getUTCFullYear(), Math.floor(Math.random() * 900000) + 1);
    const created = (await tx.query("insert into invoices (organization_id, customer_id, onboarding_id, number, subtotal_cents, discount_cents, tax_cents, total_cents, due_at) values ($1,$2,$3,$4,$5,$6,$7,$8,$9) returning id, number, status, subtotal_cents, discount_cents, tax_cents, total_cents, due_at", [auth.actor.organizationId, body.customerId, body.onboardingId ?? null, number, totals.subtotalCents, totals.discountCents, totals.taxCents, totals.totalCents, body.dueAt ?? null])).rows[0];
    for (const item of totals.items) await tx.query("insert into invoice_items (organization_id, invoice_id, description, quantity, unit_price_cents, tax_rate_bps) values ($1,$2,$3,$4,$5,$6)", [auth.actor.organizationId, created.id, item.description, item.quantity, item.unitPriceCents, item.taxRateBps ?? 0]);
    return created;
  });
  return NextResponse.json({ data: result, meta: { persisted: true } }, { status: 201 });
}
