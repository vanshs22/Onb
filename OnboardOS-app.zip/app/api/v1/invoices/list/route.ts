import { NextResponse } from "next/server";
import { db } from "@/lib/server/db";
import { guard } from "@/lib/server/http";

export async function GET(request: Request) {
  const auth = await guard(request, "onboarding.read");
  if ("response" in auth) return auth.response;
  if (!db) return NextResponse.json({ data: [], meta: { persisted: false, demo: true } });
  const result = await db.query("select id, number, status, currency, subtotal_cents, discount_cents, tax_cents, total_cents, amount_paid_cents, due_at, paid_at, created_at from invoices where organization_id=$1 order by created_at desc", [auth.actor.organizationId]);
  return NextResponse.json({ data: result.rows, meta: { persisted: true } });
}
