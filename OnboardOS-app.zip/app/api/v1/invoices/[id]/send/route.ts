import { NextResponse } from "next/server";
import { db } from "@/lib/server/db";
import { fail, guard } from "@/lib/server/http";
import { withTenantTransaction } from "@/lib/server/sql";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const auth = await guard(request, "onboarding.write");
  if ("response" in auth) return auth.response;
  if (!db) return NextResponse.json({ data: { id, status: "SENT" }, meta: { persisted: false, demo: true } });
  const row = await withTenantTransaction(db, auth.actor.actorId, async (tx) => (await tx.query("update invoices set status='SENT' where id=$1 and organization_id=$2 and status='DRAFT' returning id, number, status", [id, auth.actor.organizationId])).rows[0]);
  return row ? NextResponse.json({ data: row, meta: { persisted: true } }) : fail("CONFLICT", "Only draft invoices can be sent.", 409);
}
