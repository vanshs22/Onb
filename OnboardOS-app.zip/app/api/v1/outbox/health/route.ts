import { NextResponse } from "next/server";
import { demoOperatorContext } from "@/lib/server/authorization";
import { outboxHealth } from "@/lib/server/outbox";

export async function GET() {
  const actor = demoOperatorContext();
  return NextResponse.json({ data: outboxHealth(actor.organizationId), meta: { organization_id: actor.organizationId } });
}
