import { NextResponse } from "next/server";
import { fail, guard } from "@/lib/server/http";
import { outboxHealth, replayOutbox } from "@/lib/server/outbox";

export async function POST(request: Request) {
  const auth = await guard(request, "workflow.execute");
  if ("response" in auth) return auth.response;
  const body = (await request.json().catch(() => ({}))) as { limit?: number };
  if (body.limit !== undefined && (!Number.isInteger(body.limit) || body.limit < 1)) return fail("VALIDATION_ERROR", "limit must be a positive integer.", 422);
  const replayed = replayOutbox(auth.actor.organizationId, Math.min(body.limit ?? 50, 100));
  return NextResponse.json({ data: replayed, meta: { health: outboxHealth(auth.actor.organizationId), replayed: replayed.length } });
}
