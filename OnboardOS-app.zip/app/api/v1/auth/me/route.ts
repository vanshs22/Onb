import { NextResponse } from "next/server";
import { AuthenticationError, authenticateRequest, identify, listMemberships } from "@/lib/server/authentication";
import { permissionsFor } from "@/lib/server/authorization";
import { db } from "@/lib/server/db";
import { toAuthResponse } from "@/lib/server/http";

export async function GET(request: Request) {
  try {
    const identity = await identify(request);
    const memberships = identity.demo || !db ? [] : await listMemberships(db as never, identity.userId);
    let actor = null;
    try { actor = await authenticateRequest(request); } catch (error) { if (!(error instanceof AuthenticationError) || error.code === "AUTHENTICATION_REQUIRED") throw error; }
    return NextResponse.json({ data: { demo: identity.demo, user: { id: identity.userId, email: typeof identity.claims.email === "string" ? identity.claims.email : null }, memberships, actor, permissions: actor ? permissionsFor(actor.role) : [] } });
  } catch (error) { const response = toAuthResponse(error); if (response) return response; throw error; }
}
