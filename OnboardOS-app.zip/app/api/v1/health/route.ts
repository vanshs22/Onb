import { NextResponse } from "next/server";
import { runtimeConfig } from "@/lib/server/config";

async function checkDatabase() {
  const config = runtimeConfig();
  if (!config.databaseUrl) return "not_configured";
  try {
    const { db } = await import("@/lib/server/db");
    if (!db) return "not_configured";
    await Promise.race([db.query("SELECT 1"), new Promise((_, reject) => setTimeout(() => reject(new Error("timeout")), 1500))]);
    return "ok";
  } catch { return "error"; }
}

export async function GET() {
  const database = await checkDatabase();
  const queue = process.env.REDIS_URL ? "configured" : "not_configured";
  const status = database === "error" ? "degraded" : "ok";
  return NextResponse.json({ data: { status, service: "onboardos-web", version: "0.1.0", timestamp: new Date().toISOString(), dependencies: { database, queue }, productionReady: status === "ok" && database === "ok" && queue === "configured" } }, { status: status === "ok" ? 200 : 503 });
}
