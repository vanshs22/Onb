import { NextResponse } from "next/server";
import { AGENT_ROSTER, CHANNEL_POLICIES, CONNECTOR_REGISTRY, PAID_ADS_ACTIVATION, SLA_POLICIES, TOOL_REGISTRY } from "@/lib/product-contracts";

export async function GET() {
  return NextResponse.json({ data: { agents: AGENT_ROSTER, tools: TOOL_REGISTRY, connectors: CONNECTOR_REGISTRY, channels: CHANNEL_POLICIES, slaPolicies: SLA_POLICIES, activationDefinitions: [PAID_ADS_ACTIVATION] }, meta: { version: 1, canonical: true } });
}
