import { NextResponse } from "next/server";
import { getCommunicationPreferences } from "@/lib/server/communication-preferences";

export async function GET(_: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  return NextResponse.json({ data: { contactId: id, preferences: getCommunicationPreferences(id) } });
}
