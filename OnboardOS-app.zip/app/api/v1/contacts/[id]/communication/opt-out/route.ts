import { NextResponse } from "next/server";
import { setOptOut } from "@/lib/server/communication-preferences";
import type { Channel } from "@/lib/product-contracts";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const body = await request.json().catch(() => null) as { channel?: Channel | "ALL" } | null;
  if (!body?.channel || !["EMAIL", "SMS", "WHATSAPP", "IN_APP", "ALL"].includes(body.channel)) return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "A valid channel or ALL is required.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 422 });
  return NextResponse.json({ data: { contactId: id, optedOut: body.channel, preferences: setOptOut(id, body.channel) }, meta: { effectiveImmediately: true, futureMessagesBlocked: true } });
}
