import { NextResponse } from "next/server";
import { canSend } from "@/lib/server/communication-preferences";
import type { Channel } from "@/lib/product-contracts";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const body = await request.json().catch(() => null) as { channel?: Channel } | null;
  if (!body?.channel) return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "channel is required.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 422 });
  return NextResponse.json({ data: canSend(id, body.channel) });
}
