import { NextResponse } from "next/server";
import { db } from "@/lib/server/db";
import { fail, guard } from "@/lib/server/http";
import { PlatformError, verifyRequirementDb } from "@/lib/server/repositories/platform-db";
import { VerificationError, verifyRequirement } from "@/lib/server/readiness";
import { withServiceTransaction } from "@/lib/server/sql";
import type { EvidenceType } from "@/lib/types";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const auth = await guard(request, "evidence.verify");
  if ("response" in auth) return auth.response;
  const idempotencyKey = request.headers.get("idempotency-key");
  const body = (await request.json().catch(() => null)) as { type?: EvidenceType; source?: string; producer?: string } | null;
  if (!idempotencyKey || !body?.type || !body.source) return fail("VALIDATION_ERROR", "Evidence type, source, and Idempotency-Key are required.", 422);
  try {
    if (db) {
      const result = await withServiceTransaction(db, (tx) => verifyRequirementDb(tx, { organizationId: auth.actor.organizationId, requirementId: id, evidenceType: body.type as string, source: body.source as string, producer: body.producer ?? "system:evidence-intake", verifier: `user:${auth.actor.actorId}`, idempotencyKey }));
      return NextResponse.json({ data: result, meta: { persisted: true, independent_verification: true } });
    }
    return NextResponse.json({ data: verifyRequirement({ organizationId: auth.actor.organizationId, requirementId: id, evidenceType: body.type, source: body.source, actorId: auth.actor.actorId, idempotencyKey }), meta: { persisted: false, demo: true } });
  } catch (error) {
    if (error instanceof PlatformError) return fail(error.code, error.message, error.code === "NOT_FOUND" ? 404 : 422);
    if (error instanceof VerificationError) return fail(error.code, error.message, error.code === "NOT_FOUND" ? 404 : error.code === "VERIFICATION_CONFLICT" ? 409 : 422);
    throw error;
  }
}
