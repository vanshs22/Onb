import { NextResponse } from "next/server";
import { activationReadiness } from "@/lib/server/operations";

export async function GET(_: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const readiness = activationReadiness(id);
  if (!readiness) return NextResponse.json({ error: { code: "NOT_FOUND", message: "Onboarding was not found.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 404 });
  return NextResponse.json({ data: readiness, meta: { activation_is_outcome: true, checklist_completion_is_not_sufficient: true } });
}
