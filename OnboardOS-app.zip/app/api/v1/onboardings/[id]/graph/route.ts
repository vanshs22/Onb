import { NextResponse } from "next/server";
import { promiseGraph } from "@/lib/server/operations";

export async function GET(_: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  return NextResponse.json({ data: { promises: promiseGraph(id), dependencies: promiseGraph(id).flatMap((promise) => promise.dependencies.map((dependency) => ({ promiseId: promise.id, dependency }))) } });
}
