import { NextResponse } from "next/server";
import { scopeComparison } from "@/lib/server/operations";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const body = await request.json().catch(() => null) as { request?: string } | null;
  if (!body?.request) return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "request is required.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 422 });
  return NextResponse.json({ data: { onboardingId: id, comparison: scopeComparison(body.request) } });
}
