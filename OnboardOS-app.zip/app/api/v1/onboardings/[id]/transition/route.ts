import { NextResponse } from "next/server";
import { runtimeConfig } from "@/lib/server/config";
import { db } from "@/lib/server/db";
import { fail, guard } from "@/lib/server/http";
import { transitionOnboardingDb } from "@/lib/server/repositories/onboarding-db";
import { withTenantTransaction } from "@/lib/server/sql";
import { transitionOnboarding, TransitionError } from "@/lib/server/transition-service";
import type { OnboardingState } from "@/lib/types";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const auth = await guard(request, "onboarding.write");
  if ("response" in auth) return auth.response;
  const { actor } = auth;
  const idempotencyKey = request.headers.get("idempotency-key");
  const body = (await request.json().catch(() => null)) as { to?: OnboardingState; version?: number } | null;
  if (!idempotencyKey || !body?.to || typeof body.version !== "number") return fail("VALIDATION_ERROR", "to, version, and Idempotency-Key are required.", 422);

  try {
    if (db) {
      const result = await withTenantTransaction(db, actor.actorId, (tx) => transitionOnboardingDb(tx, { organizationId: actor.organizationId, onboardingId: id, to: body.to as OnboardingState, expectedVersion: body.version as number, idempotencyKey, actor: { type: "USER", id: actor.actorId } }));
      return NextResponse.json({ data: result.onboarding, meta: { persisted: true, replayed: result.replayed, event_id: result.eventId } });
    }
    if (runtimeConfig().isProduction) return fail("SERVICE_UNAVAILABLE", "Database is not configured.", 503);
    const result = transitionOnboarding({ organizationId: actor.organizationId, onboardingId: id, to: body.to, expectedVersion: body.version, idempotencyKey, actor: { type: "user", id: actor.actorId } });
    return NextResponse.json({ data: result.onboarding, event: result.event, meta: { persisted: false, demo: true } });
  } catch (error) {
    if (!(error instanceof TransitionError)) throw error;
    const status = error.code === "NOT_FOUND" ? 404 : ["CONFLICT", "STATE_TRANSITION_INVALID", "IDEMPOTENCY_CONFLICT"].includes(error.code) ? 409 : 422;
    return fail(error.code, error.message, status, error.details);
  }
}
