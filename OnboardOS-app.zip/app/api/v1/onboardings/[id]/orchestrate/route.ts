import { NextResponse } from "next/server";
import { onboardingTwin, orchestrate } from "@/lib/server/orchestrator";

export async function GET(_: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const result = onboardingTwin(id);
  if (!result) return NextResponse.json({ error: { code: "NOT_FOUND", message: "Onboarding was not found.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 404 });
  return NextResponse.json({ data: result, meta: { projection: "onboarding_twin", request_id: crypto.randomUUID() } });
}

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const body = await request.json().catch(() => ({})) as { actorId?: string };
  const result = orchestrate(id, body.actorId);
  if (!result) return NextResponse.json({ error: { code: "NOT_FOUND", message: "Onboarding was not found.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 404 });
  return NextResponse.json({ data: result, meta: { loop: "objective → context → plan → tool → execute → verify → commit → handoff", request_id: crypto.randomUUID() } });
}
