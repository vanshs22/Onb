import { NextResponse } from "next/server";
import { createHandoff } from "@/lib/server/operations";

export async function POST(_: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const handoff = createHandoff(id);
  if (!handoff) return NextResponse.json({ error: { code: "NOT_FOUND", message: "Onboarding was not found.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 404 });
  return NextResponse.json({ data: handoff, meta: { approval_required: true, immutable_snapshot: true } }, { status: 201 });
}
