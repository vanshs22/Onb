import { NextResponse } from "next/server";
import { onboardings } from "@/lib/demo-data";
import { demoOperatorContext } from "@/lib/server/authorization";

export async function GET(_: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const actor = demoOperatorContext();
  const onboarding = onboardings.find((item) => item.id === id);
  if (!onboarding) return NextResponse.json({ error: { code: "NOT_FOUND", message: "Onboarding was not found.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 404 });
  return NextResponse.json({ data: onboarding.requirements, meta: { organization_id: actor.organizationId, onboarding_id: id } });
}
