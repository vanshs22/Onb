import { NextResponse } from "next/server";
import { onboardings } from "@/lib/demo-data";
import { runtimeConfig } from "@/lib/server/config";
import { db } from "@/lib/server/db";
import { fail, guard } from "@/lib/server/http";
import { createOnboardingDb, listOnboardingsDb, PlatformError } from "@/lib/server/repositories/platform-db";
import { withTenantTransaction } from "@/lib/server/sql";

export async function GET(request: Request) {
  const auth = await guard(request, "onboarding.read");
  if ("response" in auth) return auth.response;
  if (!db) return NextResponse.json({ data: onboardings, meta: { persisted: false, demo: true, count: onboardings.length } });
  const data = await withTenantTransaction(db, auth.actor.actorId, (tx) => listOnboardingsDb(tx, auth.actor.organizationId));
  return NextResponse.json({ data, meta: { persisted: true, count: data.length } });
}

export async function POST(request: Request) {
  const auth = await guard(request, "onboarding.write");
  if ("response" in auth) return auth.response;
  const key = request.headers.get("idempotency-key");
  const body = (await request.json().catch(() => null)) as { customerName?: string; externalRef?: string; title?: string; valueCents?: number; templateVersionId?: string; contact?: { name: string; email?: string; phone?: string; timezone?: string } } | null;
  if (!key || !body?.customerName || !body.title) return fail("VALIDATION_ERROR", "customerName, title and Idempotency-Key are required.", 422);
  if (body.valueCents !== undefined && (!Number.isInteger(body.valueCents) || body.valueCents < 0)) return fail("VALIDATION_ERROR", "valueCents must be a non-negative integer.", 422);
  if (!db) {
    if (runtimeConfig().isProduction) return fail("SERVICE_UNAVAILABLE", "Database is not configured.", 503);
    return NextResponse.json({ data: { onboardingId: crypto.randomUUID(), requirementCount: 0, replayed: false }, meta: { persisted: false, demo: true } }, { status: 201 });
  }
  try {
    const result = await withTenantTransaction(db, auth.actor.actorId, (tx) => createOnboardingDb(tx, { organizationId: auth.actor.organizationId, actorId: auth.actor.actorId, idempotencyKey: key, customer: { name: body.customerName as string, externalRef: body.externalRef }, title: body.title as string, valueCents: body.valueCents, templateVersionId: body.templateVersionId, contact: body.contact }));
    return NextResponse.json({ data: result, meta: { persisted: true } }, { status: result.replayed ? 200 : 201 });
  } catch (error) {
    if (error instanceof PlatformError) return fail(error.code, error.message, error.code === "NOT_FOUND" ? 404 : 422);
    throw error;
  }
}
