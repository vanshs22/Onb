import { NextResponse } from "next/server";
import { db } from "@/lib/server/db";
import { fail } from "@/lib/server/http";
import { revokeConsent, verifyUnsubscribeToken } from "@/lib/server/followups";
import { setOptOut } from "@/lib/server/communication-preferences";
import type { Queryable } from "@/lib/server/sql";
import type { Channel } from "@/lib/product-contracts";

async function unsubscribe(token: string | null) {
  const payload = token ? verifyUnsubscribeToken(token, process.env.AUTH_SECRET ?? process.env.CRON_SECRET ?? "development-only-auth-secret-change-me") : null;
  if (!payload) return fail("FORBIDDEN", "This unsubscribe link is invalid.", 403);
  if (db) await revokeConsent(db as unknown as Queryable, payload, "unsubscribe_link"); else setOptOut(payload.contactId, payload.channel as Channel, "unsubscribe_link");
  return NextResponse.json({ data: { unsubscribed: true, channel: payload.channel } });
}
// RFC 8058 one-click (POST) and link click (GET).
export async function POST(request: Request) { return unsubscribe(new URL(request.url).searchParams.get("token")); }
export async function GET(request: Request) { return unsubscribe(new URL(request.url).searchParams.get("token")); }
