import { NextResponse } from "next/server";
import { CAPABILITY_DEFAULTS, PROVIDER_CATALOG } from "@/lib/integration-catalog";

export async function GET() {
  return NextResponse.json({ data: { providers: PROVIDER_CATALOG, capabilityDefaults: CAPABILITY_DEFAULTS }, meta: { sourceOfTruth: "OnboardOS operational model", competitorProviders: ["dubsado", "bonsai", "jotform", "rocketlane", "onramp", "guidecx"] } });
}
