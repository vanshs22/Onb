import { NextResponse } from "next/server";
import { routeCapability } from "@/lib/server/integration-routing";

export async function POST(request: Request) {
  const body = await request.json().catch(() => null) as { capability?: string; preferredProvider?: string; connectedProviders?: string[] } | null;
  if (!body || !body.capability) return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "capability is required.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 422 });
  return NextResponse.json({ data: routeCapability({ capability: body.capability, preferredProvider: body.preferredProvider, connectedProviders: body.connectedProviders }) });
}
