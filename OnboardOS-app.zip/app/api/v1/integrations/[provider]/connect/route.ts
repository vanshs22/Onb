import { NextResponse } from "next/server";
import { PROVIDER_CATALOG } from "@/lib/integration-catalog";

export async function POST(_: Request, context: { params: Promise<{ provider: string }> }) {
  const { provider } = await context.params;
  const definition = PROVIDER_CATALOG.find((candidate) => candidate.id === provider);
  if (!definition) return NextResponse.json({ error: { code: "NOT_FOUND", message: "Integration provider is not supported.", details: {}, request_id: crypto.randomUUID(), retryable: false, field_errors: [] } }, { status: 404 });
  return NextResponse.json({ data: { provider: definition.id, status: definition.setup === "AVAILABLE" ? "CONNECTED" : "SETUP_REQUIRED", authModes: definition.modes, capabilities: definition.capabilities, next: definition.setup === "AVAILABLE" ? "run_health_check" : definition.modes.includes("OAUTH") ? "start_oauth_pkce" : "configure_credential_or_bridge" }, meta: { provider_is_optional: provider !== "onboardos", native_fallback_available: true } });
}
