import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "OnboardOS — Activation command center",
  description: "The AI execution layer between a signed deal and customer activation.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
