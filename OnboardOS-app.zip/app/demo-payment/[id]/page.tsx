export default async function DemoPayment({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <main style={{ minHeight: "100vh", display: "grid", placeItems: "center", background: "#f7f8fb", fontFamily: "DM Sans, sans-serif" }}><div style={{ background: "#fff", border: "1px solid #e7eaf0", borderRadius: 14, padding: 32, maxWidth: 420, textAlign: "center" }}><h1 style={{ fontSize: 20, margin: "0 0 8px" }}>Demo checkout</h1><p style={{ color: "#687386", fontSize: 13, lineHeight: 1.6 }}>Invoice {id.slice(0, 8)} would open Stripe Checkout here. No card is charged in demo mode. Configure STRIPE_SECRET_KEY to enable real payments.</p></div></main>;
}
