"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { CheckCircle2, ClipboardList, CreditCard, Plus, Receipt, Send, Sparkles, Trash2, X } from "lucide-react";
import { apiFetch } from "@/lib/client/api";
import { evaluate, validateForm, type FieldDef, type FormSchema } from "@/lib/server/forms";
import { computeInvoice, planDunning, type Discount, type LineInput } from "@/lib/server/invoices";

const money = (cents: number, currency = "USD") => new Intl.NumberFormat("en-US", { style: "currency", currency }).format(cents / 100);
const statusTone = (status: string) => (status === "PAID" ? "green" : status === "OVERDUE" || status === "VOID" ? "red" : status === "DRAFT" ? "" : "amber");

function Heading({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle: string }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p className="page-subtitle">{subtitle}</p></div></div>;
}

// ───────────────────────── Invoices ─────────────────────────
type Line = { description: string; quantity: string; price: string; tax: string };
type InvoiceRow = { id: string; number: string; status: string; currency?: string; total_cents: number | string; amount_paid_cents: number | string; due_at: string | null };

export function InvoicesView({ notify }: { notify: (message: string) => void }) {
  const [customers, setCustomers] = useState<{ id: string; name: string }[]>([]);
  const [customerId, setCustomerId] = useState("");
  const [lines, setLines] = useState<Line[]>([{ description: "Paid ads launch", quantity: "1", price: "5000", tax: "0" }]);
  const [discountKind, setDiscountKind] = useState<"none" | "percent" | "fixed">("none");
  const [discountValue, setDiscountValue] = useState("0");
  const [dueInDays, setDueInDays] = useState("14");
  const [invoices, setInvoices] = useState<InvoiceRow[]>([]);
  const [busy, setBusy] = useState(false);

  const [reload, setReload] = useState(0);
  const [today] = useState(() => Date.now());
  const load = useCallback(() => setReload((n) => n + 1), []);
  useEffect(() => {
    let cancelled = false;
    void Promise.all([apiFetch("/api/v1/customers"), apiFetch("/api/v1/invoices/list")]).then(async ([c, i]) => {
      const list = c.ok ? ((await c.json()).data as { id: string; name: string }[]) : null;
      const rows = i.ok ? ((await i.json()).data as InvoiceRow[]) : null;
      if (cancelled) return;
      if (list) { setCustomers(list); setCustomerId((current) => current || list[0]?.id || ""); }
      if (rows) setInvoices(rows);
    });
    return () => { cancelled = true; };
  }, [reload]);

  const parsed = useMemo(() => {
    try {
      const inputLines: LineInput[] = lines.map((l) => ({ description: l.description, quantity: Number(l.quantity), unitPriceCents: Math.round(Number(l.price) * 100), taxRateBps: Math.round(Number(l.tax) * 100) }));
      const discount: Discount | undefined = discountKind === "none" ? undefined : discountKind === "percent" ? { type: "PERCENT_BPS", value: Math.round(Number(discountValue) * 100) } : { type: "FIXED_CENTS", value: Math.round(Number(discountValue) * 100) };
      return { result: computeInvoice(inputLines, discount), inputLines, discount, error: "" };
    } catch (error) { return { result: null, inputLines: [] as LineInput[], discount: undefined, error: error instanceof Error ? error.message : "Invalid invoice" }; }
  }, [lines, discountKind, discountValue]);
  const dunning = useMemo(() => planDunning(new Date(today + Number(dueInDays || 0) * 86_400_000)), [dueInDays, today]);

  const update = (index: number, patch: Partial<Line>) => setLines((current) => current.map((l, i) => (i === index ? { ...l, ...patch } : l)));
  async function save() {
    if (!parsed.result) return;
    setBusy(true);
    const response = await apiFetch("/api/v1/invoices", { method: "POST", body: JSON.stringify({ customerId, lines: parsed.inputLines, discount: parsed.discount, dueAt: new Date(today + Number(dueInDays || 0) * 86_400_000).toISOString() }) });
    const body = await response.json(); setBusy(false);
    if (!response.ok) { notify(body.error?.message ?? "Could not save the invoice"); return; }
    notify(body.meta?.persisted ? `Invoice ${body.data.number} saved as draft` : "Demo mode: calculated, not saved"); load();
  }
  async function send(id: string) { const r = await apiFetch(`/api/v1/invoices/${id}/send`, { method: "POST" }); notify(r.ok ? "Invoice sent" : (await r.json()).error?.message ?? "Could not send"); load(); }
  async function pay(id: string) {
    const r = await apiFetch("/api/v1/payments/checkout", { method: "POST", headers: { "Idempotency-Key": crypto.randomUUID() }, body: JSON.stringify({ invoiceId: id }) });
    const body = await r.json();
    if (!r.ok) { notify(body.error?.message ?? "Could not create the payment link"); return; }
    notify(body.data.mode === "demo" ? "Demo payment link created (no card is charged)" : "Secure payment link opened"); window.open(body.data.url, "_blank", "noopener");
  }
  const outstanding = invoices.reduce((sum, i) => sum + (["SENT", "PARTIALLY_PAID", "OVERDUE"].includes(i.status) ? Number(i.total_cents) - Number(i.amount_paid_cents) : 0), 0);

  return <>
    <Heading eyebrow="Commercial engine" title="Invoices" subtitle="Exact-to-the-cent invoicing with automatic payment follow-up, hosted checkout, and provider-verified payment status." />
    <div className="kpi-grid">
      <div className="kpi"><div className="kpi-top"><span>Outstanding</span><span className="kpi-icon"><Receipt size={14} /></span></div><div className="kpi-number">{money(outstanding)}</div><div className="kpi-foot">Across sent and overdue invoices</div></div>
      <div className="kpi blue"><div className="kpi-top"><span>Invoices</span><span className="kpi-icon"><CreditCard size={14} /></span></div><div className="kpi-number">{invoices.length}</div><div className="kpi-foot">{invoices.filter((i) => i.status === "PAID").length} paid</div></div>
    </div>
    <div className="builder-grid">
      <section className="card">
        <div className="card-header"><div><div className="card-title">New invoice</div><div className="card-note">Totals update instantly and are re-computed by the server before saving.</div></div></div>
        <div className="builder-body">
          <div className="form-field"><label htmlFor="inv-customer">Customer</label><select id="inv-customer" value={customerId} onChange={(e) => setCustomerId(e.target.value)}>{customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
          <div className="line-head"><span>Description</span><span>Qty</span><span>Price ($)</span><span>Tax (%)</span><span /></div>
          {lines.map((l, i) => <div className="line-row" key={i}>
            <input aria-label="Description" value={l.description} onChange={(e) => update(i, { description: e.target.value })} />
            <input aria-label="Quantity" inputMode="decimal" value={l.quantity} onChange={(e) => update(i, { quantity: e.target.value })} />
            <input aria-label="Unit price" inputMode="decimal" value={l.price} onChange={(e) => update(i, { price: e.target.value })} />
            <input aria-label="Tax rate" inputMode="decimal" value={l.tax} onChange={(e) => update(i, { tax: e.target.value })} />
            <button className="icon-button" aria-label="Remove line" onClick={() => setLines((c) => c.filter((_, x) => x !== i))} disabled={lines.length === 1}><Trash2 size={14} /></button>
          </div>)}
          <button className="btn" onClick={() => setLines((c) => [...c, { description: "", quantity: "1", price: "0", tax: "0" }])}><Plus size={13} /> Add line</button>
          <div className="form-row" style={{ marginTop: 16 }}>
            <div className="form-field"><label htmlFor="inv-disc">Discount</label><div className="inline-pair"><select id="inv-disc" value={discountKind} onChange={(e) => setDiscountKind(e.target.value as typeof discountKind)}><option value="none">None</option><option value="percent">Percent</option><option value="fixed">Fixed ($)</option></select><input aria-label="Discount value" disabled={discountKind === "none"} value={discountValue} onChange={(e) => setDiscountValue(e.target.value)} /></div></div>
            <div className="form-field"><label htmlFor="inv-due">Due in (days)</label><input id="inv-due" inputMode="numeric" value={dueInDays} onChange={(e) => setDueInDays(e.target.value)} /></div>
          </div>
          {parsed.error ? <div className="auth-message" role="alert">{parsed.error}</div> : parsed.result && <div className="totals">
            <div><span>Subtotal</span><strong>{money(parsed.result.subtotalCents)}</strong></div>
            <div><span>Discount</span><strong>−{money(parsed.result.discountCents)}</strong></div>
            <div><span>Tax</span><strong>{money(parsed.result.taxCents)}</strong></div>
            <div className="grand"><span>Total due</span><strong>{money(parsed.result.totalCents)}</strong></div>
          </div>}
          <button className="btn btn-primary" style={{ marginTop: 14 }} disabled={!parsed.result || busy || !customerId} onClick={save}>{busy ? "Saving…" : "Save draft invoice"}</button>
        </div>
      </section>
      <div className="side-stack">
        <section className="card"><div className="card-header"><div><div className="card-title">Automatic payment follow-up</div><div className="card-note">Starts the moment an invoice is sent. Stops the moment it is paid.</div></div></div>
          <div className="dunning">{dunning.map((s) => <div key={s.step} className="dunning-step"><span className="timeline-dot" /><div><strong>{s.step.replace("_", " ").toLowerCase()}</strong><small>{s.runAt.toLocaleDateString()} · {s.channel.toLowerCase()} · {s.tone}</small></div></div>)}</div>
        </section>
        <section className="card"><div className="card-header"><div className="card-title">Recent invoices</div></div>
          <div className="requirements">{invoices.length === 0 && <p className="card-note" style={{ padding: "14px 0" }}>No invoices yet. Save a draft to see it here.</p>}
            {invoices.slice(0, 8).map((i) => <div className="requirement-row" key={i.id}>
              <div className="requirement-copy"><strong>{i.number}</strong><small>{money(Number(i.total_cents), i.currency?.trim() || "USD")}{i.due_at ? ` · due ${new Date(i.due_at).toLocaleDateString()}` : ""}</small></div>
              <span className={`state-pill ${statusTone(i.status)}`}>{i.status.replace("_", " ")}</span>
              {i.status === "DRAFT" && <button className="btn" onClick={() => send(i.id)}><Send size={12} /> Send</button>}
              {["SENT", "PARTIALLY_PAID", "OVERDUE"].includes(i.status) && <button className="btn btn-primary" onClick={() => pay(i.id)}><CreditCard size={12} /> Pay link</button>}
            </div>)}
          </div>
        </section>
      </div>
    </div>
  </>;
}

// ───────────────────────── Forms ─────────────────────────
const INTAKE_SCHEMA: FormSchema = { fields: [
  { id: "company", type: "text", label: "Company name", required: true },
  { id: "contact_email", type: "email", label: "Primary contact email", required: true, mapsToRequirement: "Primary contact" },
  { id: "website", type: "url", label: "Website" },
  { id: "goal", type: "select", label: "Main goal", required: true, options: ["Lead generation", "Traffic growth", "Sales growth", "Brand awareness"] },
  { id: "monthly_budget", type: "number", label: "Monthly ad budget ($)", required: true, min: 500, max: 1_000_000, mapsToRequirement: "Budget confirmed" },
  { id: "uses_crm", type: "select", label: "Do you use a CRM?", required: true, options: ["yes", "no"] },
  { id: "crm", type: "select", label: "Which CRM?", required: true, options: ["HubSpot", "Salesforce", "Pipedrive", "Other"], visibleIf: { field: "uses_crm", op: "eq", value: "yes" }, mapsToRequirement: "CRM sync" },
  { id: "platforms", type: "multiselect", label: "Ad platforms", options: ["Google Ads", "Meta Ads", "LinkedIn Ads", "TikTok Ads"] },
  { id: "has_brand_guide", type: "checkbox", label: "We have a brand guide to upload" },
  { id: "notes", type: "textarea", label: "Anything else we should know?", maxLength: 1000 },
] };

function FieldInput({ field, value, error, onChange }: { field: FieldDef; value: unknown; error?: string; onChange: (value: unknown) => void }) {
  const id = `f-${field.id}`;
  const base = { id, "aria-invalid": Boolean(error) || undefined, "aria-describedby": error ? `${id}-err` : undefined };
  let control: React.ReactNode;
  if (field.type === "select") control = <select {...base} value={String(value ?? "")} onChange={(e) => onChange(e.target.value || undefined)}><option value="">Select…</option>{field.options?.map((o) => <option key={o}>{o}</option>)}</select>;
  else if (field.type === "multiselect") control = <div className="checks">{field.options?.map((o) => { const list = (value as string[] | undefined) ?? []; return <label key={o} className="check"><input type="checkbox" checked={list.includes(o)} onChange={(e) => onChange(e.target.checked ? [...list, o] : list.filter((x) => x !== o))} />{o}</label>; })}</div>;
  else if (field.type === "checkbox") control = <label className="check"><input id={id} type="checkbox" checked={Boolean(value)} onChange={(e) => onChange(e.target.checked)} />{field.label}</label>;
  else if (field.type === "textarea") control = <textarea {...base} value={String(value ?? "")} onChange={(e) => onChange(e.target.value)} />;
  else if (field.type === "number") control = <input {...base} inputMode="decimal" value={value === undefined ? "" : String(value)} onChange={(e) => onChange(e.target.value === "" ? undefined : Number(e.target.value))} />;
  else control = <input {...base} type={field.type === "email" ? "email" : "text"} value={String(value ?? "")} onChange={(e) => onChange(e.target.value)} />;
  return <div className="form-field">{field.type !== "checkbox" && <label htmlFor={id}>{field.label}{field.required && <span className="req"> *</span>}</label>}{control}{error && <div id={`${id}-err`} className="field-error" role="alert">{error}</div>}</div>;
}

export function FormsView({ notify }: { notify: (message: string) => void }) {
  const [answers, setAnswers] = useState<Record<string, unknown>>({});
  const [showErrors, setShowErrors] = useState(false);
  const [serverResult, setServerResult] = useState<string>("");
  const [text, setText] = useState("We want more roofing leads in California and already use HubSpot.");
  const [intake, setIntake] = useState<{ goal?: string; industry?: string; market?: string; crm?: string; requirements: string[] } | null>(null);

  const visible = INTAKE_SCHEMA.fields.filter((f) => evaluate(f.visibleIf, answers));
  const live = validateForm(INTAKE_SCHEMA, Object.fromEntries(Object.entries(answers).filter(([, v]) => v !== undefined)));
  const errorFor = (id: string) => (showErrors ? live.errors.find((e) => e.field === id)?.message : undefined);
  const requiredVisible = visible.filter((f) => f.required);
  const done = requiredVisible.filter((f) => !live.errors.some((e) => e.field === f.id) && answers[f.id] !== undefined).length;
  const pct = requiredVisible.length ? Math.round((done / requiredVisible.length) * 100) : 100;

  async function submit() {
    setShowErrors(true);
    const response = await apiFetch("/api/v1/forms/validate", { method: "POST", body: JSON.stringify({ schema: INTAKE_SCHEMA, answers: Object.fromEntries(Object.entries(answers).filter(([, v]) => v !== undefined)) }) });
    const body = await response.json();
    if (response.ok) { setServerResult(`Verified by the server. Requirements satisfied: ${body.data.satisfiedRequirements.join(", ") || "none"}.`); notify("Intake validated"); }
    else setServerResult(`${body.data?.errors?.length ?? 0} field(s) need attention.`);
  }
  async function analyze() {
    const response = await apiFetch("/api/v1/intake/extract", { method: "POST", body: JSON.stringify({ text }) });
    if (response.ok) setIntake((await response.json()).data);
  }

  return <>
    <Heading eyebrow="Intake engine" title="Forms" subtitle="Conditional, server-validated intake that maps every answer to a requirement, so nothing is collected twice." />
    <div className="builder-grid">
      <section className="card">
        <div className="card-header"><div><div className="card-title">Agency intake · v1</div><div className="card-note">Fields appear and disappear as answers change. Hidden answers are never stored.</div></div><span className="state-pill green"><ClipboardList size={11} /> {pct}% complete</span></div>
        <div className="builder-body">
          <div className="progress-line" style={{ marginBottom: 18 }}><span style={{ width: `${pct}%` }} /></div>
          {visible.map((f) => <FieldInput key={f.id} field={f} value={answers[f.id]} error={errorFor(f.id)} onChange={(v) => setAnswers((a) => ({ ...a, [f.id]: v }))} />)}
          <button className="btn btn-primary" onClick={submit}><CheckCircle2 size={13} /> Validate &amp; submit</button>
          {serverResult && <p className="card-note" role="status" style={{ marginTop: 12 }}>{serverResult}</p>}
        </div>
      </section>
      <div className="side-stack">
        <section className="card"><div className="card-header"><div><div className="card-title">Smart intake</div><div className="card-note">Paste what the customer wrote. We derive goals and the requirements they imply.</div></div><Sparkles size={15} color="var(--purple)" /></div>
          <div className="builder-body"><textarea aria-label="Customer message" value={text} onChange={(e) => setText(e.target.value)} style={{ width: "100%", minHeight: 90 }} /><button className="btn" style={{ marginTop: 10 }} onClick={analyze}><Sparkles size={12} /> Analyze</button>
            {intake && <div style={{ marginTop: 14 }}><div className="chips">{[intake.goal, intake.industry, intake.market, intake.crm].filter(Boolean).map((c) => <span className="chip" key={c}>{c}</span>)}</div><p className="card-note" style={{ margin: "10px 0 6px" }}>Requirements this creates</p><div className="chips">{intake.requirements.map((r) => <span className="chip accent" key={r}>{r}</span>)}</div></div>}
          </div>
        </section>
      </div>
    </div>
  </>;
}

// ───────────────────────── New onboarding ─────────────────────────
export function NewOnboardingDialog({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [key] = useState(() => crypto.randomUUID());
  const [templates, setTemplates] = useState<{ id: string; name: string; version: number }[]>([]);
  const [form, setForm] = useState({ customerName: "", title: "", value: "", templateVersionId: "", contactName: "", contactEmail: "", timezone: Intl.DateTimeFormat().resolvedOptions().timeZone });
  const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  useEffect(() => { apiFetch("/api/v1/templates").then((r) => (r.ok ? r.json() : null)).then((b) => b?.data && setTemplates(b.data)).catch(() => undefined); }, []);
  const set = (patch: Partial<typeof form>) => setForm((f) => ({ ...f, ...patch }));
  async function submit(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError("");
    const response = await apiFetch("/api/v1/onboardings", { method: "POST", headers: { "Idempotency-Key": key }, body: JSON.stringify({ customerName: form.customerName, title: form.title, valueCents: form.value ? Math.round(Number(form.value) * 100) : 0, templateVersionId: form.templateVersionId || undefined, contact: form.contactName ? { name: form.contactName, email: form.contactEmail || undefined, timezone: form.timezone } : undefined }) });
    const body = await response.json(); setBusy(false);
    if (!response.ok) { setError(body.error?.message ?? "Could not create the onboarding."); return; }
    onCreated();
  }
  return <div className="modal-backdrop" onClick={onClose}><form className="card modal" onClick={(e) => e.stopPropagation()} onSubmit={submit} aria-label="New onboarding">
    <div className="card-header"><div><div className="card-title">New onboarding</div><div className="card-note">Requirements are generated from the template version you pick.</div></div><button type="button" className="icon-button" aria-label="Close" onClick={onClose}><X size={16} /></button></div>
    <div className="builder-body">
      <div className="form-row"><div className="form-field"><label htmlFor="n-cust">Customer</label><input id="n-cust" required value={form.customerName} onChange={(e) => set({ customerName: e.target.value })} placeholder="Acme Roofing" /></div><div className="form-field"><label htmlFor="n-title">Package</label><input id="n-title" required value={form.title} onChange={(e) => set({ title: e.target.value })} placeholder="Google Ads + SEO" /></div></div>
      <div className="form-row"><div className="form-field"><label htmlFor="n-val">Deal value ($)</label><input id="n-val" inputMode="decimal" value={form.value} onChange={(e) => set({ value: e.target.value })} placeholder="8000" /></div><div className="form-field"><label htmlFor="n-tpl">Template</label><select id="n-tpl" value={form.templateVersionId} onChange={(e) => set({ templateVersionId: e.target.value })}><option value="">No template</option>{templates.map((t) => <option key={t.id} value={t.id}>{t.name} v{t.version}</option>)}</select></div></div>
      <div className="form-row"><div className="form-field"><label htmlFor="n-cn">Contact name</label><input id="n-cn" value={form.contactName} onChange={(e) => set({ contactName: e.target.value })} /></div><div className="form-field"><label htmlFor="n-ce">Contact email</label><input id="n-ce" type="email" value={form.contactEmail} onChange={(e) => set({ contactEmail: e.target.value })} /></div></div>
      {error && <div className="auth-message" role="alert">{error}</div>}
      <button className="btn btn-primary" disabled={busy}>{busy ? "Creating…" : "Create onboarding"}</button>
    </div>
  </form></div>;
}
