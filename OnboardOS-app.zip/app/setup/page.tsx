"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, Building2 } from "lucide-react";
import { activeOrganization, apiFetch } from "@/lib/client/api";

export default function SetupPage() {
  const router = useRouter();
  const [name, setName] = useState(""); const [error, setError] = useState(""); const [loading, setLoading] = useState(false);
  async function submit(event: React.FormEvent) {
    event.preventDefault(); setLoading(true); setError("");
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const response = await apiFetch("/api/v1/organizations", { method: "POST", body: JSON.stringify({ name, timezone }) });
    const body = await response.json();
    if (!response.ok) { setError(body.error?.message ?? "Could not create the workspace."); setLoading(false); return; }
    activeOrganization.set(body.data.organizationId); router.push("/"); router.refresh();
  }
  return <main className="auth-page single"><section className="auth-form-panel"><div className="auth-form-wrap"><div className="auth-lock"><Building2 size={17} /></div><div className="eyebrow">One last step</div><h2>Name your workspace</h2><p className="auth-subtitle">This is your agency or company. You will be its owner and can invite your team next.</p><form onSubmit={submit}><label>Workspace name<input value={name} onChange={(e) => setName(e.target.value)} required maxLength={200} placeholder="Acme Media Group" /></label>{error && <div className="auth-message">{error}</div>}<button className="btn btn-primary auth-submit" disabled={loading || !name.trim()}>{loading ? "Creating…" : "Create workspace"}<ArrowRight size={14} /></button></form></div></section></main>;
}
