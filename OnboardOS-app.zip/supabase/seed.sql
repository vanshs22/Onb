-- Local development seed. Create a user via Supabase Auth, then call public.create_organization(...) as that user.
insert into public.organizations (id, name, slug, timezone)
values ('00000000-0000-4000-8000-000000000001', 'Acme Media Group', 'acme-media', 'America/Los_Angeles')
on conflict do nothing;

insert into public.onboarding_templates (id, organization_id, name, vertical)
values ('00000000-0000-4000-8000-000000000011', '00000000-0000-4000-8000-000000000001', 'Paid Ads Launch', 'Performance agency')
on conflict do nothing;

insert into public.onboarding_template_versions (id, organization_id, template_id, version, definition, published_at)
values ('00000000-0000-4000-8000-000000000012', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000011', 1,
  '{"activation":["google-ads-connected","tracking-verified","campaign-approved","campaign-live","first-valid-event"],"followUps":[24,48,72]}', now())
on conflict do nothing;
