-- Profiles are created automatically for every new Supabase Auth user, and are visible to co-members of an organization.
set check_function_bodies = off;

create or replace function app.handle_new_user() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  insert into public.profiles (id, email, display_name)
  values (new.id, coalesce(new.email, ''), coalesce(new.raw_user_meta_data ->> 'display_name', split_part(coalesce(new.email, ''), '@', 1)))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function app.handle_new_user();

create or replace function app.shares_org_with(p_user uuid) returns boolean language sql stable security definer set search_path = public, pg_temp as $$
  select exists (select 1 from memberships a join memberships b on a.organization_id = b.organization_id
    where a.user_id = auth.uid() and a.status = 'ACTIVE' and b.user_id = p_user and b.status = 'ACTIVE');
$$;
create policy profiles_coworkers on public.profiles for select to authenticated using (app.shares_org_with(id));
