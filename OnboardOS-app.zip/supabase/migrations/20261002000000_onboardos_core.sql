-- OnboardOS core schema for Supabase (PostgreSQL 15+).
-- Tenant isolation: RLS keyed on memberships (auth.uid()). Invariants (verified evidence,
-- activation proof, independent verification, consent, immutability) are enforced in the database.

create schema if not exists app;

-- Helper functions reference tables defined further down; validate bodies at call time instead.
set check_function_bodies = off;

-- ───────────── helpers ─────────────
create or replace function app.bump_version() returns trigger language plpgsql as $$
begin
  if tg_op = 'UPDATE' then new.version := old.version + 1; new.updated_at := now(); end if;
  return new;
end $$;

create or replace function app.is_member(org uuid) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select exists (select 1 from public.memberships m
    where m.organization_id = org and m.user_id = auth.uid() and m.status = 'ACTIVE');
$$;

create or replace function app.has_role(org uuid, roles text[]) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select exists (select 1 from public.memberships m
    where m.organization_id = org and m.user_id = auth.uid() and m.status = 'ACTIVE' and m.role = any(roles));
$$;

create or replace function app.contact_ids() returns setof uuid
language sql stable security definer set search_path = public, pg_temp as $$
  select contact_id from public.customer_contact_identities
  where auth_user_id = auth.uid() and verified_at is not null;
$$;

create or replace function app.contact_onboarding_ids() returns setof uuid
language sql stable security definer set search_path = public, pg_temp as $$
  select onboarding_id from public.onboarding_contacts where contact_id in (select app.contact_ids());
$$;

-- Opt-out is authoritative: a REVOKED row always blocks; EMAIL/IN_APP are allowed by default; SMS/WHATSAPP need GRANTED.
create or replace function app.can_contact(p_contact uuid, p_channel text, p_purpose text default 'ONBOARDING')
returns boolean language sql stable security definer set search_path = public, pg_temp as $$
  select case
    when exists (select 1 from channel_consents c where c.contact_id = p_contact and c.channel = p_channel and c.purpose = p_purpose and c.status = 'REVOKED') then false
    when p_channel in ('EMAIL','IN_APP') then true
    else exists (select 1 from channel_consents c where c.contact_id = p_contact and c.channel = p_channel and c.purpose = p_purpose and c.status = 'GRANTED')
  end;
$$;

-- ───────────── identity & tenancy ─────────────
create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 200),
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,62}$'),
  plan text not null default 'LAUNCH' check (plan in ('LAUNCH','PRO','OPERATIONS','ENTERPRISE')),
  timezone text not null default 'UTC',
  settings jsonb not null default '{}', branding jsonb not null default '{}',
  version integer not null default 1,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null, display_name text not null default '', created_at timestamptz not null default now()
);
create table public.memberships (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'MEMBER' check (role in ('OWNER','ADMIN','OPERATOR','MEMBER','VIEWER')),
  status text not null default 'INVITED' check (status in ('INVITED','ACTIVE','SUSPENDED')),
  created_at timestamptz not null default now(),
  unique (organization_id, user_id)
);
create index memberships_user_idx on public.memberships (user_id, status);

-- ───────────── customers & contacts ─────────────
create table public.customers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 300),
  external_ref text, metadata jsonb not null default '{}',
  version integer not null default 1,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (organization_id, id),
  unique (organization_id, external_ref)
);
create table public.customer_contacts (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  customer_id uuid not null,
  name text not null, email text, phone text, timezone text not null default 'UTC',
  is_primary boolean not null default false, version integer not null default 1,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (organization_id, id),
  foreign key (organization_id, customer_id) references public.customers (organization_id, id) on delete cascade
);
create table public.customer_contact_identities (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, contact_id uuid not null,
  auth_user_id uuid not null references auth.users(id) on delete cascade,
  verified_at timestamptz,
  unique (contact_id, auth_user_id),
  foreign key (organization_id, contact_id) references public.customer_contacts (organization_id, id) on delete cascade
);
create table public.channel_consents (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, contact_id uuid not null,
  channel text not null check (channel in ('EMAIL','SMS','WHATSAPP','IN_APP')),
  purpose text not null default 'ONBOARDING',
  status text not null check (status in ('GRANTED','REVOKED')),
  source text not null, granted_at timestamptz, revoked_at timestamptz,
  unique (contact_id, channel, purpose),
  foreign key (organization_id, contact_id) references public.customer_contacts (organization_id, id) on delete cascade
);

-- ───────────── templates (immutable once published) ─────────────
create table public.onboarding_templates (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null, vertical text,
  unique (organization_id, id), unique (organization_id, name)
);
create table public.onboarding_template_versions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, template_id uuid not null,
  version integer not null, definition jsonb not null, published_at timestamptz,
  unique (organization_id, id), unique (template_id, version),
  foreign key (organization_id, template_id) references public.onboarding_templates (organization_id, id) on delete cascade
);
create table public.forms (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null, unique (organization_id, id), unique (organization_id, name)
);
create table public.form_versions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, form_id uuid not null,
  version integer not null, schema jsonb not null, published_at timestamptz,
  unique (organization_id, id), unique (form_id, version),
  foreign key (organization_id, form_id) references public.forms (organization_id, id) on delete cascade
);

create or replace function app.block_published_change() returns trigger language plpgsql as $$
begin
  if old.published_at is not null and coalesce(current_setting('app.allow_tenant_delete', true), 'off') <> 'on' then
    raise exception 'PUBLISHED_VERSION_IMMUTABLE' using errcode = '23514';
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
create trigger template_versions_immutable before update or delete on public.onboarding_template_versions for each row execute function app.block_published_change();
create trigger form_versions_immutable before update or delete on public.form_versions for each row execute function app.block_published_change();

-- ───────────── onboarding core ─────────────
create table public.onboarding_instances (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, customer_id uuid not null, template_version_id uuid,
  owner_user_id uuid references auth.users(id) on delete set null,
  title text not null,
  state text not null default 'DRAFT' check (state in ('DRAFT','INVITED','IN_PROGRESS','AWAITING_CLIENT','AWAITING_INTERNAL','BLOCKED','READY_FOR_KICKOFF','IN_KICKOFF','IN_IMPLEMENTATION','AWAITING_APPROVAL','READY_FOR_ACTIVATION','ACTIVATED','COMPLETED','PAUSED','CANCELLED')),
  risk text not null default 'LOW' check (risk in ('LOW','MEDIUM','HIGH','CRITICAL')),
  health_score integer not null default 100 check (health_score between 0 and 100),
  value_cents bigint not null default 0 check (value_cents >= 0),
  currency char(3) not null default 'USD',
  launched_at timestamptz, activated_at timestamptz, completed_at timestamptz,
  version integer not null default 1,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (organization_id, id),
  foreign key (organization_id, customer_id) references public.customers (organization_id, id) on delete cascade,
  foreign key (organization_id, template_version_id) references public.onboarding_template_versions (organization_id, id)
);
create index onboarding_org_state_idx on public.onboarding_instances (organization_id, state, updated_at desc);
create table public.onboarding_contacts (
  organization_id uuid not null, onboarding_id uuid not null, contact_id uuid not null, role text,
  primary key (onboarding_id, contact_id),
  foreign key (organization_id, onboarding_id) references public.onboarding_instances (organization_id, id) on delete cascade,
  foreign key (organization_id, contact_id) references public.customer_contacts (organization_id, id) on delete cascade
);

create or replace function app.transition_allowed(f text, t text) returns boolean language sql immutable as $$
  select f = t or exists (select 1 from (values
    ('DRAFT','INVITED'),('DRAFT','CANCELLED'),('INVITED','IN_PROGRESS'),('INVITED','CANCELLED'),
    ('IN_PROGRESS','AWAITING_CLIENT'),('IN_PROGRESS','AWAITING_INTERNAL'),('IN_PROGRESS','BLOCKED'),('IN_PROGRESS','READY_FOR_KICKOFF'),('IN_PROGRESS','PAUSED'),('IN_PROGRESS','CANCELLED'),
    ('AWAITING_CLIENT','IN_PROGRESS'),('AWAITING_CLIENT','BLOCKED'),('AWAITING_CLIENT','PAUSED'),('AWAITING_CLIENT','CANCELLED'),
    ('AWAITING_INTERNAL','IN_PROGRESS'),('AWAITING_INTERNAL','BLOCKED'),('AWAITING_INTERNAL','PAUSED'),('AWAITING_INTERNAL','CANCELLED'),
    ('BLOCKED','IN_PROGRESS'),('BLOCKED','AWAITING_CLIENT'),('BLOCKED','AWAITING_INTERNAL'),('BLOCKED','PAUSED'),('BLOCKED','CANCELLED'),
    ('READY_FOR_KICKOFF','IN_KICKOFF'),('READY_FOR_KICKOFF','PAUSED'),('READY_FOR_KICKOFF','CANCELLED'),
    ('IN_KICKOFF','IN_IMPLEMENTATION'),('IN_KICKOFF','BLOCKED'),('IN_KICKOFF','PAUSED'),
    ('IN_IMPLEMENTATION','AWAITING_APPROVAL'),('IN_IMPLEMENTATION','BLOCKED'),('IN_IMPLEMENTATION','PAUSED'),
    ('AWAITING_APPROVAL','IN_IMPLEMENTATION'),('AWAITING_APPROVAL','READY_FOR_ACTIVATION'),('AWAITING_APPROVAL','BLOCKED'),('AWAITING_APPROVAL','PAUSED'),
    ('READY_FOR_ACTIVATION','ACTIVATED'),('READY_FOR_ACTIVATION','BLOCKED'),('READY_FOR_ACTIVATION','PAUSED'),
    ('ACTIVATED','COMPLETED'),('ACTIVATED','PAUSED'),('PAUSED','IN_PROGRESS'),('PAUSED','CANCELLED')
  ) as x(a, b) where x.a = f and x.b = t);
$$;

-- Activation is an outcome: it needs an ISSUED certificate and no open requirements.
create or replace function app.enforce_onboarding_state() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if new.state is distinct from old.state then
    if not app.transition_allowed(old.state, new.state) then
      raise exception 'STATE_TRANSITION_INVALID: % -> %', old.state, new.state using errcode = '23514';
    end if;
    if new.state = 'INVITED' then new.launched_at := coalesce(new.launched_at, now()); end if;
    if new.state = 'ACTIVATED' then
      if not exists (select 1 from activation_certificates c where c.onboarding_id = new.id and c.status = 'ISSUED') then
        raise exception 'ACTIVATION_PROOF_REQUIRED' using errcode = '23514';
      end if;
      if exists (select 1 from requirements r where r.onboarding_id = new.id and r.status not in ('SATISFIED','WAIVED')) then
        raise exception 'ACTIVATION_REQUIREMENTS_OPEN' using errcode = '23514';
      end if;
      new.activated_at := coalesce(new.activated_at, now());
    end if;
    if new.state = 'COMPLETED' then new.completed_at := coalesce(new.completed_at, now()); end if;
  end if;
  return new;
end $$;
create trigger onboarding_state_guard before update on public.onboarding_instances for each row execute function app.enforce_onboarding_state();
create trigger onboarding_version before update on public.onboarding_instances for each row execute function app.bump_version();

-- ───────────── requirements / evidence / verification ─────────────
create table public.requirements (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, onboarding_id uuid not null,
  title text not null, description text not null default '',
  owner_type text not null check (owner_type in ('CUSTOMER','INTERNAL','SYSTEM')),
  status text not null default 'MISSING' check (status in ('MISSING','IN_REVIEW','SATISFIED','BLOCKED','WAIVED')),
  stage text not null, due_at timestamptz, priority integer not null default 0,
  client_visible boolean not null default false, evidence_required boolean not null default true,
  verification_policy jsonb not null default '{}', version integer not null default 1,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (organization_id, id),
  foreign key (organization_id, onboarding_id) references public.onboarding_instances (organization_id, id) on delete cascade
);
create index requirements_org_status_idx on public.requirements (organization_id, status, due_at);
create table public.requirement_dependencies (
  organization_id uuid not null, requirement_id uuid not null, depends_on_id uuid not null,
  primary key (requirement_id, depends_on_id), check (requirement_id <> depends_on_id),
  foreign key (organization_id, requirement_id) references public.requirements (organization_id, id) on delete cascade,
  foreign key (organization_id, depends_on_id) references public.requirements (organization_id, id) on delete cascade
);
create table public.evidence (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, requirement_id uuid not null,
  type text not null check (type in ('FILE','SIGNATURE','PAYMENT','OAUTH','FORM','APPROVAL','WEBHOOK','API_RECORD','MESSAGE')),
  source text not null, producer text not null, reference text, payload jsonb not null default '{}',
  created_at timestamptz not null default now(),
  unique (organization_id, id),
  foreign key (organization_id, requirement_id) references public.requirements (organization_id, id) on delete cascade
);
create table public.verifications (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, requirement_id uuid not null, evidence_id uuid not null,
  status text not null default 'PENDING' check (status in ('PENDING','PASSED','FAILED')),
  verifier text not null, reason text, checked_at timestamptz,
  foreign key (organization_id, requirement_id) references public.requirements (organization_id, id) on delete cascade,
  foreign key (organization_id, evidence_id) references public.evidence (organization_id, id) on delete cascade
);

create or replace function app.enforce_independent_verification() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
declare v_producer text;
begin
  select producer into v_producer from evidence where id = new.evidence_id;
  if new.status = 'PASSED' then
    if new.verifier = v_producer then raise exception 'SELF_VERIFICATION_FORBIDDEN' using errcode = '23514'; end if;
    new.checked_at := coalesce(new.checked_at, now());
  end if;
  return new;
end $$;
create trigger verification_independence before insert or update on public.verifications for each row execute function app.enforce_independent_verification();

create or replace function app.enforce_requirement_verified() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if new.status = 'SATISFIED' and new.evidence_required and (tg_op = 'INSERT' or old.status is distinct from 'SATISFIED') then
    if not exists (select 1 from verifications v where v.requirement_id = new.id and v.status = 'PASSED') then
      raise exception 'REQUIREMENT_NOT_VERIFIED' using errcode = '23514';
    end if;
  end if;
  return new;
end $$;
create trigger requirement_verified_guard before insert or update on public.requirements for each row execute function app.enforce_requirement_verified();
create trigger requirement_version before update on public.requirements for each row execute function app.bump_version();

create or replace function app.prevent_dependency_cycle() returns trigger language plpgsql as $$
begin
  if exists (with recursive walk(id) as (select new.depends_on_id union select d.depends_on_id from public.requirement_dependencies d join walk w on d.requirement_id = w.id)
             select 1 from walk where id = new.requirement_id) then
    raise exception 'DEPENDENCY_CYCLE' using errcode = '23514';
  end if;
  return new;
end $$;
create trigger requirement_dependency_cycle before insert on public.requirement_dependencies for each row execute function app.prevent_dependency_cycle();

create table public.activation_certificates (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, onboarding_id uuid not null,
  status text not null default 'ISSUED' check (status in ('ISSUED','REVOKED')),
  criteria_results jsonb not null, evidence_ids uuid[] not null default '{}',
  issued_at timestamptz not null default now(),
  foreign key (organization_id, onboarding_id) references public.onboarding_instances (organization_id, id) on delete cascade
);
create unique index activation_one_issued on public.activation_certificates (onboarding_id) where status = 'ISSUED';
create or replace function app.validate_certificate() returns trigger language plpgsql as $$
begin
  if jsonb_typeof(new.criteria_results) <> 'array' or jsonb_array_length(new.criteria_results) = 0 then
    raise exception 'CERTIFICATE_CRITERIA_REQUIRED' using errcode = '23514';
  end if;
  if exists (select 1 from jsonb_array_elements(new.criteria_results) e where coalesce((e ->> 'satisfied')::boolean, false) is not true) then
    raise exception 'CERTIFICATE_CRITERIA_UNSATISFIED' using errcode = '23514';
  end if;
  return new;
end $$;
create trigger certificate_guard before insert on public.activation_certificates for each row execute function app.validate_certificate();

-- ───────────── forms, documents, approvals, exceptions ─────────────
create table public.form_submissions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, onboarding_id uuid not null, form_version_id uuid not null, contact_id uuid,
  answers jsonb not null, status text not null default 'SUBMITTED' check (status in ('DRAFT','SUBMITTED','VALIDATED','REJECTED')),
  created_at timestamptz not null default now(),
  foreign key (organization_id, onboarding_id) references public.onboarding_instances (organization_id, id) on delete cascade,
  foreign key (organization_id, form_version_id) references public.form_versions (organization_id, id)
);
create table public.documents (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, onboarding_id uuid not null, requirement_id uuid,
  name text not null, object_key text not null, mime_type text not null,
  size_bytes bigint not null check (size_bytes between 1 and 26214400), sha256 text,
  status text not null default 'QUARANTINED' check (status in ('QUARANTINED','SCANNING','CLEAN','REJECTED')),
  scan_result jsonb not null default '{}', created_at timestamptz not null default now(),
  unique (organization_id, object_key),
  foreign key (organization_id, onboarding_id) references public.onboarding_instances (organization_id, id) on delete cascade
);
create table public.approvals (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, onboarding_id uuid not null, title text not null,
  status text not null default 'PENDING' check (status in ('PENDING','APPROVED','REJECTED','CHANGES_REQUESTED','EXPIRED','CANCELLED')),
  decided_at timestamptz, comment text, expires_at timestamptz, version integer not null default 1,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  foreign key (organization_id, onboarding_id) references public.onboarding_instances (organization_id, id) on delete cascade
);
create table public.exceptions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, onboarding_id uuid not null, title text not null,
  severity text not null check (severity in ('LOW','MEDIUM','HIGH','CRITICAL')),
  status text not null default 'OPEN' check (status in ('OPEN','ACKNOWLEDGED','SNOOZED','RESOLVED')),
  impact text not null default '', recommendation text, detected_at timestamptz not null default now(), resolved_at timestamptz,
  version integer not null default 1, updated_at timestamptz not null default now(),
  foreign key (organization_id, onboarding_id) references public.onboarding_instances (organization_id, id) on delete cascade
);

-- ───────────── commercial: invoices & payments ─────────────
create table public.invoices (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, customer_id uuid not null, onboarding_id uuid,
  number text not null,
  status text not null default 'DRAFT' check (status in ('DRAFT','SENT','PARTIALLY_PAID','PAID','OVERDUE','VOID')),
  currency char(3) not null default 'USD',
  subtotal_cents bigint not null check (subtotal_cents >= 0), discount_cents bigint not null default 0 check (discount_cents >= 0),
  tax_cents bigint not null default 0 check (tax_cents >= 0), total_cents bigint not null,
  amount_paid_cents bigint not null default 0, due_at timestamptz, paid_at timestamptz,
  version integer not null default 1, created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (organization_id, id), unique (organization_id, number),
  check (total_cents = subtotal_cents - discount_cents + tax_cents),
  check (amount_paid_cents between 0 and total_cents),
  foreign key (organization_id, customer_id) references public.customers (organization_id, id) on delete cascade
);
create table public.invoice_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, invoice_id uuid not null,
  description text not null, quantity numeric(12,3) not null check (quantity > 0),
  unit_price_cents bigint not null check (unit_price_cents >= 0), tax_rate_bps integer not null default 0 check (tax_rate_bps between 0 and 10000),
  foreign key (organization_id, invoice_id) references public.invoices (organization_id, id) on delete cascade
);
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, invoice_id uuid not null,
  amount_cents bigint not null check (amount_cents > 0), provider text not null, provider_payment_id text not null,
  status text not null default 'SUCCEEDED' check (status in ('SUCCEEDED','FAILED','REFUNDED')),
  created_at timestamptz not null default now(),
  unique (provider, provider_payment_id),
  foreign key (organization_id, invoice_id) references public.invoices (organization_id, id) on delete cascade
);
-- Duplicate provider webhooks cannot double-apply (unique provider_payment_id); overpayment violates invoices check.
create or replace function app.apply_payment() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
declare v_inv public.invoices;
begin
  if new.status <> 'SUCCEEDED' then return new; end if;
  select * into v_inv from invoices where id = new.invoice_id for update;
  if v_inv.status in ('DRAFT','VOID') then raise exception 'INVOICE_NOT_PAYABLE' using errcode = '23514'; end if;
  update invoices set amount_paid_cents = amount_paid_cents + new.amount_cents,
    status = case when amount_paid_cents + new.amount_cents >= total_cents then 'PAID' else 'PARTIALLY_PAID' end,
    paid_at = case when amount_paid_cents + new.amount_cents >= total_cents then now() else paid_at end
  where id = new.invoice_id;
  return new;
end $$;
create trigger payment_apply after insert on public.payments for each row execute function app.apply_payment();
create trigger invoice_version before update on public.invoices for each row execute function app.bump_version();

-- ───────────── messaging ─────────────
create table public.messages (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, onboarding_id uuid, contact_id uuid,
  direction text not null check (direction in ('OUTBOUND','INBOUND')),
  channel text not null check (channel in ('EMAIL','SMS','WHATSAPP','IN_APP')),
  status text not null default 'QUEUED' check (status in ('DRAFT','QUEUED','SENT','DELIVERED','FAILED','RECEIVED','SUPPRESSED')),
  body text not null, idempotency_key text, provider_message_id text,
  created_at timestamptz not null default now(), sent_at timestamptz,
  foreign key (organization_id, contact_id) references public.customer_contacts (organization_id, id) on delete cascade
);
create unique index messages_idem on public.messages (organization_id, idempotency_key) where idempotency_key is not null;
create or replace function app.enforce_consent() returns trigger language plpgsql as $$
begin
  if new.direction = 'OUTBOUND' and new.contact_id is not null and new.status in ('QUEUED','SENT')
     and not app.can_contact(new.contact_id, new.channel) then
    raise exception 'CONSENT_REQUIRED_OR_OPTED_OUT' using errcode = '23514';
  end if;
  return new;
end $$;
create trigger message_consent before insert on public.messages for each row execute function app.enforce_consent();

-- ───────────── integrations, events, outbox, jobs ─────────────
create table public.integration_accounts (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  provider text not null, external_account_id text not null,
  status text not null default 'PENDING' check (status in ('PENDING','CONNECTED','ERROR','REVOKED')),
  scopes text[] not null default '{}', secret_ref text, last_health_at timestamptz,
  unique (organization_id, provider, external_account_id)
);
create table public.webhook_deliveries (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references public.organizations(id) on delete cascade,
  provider text not null, provider_event_id text not null, signature_valid boolean not null,
  payload_hash text not null, status text not null default 'RECEIVED' check (status in ('RECEIVED','PROCESSED','DUPLICATE','FAILED')),
  retry_count integer not null default 0, error text, received_at timestamptz not null default now(), processed_at timestamptz,
  unique (provider, provider_event_id)
);
create table public.events (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  aggregate_type text not null, aggregate_id uuid not null, event_type text not null, event_version integer not null default 1,
  sequence integer not null, correlation_id uuid not null default gen_random_uuid(), causation_id uuid,
  idempotency_key text not null, actor_type text not null, actor_id text, payload jsonb not null default '{}',
  occurred_at timestamptz not null default now(),
  unique (organization_id, id), unique (organization_id, idempotency_key), unique (aggregate_type, aggregate_id, sequence)
);
create table public.outbox_messages (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null, event_id uuid not null unique,
  status text not null default 'PENDING' check (status in ('PENDING','PUBLISHED','FAILED')),
  attempts integer not null default 0, available_at timestamptz not null default now(), published_at timestamptz, last_error text,
  foreign key (organization_id, event_id) references public.events (organization_id, id) on delete cascade
);
create index outbox_pending_idx on public.outbox_messages (status, available_at);
create table public.idempotency_keys (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  key text not null, request_hash text not null, status text not null default 'IN_PROGRESS' check (status in ('IN_PROGRESS','SUCCEEDED','FAILED')),
  response_code integer, response_body jsonb, expires_at timestamptz not null,
  unique (organization_id, key)
);
create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  actor_type text not null, actor_id text, action text not null, resource_type text not null, resource_id uuid,
  metadata jsonb not null default '{}', created_at timestamptz not null default now()
);
create index audit_org_idx on public.audit_logs (organization_id, created_at desc);

-- Durable scheduler (replaces in-process timers). Workers run as service_role.
create table public.scheduled_jobs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  kind text not null, run_at timestamptz not null, payload jsonb not null default '{}',
  status text not null default 'PENDING' check (status in ('PENDING','RUNNING','DONE','FAILED','CANCELLED')),
  attempts integer not null default 0, max_attempts integer not null default 5, locked_until timestamptz,
  idempotency_key text not null, result jsonb, last_error text,
  unique (organization_id, idempotency_key)
);
create index scheduled_jobs_due_idx on public.scheduled_jobs (status, run_at);

create or replace function app.claim_due_jobs(p_limit integer default 10, p_lease interval default '5 minutes')
returns setof public.scheduled_jobs language plpgsql security definer set search_path = public, pg_temp as $$
begin
  return query
  update scheduled_jobs j set status = 'RUNNING', attempts = j.attempts + 1, locked_until = now() + p_lease
  where j.id in (select s.id from scheduled_jobs s
                 where (s.status = 'PENDING' and s.run_at <= now()) or (s.status = 'RUNNING' and s.locked_until < now())
                 order by s.run_at for update skip locked limit p_limit)
  returning j.*;
end $$;
create or replace function app.complete_job(p_id uuid, p_result jsonb default '{}') returns void language sql security definer set search_path = public, pg_temp as $$
  update scheduled_jobs set status = 'DONE', result = p_result, locked_until = null where id = p_id;
$$;
create or replace function app.fail_job(p_id uuid, p_error text) returns void language sql security definer set search_path = public, pg_temp as $$
  update scheduled_jobs set last_error = p_error, locked_until = null,
    status = case when attempts >= max_attempts then 'FAILED' else 'PENDING' end,
    run_at = now() + (interval '1 minute' * power(2, least(attempts, 10)))
  where id = p_id;
$$;

-- ───────────── RPCs ─────────────
create or replace function public.create_organization(p_name text, p_slug text, p_timezone text default 'UTC')
returns uuid language plpgsql security definer set search_path = public, pg_temp as $$
declare v_org uuid; v_user uuid := auth.uid();
begin
  if v_user is null then raise exception 'AUTHENTICATION_REQUIRED' using errcode = '28000'; end if;
  insert into organizations (name, slug, timezone) values (p_name, p_slug, p_timezone) returning id into v_org;
  insert into memberships (organization_id, user_id, role, status) values (v_org, v_user, 'OWNER', 'ACTIVE');
  insert into audit_logs (organization_id, actor_type, actor_id, action, resource_type, resource_id) values (v_org, 'USER', v_user::text, 'organization.created', 'organization', v_org);
  return v_org;
end $$;

-- Portal contacts opt out / in without needing staff access.
create or replace function public.set_channel_consent(p_contact uuid, p_channel text, p_status text, p_source text default 'portal')
returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare v_org uuid;
begin
  select organization_id into v_org from customer_contacts where id = p_contact;
  if v_org is null or not (p_contact in (select app.contact_ids()) or app.has_role(v_org, array['OWNER','ADMIN','OPERATOR'])) then
    raise exception 'FORBIDDEN' using errcode = '42501';
  end if;
  insert into channel_consents (organization_id, contact_id, channel, status, source, granted_at, revoked_at)
  values (v_org, p_contact, p_channel, p_status, p_source, case when p_status = 'GRANTED' then now() end, case when p_status = 'REVOKED' then now() end)
  on conflict (contact_id, channel, purpose) do update
    set status = excluded.status, source = excluded.source,
        granted_at = case when excluded.status = 'GRANTED' then now() else channel_consents.granted_at end,
        revoked_at = case when excluded.status = 'REVOKED' then now() else channel_consents.revoked_at end;
end $$;

-- ───────────── Row Level Security ─────────────
do $$
declare t text;
  rw text[] := array['customers','customer_contacts','channel_consents','onboarding_templates','onboarding_template_versions','onboarding_instances',
    'onboarding_contacts','requirements','requirement_dependencies','evidence','forms','form_versions','form_submissions','documents','invoices',
    'invoice_items','messages','approvals','exceptions','integration_accounts','idempotency_keys'];
  insert_only text[] := array['events','audit_logs','outbox_messages'];
  read_only text[] := array['verifications','payments','activation_certificates','scheduled_jobs','webhook_deliveries'];
  w text := 'array[''OWNER'',''ADMIN'',''OPERATOR'',''MEMBER'']';
begin
  foreach t in array rw || insert_only || read_only loop
    execute format('alter table public.%I enable row level security', t);
    execute format('alter table public.%I force row level security', t);
    execute format('create policy %I on public.%I for select to authenticated using (app.is_member(organization_id))', t || '_select', t);
  end loop;
  foreach t in array rw || insert_only loop
    execute format('create policy %I on public.%I for insert to authenticated with check (app.has_role(organization_id, %s))', t || '_insert', t, w);
  end loop;
  foreach t in array rw loop
    execute format('create policy %I on public.%I for update to authenticated using (app.has_role(organization_id, %s)) with check (app.has_role(organization_id, %s))', t || '_update', t, w, w);
    execute format('create policy %I on public.%I for delete to authenticated using (app.has_role(organization_id, array[''OWNER'',''ADMIN'']))', t || '_delete', t);
  end loop;
end $$;

alter table public.organizations enable row level security; alter table public.organizations force row level security;
alter table public.memberships enable row level security; alter table public.memberships force row level security;
alter table public.profiles enable row level security; alter table public.profiles force row level security;
alter table public.customer_contact_identities enable row level security; alter table public.customer_contact_identities force row level security;
create policy organizations_select on public.organizations for select to authenticated using (app.is_member(id));
create policy organizations_update on public.organizations for update to authenticated using (app.has_role(id, array['OWNER','ADMIN'])) with check (app.has_role(id, array['OWNER','ADMIN']));
create policy memberships_select on public.memberships for select to authenticated using (user_id = auth.uid() or app.is_member(organization_id));
create policy memberships_manage on public.memberships for all to authenticated using (app.has_role(organization_id, array['OWNER','ADMIN'])) with check (app.has_role(organization_id, array['OWNER','ADMIN']));
create policy profiles_self on public.profiles for all to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy identities_select on public.customer_contact_identities for select to authenticated using (auth_user_id = auth.uid() or app.is_member(organization_id));
create policy identities_manage on public.customer_contact_identities for all to authenticated using (app.has_role(organization_id, array['OWNER','ADMIN','OPERATOR'])) with check (app.has_role(organization_id, array['OWNER','ADMIN','OPERATOR']));

-- Customer portal: contacts see only their onboarding, client-visible requirements, their invoices; can submit forms/documents.
create policy onboarding_portal_select on public.onboarding_instances for select to authenticated using (id in (select app.contact_onboarding_ids()));
create policy requirements_portal_select on public.requirements for select to authenticated using (client_visible and onboarding_id in (select app.contact_onboarding_ids()));
create policy invoices_portal_select on public.invoices for select to authenticated using (status <> 'DRAFT' and onboarding_id in (select app.contact_onboarding_ids()));
create policy approvals_portal_select on public.approvals for select to authenticated using (onboarding_id in (select app.contact_onboarding_ids()));
create policy submissions_portal_insert on public.form_submissions for insert to authenticated with check (status in ('DRAFT','SUBMITTED') and onboarding_id in (select app.contact_onboarding_ids()) and contact_id in (select app.contact_ids()));
create policy documents_portal_insert on public.documents for insert to authenticated with check (status = 'QUARANTINED' and onboarding_id in (select app.contact_onboarding_ids()));
create policy consents_portal_select on public.channel_consents for select to authenticated using (contact_id in (select app.contact_ids()));

-- ───────────── grants ─────────────
revoke all on all tables in schema public from anon;
grant usage on schema app to authenticated, service_role;
grant select, insert, update, delete on all tables in schema public to authenticated;
revoke update, delete on public.events, public.audit_logs from authenticated;
revoke insert, update, delete on public.verifications, public.payments, public.activation_certificates, public.scheduled_jobs, public.webhook_deliveries from authenticated;
grant all on all tables in schema public to service_role;
revoke execute on function app.claim_due_jobs(integer, interval), app.complete_job(uuid, jsonb), app.fail_job(uuid, text) from public, authenticated;
grant execute on function app.claim_due_jobs(integer, interval), app.complete_job(uuid, jsonb), app.fail_job(uuid, text) to service_role;
grant execute on function public.create_organization(text, text, text), public.set_channel_consent(uuid, text, text, text) to authenticated;
