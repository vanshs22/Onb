const required = ["AUTH_SECRET", "DATABASE_URL", "REDIS_URL"];
const providerOptional = ["STRIPE_SECRET_KEY", "STRIPE_WEBHOOK_SECRET", "GOOGLE_CLIENT_ID", "HUBSPOT_CLIENT_ID"];
const missing = required.filter((key) => !process.env[key]);
const weak = process.env.AUTH_SECRET && process.env.AUTH_SECRET.length < 32;
if (process.env.NODE_ENV === "production" && (missing.length || weak || process.env.ONBOARDOS_DEMO_MODE === "true")) {
  console.error(JSON.stringify({ ok: false, missing, weakAuthSecret: Boolean(weak), demoMode: process.env.ONBOARDOS_DEMO_MODE === "true", message: "Production configuration is incomplete." }, null, 2));
  process.exit(1);
}
console.log(JSON.stringify({ ok: true, missingOptional: providerOptional.filter((key) => !process.env[key]), demoMode: process.env.ONBOARDOS_DEMO_MODE !== "false" }, null, 2));
