// Full-stack end-to-end suite. Real Next.js production server + real Postgres (PGlite over TCP, all migrations)
// + local stand-ins for Supabase Auth and Stripe HTTP APIs + a real browser. No external credentials needed.
import { execFileSync, spawn } from "node:child_process";
import { readdirSync, readFileSync } from "node:fs";
import http from "node:http";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { PGlite } from "@electric-sql/pglite";
import { PGLiteSocketServer } from "@electric-sql/pglite-socket";
import { SignJWT } from "jose";
import Stripe from "stripe";

const P = { app: 3200, db: 54329, auth: 54330, stripe: 54331 };
const APP = `http://localhost:${P.app}`;
const SHOTS = "/projects/sandbox/.kiro/artifacts/screenshots";
const SUPABASE_SECRET = "e2e-supabase-jwt-secret-e2e-supabase-jwt-secret";
const AUTH_SECRET = "e2e-internal-auth-secret-e2e-internal-auth-secret";
const WEBHOOK_SECRET = "whsec_e2e_secret";
const CRON_SECRET = "e2e-cron-secret-e2e-cron-secret-123456";
const PASSWORD = "Str0ng-pass-phrase!";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const results = [];
const children = [];

// ───────── real database ─────────
const pg = new PGlite();
await pg.exec(`create schema auth; create table auth.users (id uuid primary key default gen_random_uuid(), email text, raw_user_meta_data jsonb not null default '{}');
  create function auth.jwt() returns jsonb language sql stable as $$ select coalesce(nullif(current_setting('request.jwt.claims', true), ''), '{}')::jsonb $$;
  create function auth.uid() returns uuid language sql stable as $$ select nullif(auth.jwt() ->> 'sub', '')::uuid $$;
  create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
  grant usage on schema auth to anon, authenticated, service_role; grant usage on schema public to anon, authenticated, service_role;`);
for (const f of readdirSync("supabase/migrations").sort()) await pg.exec(readFileSync(path.join("supabase/migrations", f), "utf8"));
const dbServer = new PGLiteSocketServer({ db: pg, port: P.db, host: "127.0.0.1" });
await dbServer.start();
const rows = async (sql, params = []) => (await pg.query(sql, params)).rows;

// ───────── Supabase Auth stand-in ─────────
const users = new Map(); const tokens = new Map();
const userJson = (u) => ({ id: u.id, aud: "authenticated", role: "authenticated", email: u.email, email_confirmed_at: new Date().toISOString(), app_metadata: { provider: "email" }, user_metadata: u.meta, identities: [], created_at: new Date().toISOString(), updated_at: new Date().toISOString() });
async function session(u) {
  const now = Math.floor(Date.now() / 1000);
  const access = await new SignJWT({ email: u.email, role: "authenticated", aal: "aal1", session_id: randomUUID() }).setProtectedHeader({ alg: "HS256" }).setSubject(u.id).setAudience("authenticated").setIssuedAt(now).setExpirationTime(now + 3600).sign(new TextEncoder().encode(SUPABASE_SECRET));
  tokens.set(u.email, access);
  return { access_token: access, token_type: "bearer", expires_in: 3600, expires_at: now + 3600, refresh_token: `rt_${u.id}`, user: userJson(u) };
}
async function signUpUser(email, password, meta = {}) {
  if (users.has(email)) return null;
  const id = (await rows("insert into auth.users (email, raw_user_meta_data) values ($1,$2) returning id", [email, JSON.stringify(meta)]))[0].id;
  const u = { id, email, password, meta }; users.set(email, u); return u;
}
const authServer = http.createServer(async (req, res) => {
  const cors = { "access-control-allow-origin": "*", "access-control-allow-headers": "authorization, apikey, content-type, x-client-info, x-supabase-api-version", "access-control-allow-methods": "GET,POST,PUT,DELETE,OPTIONS" };
  const send = (status, body) => { res.writeHead(status, { ...cors, "content-type": "application/json" }); res.end(body === undefined ? "" : JSON.stringify(body)); };
  if (req.method === "OPTIONS") return send(204);
  let raw = ""; for await (const chunk of req) raw += chunk;
  const body = raw ? JSON.parse(raw) : {}; const url = new URL(req.url, "http://x");
  if (url.pathname === "/auth/v1/signup") { const u = await signUpUser(body.email, body.password, body.data ?? {}); return u ? send(200, await session(u)) : send(422, { code: 422, error_code: "user_already_exists", msg: "User already registered" }); }
  if (url.pathname === "/auth/v1/token" && url.searchParams.get("grant_type") === "password") { const u = users.get(body.email); return u && u.password === body.password ? send(200, await session(u)) : send(400, { code: 400, error_code: "invalid_credentials", msg: "Invalid login credentials" }); }
  if (url.pathname === "/auth/v1/token" && url.searchParams.get("grant_type") === "refresh_token") { const u = [...users.values()].find((x) => `rt_${x.id}` === body.refresh_token); return u ? send(200, await session(u)) : send(400, { code: 400, error_code: "refresh_token_not_found", msg: "Invalid refresh token" }); }
  if (url.pathname === "/auth/v1/user") { const token = (req.headers.authorization ?? "").replace("Bearer ", ""); const u = [...users.values()].find((x) => tokens.get(x.email) === token); return u ? send(200, userJson(u)) : send(401, { code: 401, msg: "invalid JWT" }); }
  if (url.pathname === "/auth/v1/logout") return send(204);
  return send(404, { msg: "not found" });
});
await new Promise((r) => authServer.listen(P.auth, r));

// ───────── Stripe stand-in (records what the app asks Stripe to charge) ─────────
const stripeCalls = [];
const stripeServer = http.createServer(async (req, res) => {
  let raw = ""; for await (const chunk of req) raw += chunk;
  const form = Object.fromEntries(new URLSearchParams(raw));
  stripeCalls.push({ path: req.url, form, idempotencyKey: req.headers["idempotency-key"] });
  res.writeHead(200, { "content-type": "application/json" });
  res.end(JSON.stringify({ id: `cs_test_e2e_${stripeCalls.length}`, object: "checkout.session", url: `${APP}/demo-payment/stripe-hosted-${stripeCalls.length}`, status: "open" }));
});
await new Promise((r) => stripeServer.listen(P.stripe, r));

// ───────── app ─────────
const env = { ...process.env, NEXT_PUBLIC_SUPABASE_URL: `http://localhost:${P.auth}`, NEXT_PUBLIC_SUPABASE_ANON_KEY: "e2e-anon-key", SUPABASE_JWT_SECRET: SUPABASE_SECRET, AUTH_SECRET, CRON_SECRET,
  DATABASE_URL: `postgres://postgres:postgres@127.0.0.1:${P.db}/postgres`, DATABASE_POOL_MAX: "1", STRIPE_SECRET_KEY: "sk_test_e2e_key", STRIPE_WEBHOOK_SECRET: WEBHOOK_SECRET, STRIPE_API_BASE: `http://127.0.0.1:${P.stripe}`, NEXT_PUBLIC_APP_URL: APP, NODE_ENV: "production" };
delete env.ONBOARDOS_DEMO_MODE;

// ───────── helpers ─────────
const browser = (...args) => execFileSync("agent-browser", ["--session", "e2e", ...args], { encoding: "utf8", timeout: 60_000 });
const parse = (out) => { const t = out.trim(); try { let v = JSON.parse(t); if (typeof v === "string") { try { v = JSON.parse(v); } catch { /* plain string */ } } return v; } catch { return t; } };
const js = (code) => parse(browser("eval", code));
async function waitFor(code, label, timeout = 25_000) {
  const start = Date.now(); let last;
  while (Date.now() - start < timeout) { try { last = js(code); if (last && last !== "null" && last !== "false") return last; } catch (e) { last = String(e.message).slice(0, 120); } await sleep(350); }
  throw new Error(`Timed out waiting for ${label}; last=${JSON.stringify(last)}`);
}
const setValue = (selector, value) => js(`(() => { const el = document.querySelector(${JSON.stringify(selector)}); if (!el) return false; const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, ${JSON.stringify(value)}); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); return true; })()`);
const selectByText = (selector, text) => js(`(() => { const el = document.querySelector(${JSON.stringify(selector)}); const o = el && [...el.options].find((x) => x.textContent.includes(${JSON.stringify(text)})); if (!o) return false; Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').set.call(el, o.value); el.dispatchEvent(new Event('change', { bubbles: true })); return true; })()`);
const clickText = (text, scope = "button") => js(`(() => { const el = [...document.querySelectorAll(${JSON.stringify(scope)})].find((e) => e.textContent.trim().includes(${JSON.stringify(text)})); if (!el) return false; el.click(); return true; })()`);
const has = (text) => `document.body.innerText.toLowerCase().includes(${JSON.stringify(text.toLowerCase())})`;
const pathIs = (p) => `location.pathname === ${JSON.stringify(p)}`;
const shot = (name) => { try { browser("screenshot", `${SHOTS}/e2e-${name}.png`); } catch { /* best effort */ } };
async function api(pathname, { method = "GET", token, org, body, headers = {} } = {}) {
  const res = await fetch(APP + pathname, { method, headers: { ...(token ? { authorization: `Bearer ${token}` } : {}), ...(org ? { "x-organization-id": org } : {}), ...(body ? { "content-type": "application/json" } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
  let json = null; try { json = await res.json(); } catch { /* no body */ }
  return { status: res.status, body: json };
}
const expect = (cond, message) => { if (!cond) throw new Error(message); };
async function step(name, fn) {
  const t = Date.now();
  try { await fn(); results.push({ name, ok: true }); console.log(`  ✓ ${name} (${Date.now() - t}ms)`); }
  catch (error) { results.push({ name, ok: false, error: error.message }); console.log(`  ✗ ${name}\n      ${error.message}`); try { shot(`FAIL-${results.length}`); } catch { /* ignore */ } }
}
const goodTimezone = ["UTC", "America/Los_Angeles", "Asia/Tokyo", "Europe/London", "Australia/Sydney", "Asia/Kolkata"].find((tz) => { const h = Number(new Intl.DateTimeFormat("en-US", { hour: "numeric", hourCycle: "h23", timeZone: tz }).format(new Date())); return h >= 9 && h < 19; }) ?? "UTC";

// ───────── run ─────────
let ctx = {};
try {
  console.log("Building app with Supabase settings…");
  execFileSync("npm", ["run", "build"], { env, stdio: "pipe", timeout: 300_000 });
  const app = spawn("node", ["node_modules/next/dist/bin/next", "start", "-p", String(P.app)], { env, stdio: "pipe" }); children.push(app);
  let appLog = ""; app.stdout.on("data", (d) => (appLog += d)); app.stderr.on("data", (d) => (appLog += d));
  for (let i = 0; i < 60; i++) { try { if ((await fetch(APP + "/login")).ok) break; } catch { /* starting */ } await sleep(500); }
  console.log("\nAuthentication & access control");

  await step("anonymous and forged API calls are rejected", async () => {
    expect((await api("/api/v1/onboardings")).status === 401, "anonymous should be 401");
    expect((await api("/api/v1/onboardings", { token: "aaa.bbb.ccc" })).status === 401, "forged token should be 401");
    expect((await api("/api/v1/auth/me")).status === 401, "/auth/me anonymous should be 401");
  });
  await step("visiting the app signed-out redirects to /login", async () => {
    browser("open", APP + "/"); await waitFor(pathIs("/login"), "redirect to /login"); shot("01-login");
  });
  await step("wrong credentials show a clear error and do not sign in", async () => {
    setValue('input[type="email"]', "nobody@e2e.test"); setValue('input[type="password"]', "wrong-password-1");
    clickText("Sign in", "button.auth-submit"); await waitFor(has("Invalid login credentials"), "error message");
    expect(js(pathIs("/login")), "should remain on /login");
  });
  await step("sign up creates the account and routes to workspace setup", async () => {
    browser("open", APP + "/signup"); await waitFor('!!document.querySelector(\'input[type="password"]\')', "signup form"); shot("02-signup");
    setValue('input[placeholder="Maya Chen"]', "Maya Chen"); setValue('input[type="email"]', "maya@e2e.test"); setValue('input[type="password"]', PASSWORD);
    clickText("Create workspace", "button.auth-submit"); await waitFor(pathIs("/setup"), "redirect to /setup");
    expect((await rows("select display_name from profiles where email='maya@e2e.test'"))[0]?.display_name === "Maya Chen", "profile should be created from signup metadata");
  });
  await step("workspace setup makes the user OWNER and opens the dashboard", async () => {
    shot("03-setup"); setValue("input[maxlength]", "E2E Media Group"); clickText("Create workspace", "button.auth-submit");
    await waitFor(pathIs("/") + " && " + has("Command center"), "dashboard after setup");
    const [m] = await rows("select m.role, m.status, o.name, o.id from memberships m join organizations o on o.id=m.organization_id");
    expect(m.role === "OWNER" && m.status === "ACTIVE" && m.name === "E2E Media Group", `unexpected membership ${JSON.stringify(m)}`);
    ctx.org = m.id; ctx.token = tokens.get("maya@e2e.test");
    await waitFor(has("E2E Media Group"), "the real workspace name in the sidebar (not a hardcoded one)");
    await waitFor(has("Sample data"), "sample-data label on the unconnected Overview"); shot("04-dashboard");
  });

  console.log("\nOnboarding from deal to requirements");
  await step("seed a published template (as an admin would)", async () => {
    const tpl = (await rows("insert into onboarding_templates (organization_id, name) values ($1,'Paid Ads Launch') returning id", [ctx.org]))[0].id;
    await rows("insert into onboarding_template_versions (organization_id, template_id, version, definition, published_at) values ($1,$2,1,$3, now())", [ctx.org, tpl, JSON.stringify({ requirements: [{ title: "Sign agreement", owner: "CUSTOMER", stage: "Commercial", clientVisible: true, dueInHours: 24 }, { title: "Google Ads access", description: "Admin access to the ad account", owner: "CUSTOMER", stage: "Access", clientVisible: true }, { title: "Kickoff call", owner: "INTERNAL", stage: "Kickoff" }] })]);
  });
  await step("New onboarding dialog creates customer, contact, onboarding and template requirements", async () => {
    expect(clickText("Onboardings", ".nav-button"), "nav"); await waitFor(has("Execution pipeline") + " || " + has("EXECUTION PIPELINE"), "onboardings page");
    expect(clickText("New onboarding"), "new onboarding button"); await waitFor('!!document.querySelector("#n-cust")', "dialog");
    await waitFor('[...document.querySelectorAll("#n-tpl option")].some(o => o.textContent.includes("Paid Ads Launch"))', "template option");
    setValue("#n-cust", "E2E Roofing Co"); setValue("#n-title", "Google Ads + SEO"); setValue("#n-val", "8000"); selectByText("#n-tpl", "Paid Ads Launch"); setValue("#n-cn", "Pat Lee"); setValue("#n-ce", "pat@roofing.test");
    shot("05-new-onboarding"); clickText("Create onboarding", "form button"); await waitFor(has("E2E Roofing Co"), "new row in table");
    const [o] = await rows("select o.id, o.value_cents, o.state, (select count(*) from requirements r where r.onboarding_id=o.id) as reqs, (select count(*) from customer_contacts) as contacts from onboarding_instances o");
    expect(o.value_cents === 800000 && o.state === "DRAFT" && Number(o.reqs) === 3 && Number(o.contacts) === 1, `unexpected onboarding ${JSON.stringify(o)}`);
    ctx.onb = o.id;
  });
  await step("opening the onboarding shows the generated requirements and real progress", async () => {
    js(`(() => { const row = [...document.querySelectorAll("tbody tr")].find(r => r.textContent.includes("E2E Roofing Co")); row.querySelector("button").click(); return true; })()`);
    await waitFor(has("Sign agreement") + " || " + has("Readiness overview"), "drawer"); shot("06-onboarding-drawer");
    js(`(() => { const o = [...document.querySelectorAll("div")].find(d => d.style.position === "fixed" && d.style.zIndex === "5"); o && o.click(); return true; })()`);
  });
  await step("the API enforces the state machine and version conflicts against the real database", async () => {
    const go = (to, version, key) => api(`/api/v1/onboardings/${ctx.onb}/transition`, { method: "POST", token: ctx.token, body: { to, version }, headers: { "idempotency-key": key } });
    const ok = await go("INVITED", 1, "e2e-t1"); expect(ok.status === 200 && ok.body.data.version === 2, `transition failed ${JSON.stringify(ok)}`);
    const replay = await go("INVITED", 1, "e2e-t1"); expect(replay.status === 200 && replay.body.meta.replayed === true, "identical retry should replay");
    expect((await go("INVITED", 1, "e2e-t2")).status === 409, "stale version should be 409");
    expect((await go("COMPLETED", 2, "e2e-t3")).status === 409, "invalid transition should be 409");
    expect((await go("ACTIVATED", 2, "e2e-t4")).status === 409, "ACTIVATED from INVITED should be 409");
    expect(Number((await rows("select count(*) as n from events where aggregate_id=$1", [ctx.onb]))[0].n) === 2, "exactly two events (created + one transition)");
  });

  console.log("\nInvoices & payments");
  await step("invoice builder computes exact totals and saves a draft", async () => {
    expect(clickText("Invoices", ".nav-button"), "nav"); await waitFor('[...document.querySelectorAll("#inv-customer option")].some(o => o.textContent.includes("E2E Roofing Co"))', "customer list");
    setValue('input[aria-label="Description"]', "Google Ads launch"); setValue('input[aria-label="Unit price"]', "5000"); setValue('input[aria-label="Tax rate"]', "8.25");
    await waitFor(has("$5,412.50"), "live total $5,412.50"); shot("07-invoices");
    clickText("Save draft invoice"); await waitFor(has("INV-"), "invoice in list");
    const [inv] = await rows("select id, status, subtotal_cents, tax_cents, total_cents from invoices"); ctx.invoice = inv.id;
    expect(inv.status === "DRAFT" && inv.subtotal_cents === 500000 && inv.tax_cents === 41250 && inv.total_cents === 541250, `bad invoice ${JSON.stringify(inv)}`);
  });
  await step("a draft invoice cannot be paid; sending it enables the payment link", async () => {
    expect((await api("/api/v1/payments/checkout", { method: "POST", token: ctx.token, body: { invoiceId: ctx.invoice }, headers: { "idempotency-key": "e2e-pay-0" } })).status === 409, "draft checkout should be 409");
    expect(clickText("Send"), "send button"); await waitFor('[...document.querySelectorAll("button")].some(b => b.textContent.includes("Pay link"))', "Pay link button after send");
  });
  await step("pay link asks Stripe for the amount stored in the database, ignoring any client-supplied amount", async () => {
    const forged = await api("/api/v1/payments/checkout", { method: "POST", token: ctx.token, body: { invoiceId: ctx.invoice, amountCents: 100 }, headers: { "idempotency-key": "e2e-pay-1" } });
    expect(forged.status === 201, `checkout failed ${JSON.stringify(forged)}`);
    const call = stripeCalls.at(-1);
    expect(call.form["line_items[0][price_data][unit_amount]"] === "541250", `Stripe was asked to charge ${call.form["line_items[0][price_data][unit_amount]"]}`);
    expect(call.form["metadata[invoiceId]"] === ctx.invoice && call.form["metadata[organizationId]"] === ctx.org, "metadata must bind payment to invoice and workspace");
    expect(call.idempotencyKey === "e2e-pay-1", "idempotency key forwarded to Stripe");
    js("(() => { window.__opened = null; window.open = (u) => { window.__opened = u; return null; }; return true; })()");
    expect(clickText("Pay link"), "pay link button"); const opened = await waitFor("window.__opened", "payment page opened");
    expect(String(opened).includes("/demo-payment/stripe-hosted"), `the browser was sent to ${opened}`);
  });
  await step("a signed Stripe webhook marks the invoice PAID exactly once", async () => {
    const event = { id: "evt_e2e_1", object: "event", type: "checkout.session.completed", data: { object: { id: "cs_test_e2e_1", payment_status: "paid", payment_intent: "pi_e2e_1", amount_total: 541250, metadata: { invoiceId: ctx.invoice, organizationId: ctx.org } } } };
    const payload = JSON.stringify(event); const header = Stripe.webhooks.generateTestHeaderString({ payload, secret: WEBHOOK_SECRET });
    const post = (body, sig) => fetch(APP + "/api/v1/payments/webhook", { method: "POST", headers: { "stripe-signature": sig, "content-type": "application/json" }, body }).then(async (r) => ({ status: r.status, body: await r.json() }));
    expect((await post(payload, "t=1,v1=deadbeef")).status === 401, "forged signature should be 401");
    expect((await post(payload.replace("541250", "1"), header)).status === 401, "tampered payload should be 401");
    const first = await post(payload, header); expect(first.status === 200 && first.body.outcome.status === "APPLIED", `webhook ${JSON.stringify(first)}`);
    const replay = await post(payload, header); expect(replay.body.outcome.status === "DUPLICATE", "redelivery should be DUPLICATE");
    const [inv] = await rows("select status, amount_paid_cents, paid_at is not null as stamped from invoices where id=$1", [ctx.invoice]);
    expect(inv.status === "PAID" && inv.amount_paid_cents === 541250 && inv.stamped, `invoice ${JSON.stringify(inv)}`);
    expect(Number((await rows("select count(*) as n from payments"))[0].n) === 1, "one payment row");
  });
  await step("the UI reflects the payment and offers no further payment link", async () => {
    clickText("Forms", ".nav-button"); await waitFor(has("Agency intake"), "forms page"); clickText("Invoices", ".nav-button");
    await waitFor(has("PAID"), "PAID status in UI"); expect(!js(`[...document.querySelectorAll("button")].some(b => b.textContent.includes("Pay link"))`), "no pay link on a paid invoice"); shot("08-invoice-paid");
    expect((await api("/api/v1/payments/checkout", { method: "POST", token: ctx.token, body: { invoiceId: ctx.invoice }, headers: { "idempotency-key": "e2e-pay-2" } })).status === 409, "paid invoice checkout should be 409");
  });

  console.log("\nForms & intake");
  await step("conditional fields appear only when relevant and validation is enforced by the server", async () => {
    clickText("Forms", ".nav-button"); await waitFor(has("Agency intake"), "forms page");
    expect(!js(has("Which CRM?")), "CRM field hidden initially");
    setValue("#f-uses_crm", "yes"); await waitFor(has("Which CRM?"), "CRM field revealed");
    clickText("Validate & submit"); await waitFor(has("need attention"), "server rejection message"); shot("09-forms-errors");
    setValue("#f-company", "E2E Roofing Co"); setValue("#f-contact_email", "pat@roofing.test"); selectByText("#f-goal", "Lead generation"); setValue("#f-monthly_budget", "2500"); selectByText("#f-crm", "HubSpot");
    clickText("Validate & submit"); await waitFor(has("Verified by the server"), "server acceptance"); expect(js(has("CRM sync")), "mapped requirement reported");
  });
  await step("smart intake turns free text into goals and requirements", async () => {
    clickText("Analyze"); await waitFor(has("Google Ads access") + " && " + has("Roofing"), "extracted requirements"); shot("10-forms-intake");
  });

  console.log("\nMulti-user isolation & roles");
  await step("a second user starts with no workspace, creates one, and sees none of the first user's data", async () => {
    const u2 = await signUpUser("rival@e2e.test", PASSWORD, { display_name: "Rival" }); const t2 = (await session(u2)).access_token;
    const none = await api("/api/v1/onboardings", { token: t2 }); expect(none.status === 403 && none.body.error.code === "NO_ORGANIZATION", `expected NO_ORGANIZATION ${JSON.stringify(none)}`);
    const created = await api("/api/v1/organizations", { method: "POST", token: t2, body: { name: "Rival Agency" } }); expect(created.status === 201, `org create ${JSON.stringify(created)}`);
    ctx.rivalOrg = created.body.data.organizationId;
    const list = await api("/api/v1/onboardings", { token: t2 }); expect(list.status === 200 && list.body.data.length === 0, "rival must see zero onboardings");
    expect((await api("/api/v1/invoices/list", { token: t2 })).body.data.length === 0, "rival must see zero invoices");
    expect((await api("/api/v1/onboardings", { token: t2, org: ctx.org })).status === 403, "rival cannot select the first workspace");
    expect((await api(`/api/v1/onboardings/${ctx.onb}/transition`, { method: "POST", token: t2, body: { to: "PAUSED", version: 2 }, headers: { "idempotency-key": "steal-1" } })).status === 404, "cross-tenant transition should be 404");
    ctx.t2 = t2;
  });
  await step("a user in two workspaces must choose one explicitly", async () => {
    const u2 = users.get("rival@e2e.test");
    await rows("insert into memberships (organization_id, user_id, role, status) values ($1,$2,'VIEWER','ACTIVE')", [ctx.org, u2.id]);
    const amb = await api("/api/v1/onboardings", { token: ctx.t2 }); expect(amb.status === 409 && amb.body.error.code === "ORGANIZATION_REQUIRED", `expected ORGANIZATION_REQUIRED ${JSON.stringify(amb.body)}`);
    const viewer = await api("/api/v1/onboardings", { token: ctx.t2, org: ctx.org }); expect(viewer.status === 200 && viewer.body.data.length === 1, "viewer can read the shared workspace");
  });
  await step("a VIEWER can read but cannot create, transition, invoice or verify", async () => {
    const h = { token: ctx.t2, org: ctx.org };
    expect((await api("/api/v1/onboardings", { ...h, method: "POST", body: { customerName: "X", title: "Y" }, headers: { "idempotency-key": "v-1" } })).status === 403, "create should be 403");
    expect((await api(`/api/v1/onboardings/${ctx.onb}/transition`, { ...h, method: "POST", body: { to: "PAUSED", version: 2 }, headers: { "idempotency-key": "v-2" } })).status === 403, "transition should be 403");
    expect((await api("/api/v1/invoices", { ...h, method: "POST", body: { customerId: randomUUID(), lines: [{ description: "x", quantity: 1, unitPriceCents: 100 }] } })).status === 403, "invoice create should be 403");
    expect((await api(`/api/v1/requirements/${randomUUID()}/verify`, { ...h, method: "POST", body: { type: "FORM", source: "x" }, headers: { "idempotency-key": "v-3" } })).status === 403, "verify should be 403");
  });

  console.log("\nSession lifecycle");
  await step("sign out ends the session; protected pages redirect to /login", async () => {
    let alive; try { alive = js("1+1"); } catch (e) { alive = "DEAD " + String(e.message).slice(0, 80); }
    if (alive !== 2) throw new Error(`browser unresponsive before sign-out (${alive}); server log tail: ${appLog.slice(-600)}`);
    try { js("location.reload()"); } catch { /* page unloads mid-eval */ }
    await sleep(800); await waitFor(has("Command center"), "dashboard still signed in after a page reload");
    js(`document.querySelector('button[aria-label="Sign out"]').click()`); await waitFor(pathIs("/login"), "redirect to /login after sign out");
    browser("open", APP + "/invoices-not-a-page"); browser("open", APP + "/"); await waitFor(pathIs("/login"), "still redirected when signed out");
  });
  await step("signing back in with the correct password restores the dashboard", async () => {
    await waitFor('!!document.querySelector(\'input[type="email"]\')', "login form");
    setValue('input[type="email"]', "maya@e2e.test"); setValue('input[type="password"]', PASSWORD); clickText("Sign in", "button.auth-submit");
    await waitFor(pathIs("/") + " && " + has("Command center"), "dashboard after login"); shot("11-after-login");
  });

  console.log("\nBackground jobs & opt-out");
  await step("job runner rejects anyone without the cron secret", async () => {
    expect((await api("/api/v1/jobs/run", { method: "POST" })).status === 403, "no secret → 403");
    expect((await api("/api/v1/jobs/run", { method: "POST", headers: { authorization: "Bearer wrong-secret-wrong-secret-wrong-sec" } })).status === 403, "wrong secret → 403");
  });
  await step("a due reminder is never falsely marked sent when no email provider is configured; it is retried", async () => {
    const [{ id: contact }] = await rows("select id from customer_contacts limit 1");
    const [{ id: req }] = await rows("select id from requirements where title='Google Ads access'");
    await rows("insert into scheduled_jobs (organization_id, kind, run_at, idempotency_key, payload) values ($1,'reminder', now() - interval '1 minute', 'e2e-reminder-1', $2::jsonb)", [ctx.org, JSON.stringify({ requirementId: req, onboardingId: ctx.onb, contactId: contact, channel: "EMAIL", step: 1, timezone: goodTimezone })]);
    const run = await api("/api/v1/jobs/run", { method: "POST", headers: { authorization: `Bearer ${CRON_SECRET}` } });
    expect(run.status === 200 && run.body.data.results[0]?.outcome === "RETRY_SCHEDULED", `run ${JSON.stringify(run.body)}`);
    const [job] = await rows("select status, attempts, last_error from scheduled_jobs where idempotency_key='e2e-reminder-1'");
    expect(job.status === "PENDING" && job.attempts === 1 && job.last_error === "EMAIL_PROVIDER_NOT_CONFIGURED", `job ${JSON.stringify(job)}`);
    expect(Number((await rows("select count(*) as n from messages where status='SENT'"))[0].n) === 0, "no message may be marked SENT");
  });
  await step("the one-click unsubscribe link opts the contact out and rejects forged links", async () => {
    const { createHmac } = await import("node:crypto");
    const [{ id: contact }] = await rows("select id from customer_contacts limit 1");
    const body = Buffer.from(JSON.stringify({ contactId: contact, channel: "EMAIL", organizationId: ctx.org })).toString("base64url");
    const token = `${body}.${createHmac("sha256", AUTH_SECRET).update(body).digest("base64url")}`;
    expect((await api(`/api/v1/unsubscribe?token=${body}.forged`, { method: "POST" })).status === 403, "forged token → 403");
    expect((await api(`/api/v1/unsubscribe?token=${token}`, { method: "POST" })).status === 200, "valid token → 200");
    expect((await rows("select app.can_contact($1,'EMAIL') as ok", [contact]))[0].ok === false, "contact must now be opted out");
    await rows("update scheduled_jobs set run_at = now() - interval '1 minute' where idempotency_key='e2e-reminder-1'");
    const run = await api("/api/v1/jobs/run", { method: "POST", headers: { authorization: `Bearer ${CRON_SECRET}` } });
    expect(run.body.data.results[0]?.outcome === "SUPPRESSED_NO_CONSENT_OR_OPTED_OUT", `after opt-out ${JSON.stringify(run.body)}`);
  });
  await step("health endpoint reports a live database", async () => {
    const h = await api("/api/v1/health"); expect(h.status === 200 && h.body.data.dependencies.database === "ok", `health ${JSON.stringify(h.body)}`);
  });
} finally {
  try { browser("close"); } catch { /* ignore */ }
  for (const c of children) c.kill();
  authServer.close(); stripeServer.close(); await dbServer.stop().catch(() => undefined);
  const failed = results.filter((r) => !r.ok);
  console.log(`\n${results.length - failed.length}/${results.length} end-to-end checks passed`);
  process.exit(failed.length ? 1 : 0);
}
